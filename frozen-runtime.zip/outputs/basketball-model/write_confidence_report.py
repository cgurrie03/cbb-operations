from pathlib import Path
import json,math,shutil
import numpy as np
import pandas as pd
from confidence_check import ROOT,OLD,OUT,sha

def pct(v):return 'Unavailable' if pd.isna(v) else f'{100*v:.1f}%'
def wilson(w,n):
    if not n:return 'Unavailable'
    z=1.959963984540054;p=w/n;den=1+z*z/n;c=(p+z*z/(2*n))/den;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return f'{100*(c-h):.1f}–{100*(c+h):.1f}%'
def table(frame,kind='cover'):
    text='| Band | Games | Decided W–L | Pushes | Mean predicted probability | Actual spread cover rate | 95% date-block interval |\n| --- | ---: | ---: | ---: | ---: | ---: | --- |\n'
    for r in frame.itertuples():
        interval=f'{pct(r.date_block_low)}–{pct(r.date_block_high)}' if pd.notna(r.date_block_low) else 'Unavailable'
        text+=f'| {r.band} | {r.n:,} | {r.wins:,}–{r.losses:,} | {r.pushes} | {pct(r.mean_probability)} | {pct(r.cover_rate)} | {interval}{"; sparse" if r.sparse else ""} |\n'
    return text

bins=pd.read_csv(OUT/'confidence-buckets.csv')
high=pd.read_csv(OUT/'70-percent-check.csv')
metrics=json.loads((OUT/'probability-metrics.json').read_text())
manifest=json.loads((OUT/'prediction-manifest.json').read_text())
for name,digest in manifest['files'].items():assert sha(OUT/name)==digest
assert sha(OUT/'prediction-implementation.py')==manifest['code_sha256']
assert sha(OUT/'CHARTER.md')==manifest['charter_sha256']
for name,digest in manifest['source_hashes'].items():assert sha(OLD/name)==digest
near=bins[(bins.population=='near_tipoff_benchmark')&(bins.season=='all')]
cover=near[near.probability_kind=='exploratory_cover_probability']
winner=near[near.probability_kind=='original_winner_confidence']
strict=bins[(bins.population=='one_hour_cutoff')&(bins.season=='all')&(bins.probability_kind=='exploratory_cover_probability')]
allpred=pd.read_parquet(OUT/'recomputed-model-predictions.parquet')
matched=pd.read_parquet(OUT/'predictions.parquet')
missing=allpred[~allpred.game_id.isin(matched.game_id)].copy();missing['reason']='No accepted DraftKings spread line in retained archive under exact identity/timing rules'
missing.to_csv(OUT/'excluded-no-draftkings-line.csv',index=False)

report='''# Spread confidence check — October 17, 2026

The audit corrections are deployed at **https://cbb.coopergurrie.com/**. Site version 24, pushed source `e0cecfdf0481bd9c92a7d0d771913dc2b71c04e1`. The existing public audience was preserved. No live model, future forecast or bet was issued by this analysis.

## Answer to “what happened to the 70% predictions?”

The original model's displayed probabilities mean **chance of winning outright**, not chance of covering a sportsbook spread. On the same historical games with accepted DraftKings lines:

- Original **about 70% winner confidence** (67.5% to below 72.5%): **68.7% actual winner accuracy** across 1,699 games. The original point-margin spread picks covered **49.0%**: **817 wins, 850 losses, 32 pushes**. These spread picks can select the opposite side from the predicted outright winner; they use the original predicted-margin-versus-handicap rule.
- Original **70% to below 75% winner confidence**: **70.4% winner accuracy**, but **47.9% spread accuracy**: **826 wins, 899 losses, 30 pushes**.
- The original replay did **not** store spread-cover probabilities. A separately labeled exploratory mapping, learned from earlier held-out seasons only, assigned probabilities **about 70%** to 643 historical spread decisions: **306 wins, 328 losses, 9 pushes**, or **48.3% actual covers** on 634 decided games. Mean predicted probability was **69.7%**. Its descriptive 95% date-block interval is **45.3–51.4%**. This is a new diagnostic probability mapping, not evidence that a previously issued 70% spread forecast existed.

The large sample uses **near-tipoff archived lines**, most recorded after the one-hour forecast cutoff. Restricting to genuinely cutoff-eligible quotes leaves **49 games total**. The exploratory about-70% group contains **only five decisions: 4 wins, 1 loss (80%)**. That sample cannot substantiate a 70% success claim. A supplemental binomial Wilson interval is **37.6–96.4%**, which assumes independent decisions and does not resolve source-vintage or development-selection uncertainty.

## Original winner-confidence bands and spread results

These are original pregame winner probabilities. The spread-cover column grades the original margin model's selected spread side; it is not the actual frequency of the outright-win event. Confidence-bin game counts include pushes; cover accuracy is W/(W+L). The table does not represent actual placed bets.

'''+table(winner)+'''

Actual winner accuracy for these bands, respectively from 50–55% through 95–100%: **51.6%, 56.5%, 60.2%, 65.5%, 70.4%, 75.3%, 81.1%, 87.6%, 93.8%, 97.1%**. This is why winner reliability and spread performance must be kept separate.

## Exploratory spread-cover probability bands

Probabilities below use a newly constructed residual distribution from earlier seasons. They are conditional on no push. The original spread-pick side remains unchanged. A small predicted edge can have below-50% cover probability because the empirical residual distribution is asymmetric; those cases remain visible rather than being silently dropped or switched to the other side.

'''+table(cover)+'''

The conventional **70–75% spread-probability band** averaged **72.2% predicted**, but covered **47.8%**: **205–224 with 9 pushes**. Its descriptive date-block interval is **43.5–51.6%**. Do not substitute the 67.5–72.5%, 70–75% or >=70% groups for one another; all were declared before bucket grading, and all are in `70-percent-check.csv`.

![Historical spread probability reliability](spread-calibration.png)

## About-70% spread diagnostic by completed season

| Season | Matched decisions | W–L | Pushes | Mean predicted | Actual cover rate | 95% date-block interval |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| 2022–23 | 185 | 84–99 | 2 | 69.8% | 45.9% | 40.3–52.3% |
| 2023–24 | 238 | 122–114 | 2 | 69.6% | 51.7% | 46.1–57.7% |
| 2024–25 | 220 | 100–115 | 5 | 69.7% | 46.5% | 41.8–50.7% |

## Strict one-hour-cutoff population

This table uses only archived quotes timestamped at or before the decision cutoff. It is a much smaller population than the near-tipoff benchmark. No later line is silently treated as if it were available earlier.

'''+table(strict)+'''

Sparse groups require caution: an all-win/all-loss group can produce a degenerate nonparametric bootstrap interval (for example 100–100% with only two wins). That is a bootstrap limitation, not certainty. A supplemental Wilson interval for 2/2 is 34.2–100%; for 4/5, 37.6–96.4%. The block intervals are descriptive, not guarantees or corrections for previous model-selection effects.

## Methods, coverage and outcome isolation

One decision per game, primary bookmaker DraftKings. Home spread grade uses actual home margin + home handicap. Pick home if predicted margin + handicap >0, away if <0; forecast equality is a pass. Actual equality is a push, reported separately and excluded from cover accuracy.

The existing result-hidden replay has **17,205 retained D1–D1 games** in completed seasons ending 2023–2025. **15,951** have accepted DraftKings spread lines; **1,254** lack such a line and are listed in `excluded-no-draftkings-line.csv`. Missing lines are never wins. Of the accepted spread lines, **15,902** were later than the one-hour cutoff; only **49** meet it. Across all matched spreads: **7,782 wins, 7,901 losses, 268 pushes**, or **49.62%**. The strict-cutoff sample is **20 wins, 28 losses, 1 push**, or **41.67%** on 48 decided games. Raw archive recovery confirms that earlier retained observations do not expand the 49-game cutoff population.

The independent prediction worker read pregame test features, earlier training targets and outcome-free line fields only. It recomputed the frozen 2016–2022 classifier and Ridge margin model and matched the existing forecasts to absolute tolerance 1e-12. Test results are assumed released 24 hours after listed tipoff; daily feature ratings freeze at the earliest cutoff. Five forward folds ending 2018–2022 supplied held-out margin residuals; every fold trained on earlier released seasons only. That empirical error distribution was frozen before test-bucket grading, with integer margin rounding and separate push probability. No 2023–2025 outcomes trained the new probability mapping.

All test predictions/probabilities/sides/buckets were written and SHA-256 hashed before a separate grading process opened outcomes. Grading-time outcome poisoning changed grades while preserving probability, side, bucket and artifact hashes. Five existing independent replay tests and seven new probability/grading/bootstrap/hash tests passed. Original replay files were not overwritten. The probability-production source is preserved verbatim as `prediction-implementation.py`; its hash matches the prediction manifest.

All bins and the about-70% band were written in `CHARTER.md` before bucket results were inspected. Bootstrap uncertainty uses 2,000 seeded circular seven-active-date resamples across all matched evaluation dates, retaining zero-count bucket dates. The grading bootstrap was optimized to reuse identical resample weights after the initial implementation proved slow; a regression test confirms the same locked random resampling. This changes computation speed, not selection rules, predictions or results. The few repeated raw archive entries were separately checked using identity/date/orientation and timestamps only; they produce the identical 49 eligible lines. Original winner confidence and exploratory cover confidence are separate columns in every export.

## Probability metrics and verdict

| Population | Decided n | Brier error | Log loss | Fixed-bin ECE | 50% baseline Brier / log loss |
| --- | ---: | ---: | ---: | ---: | --- |
| Near-tipoff benchmark | 15,683 | 0.26042 | 0.71645 | 0.07456 | 0.25000 / 0.69315 |
| One-hour cutoff | 48 | 0.25922 | 0.71158 | 0.20346 | 0.25000 / 0.69315 |

Lower Brier/log loss is better. These compare the exploratory cover probabilities with a 50% prediction on the identical nonpush population. Winner probabilities are not scored against spread outcomes. ECE depends on the fixed binning and is unstable in the tiny cutoff sample. Both the observed near-tipoff calibration and probability-error metrics argue against using this exploratory mapping as calibrated spread confidence.

**Leakage verdict: REVIEW REQUIRED. Calibration verdict: invalid-eval for prospective claims; no validated production spread-confidence model.** Direct computational result withholding passed. Original source publication/revision timestamps and prior use of these seasons for model development remain unresolved. Most market lines are later than the model cutoff. The observed mismatch in this exploratory near-tipoff experiment is not proof of the calibration of a nonexistent issued spread forecast. It does show that this construction does not turn an asserted 70% probability into 70% realized covers.

The unconditional margin-error distribution does not condition on the sportsbook line's information; it should not be mistaken for a market-aware probability model. No change was fitted to the evaluated outcomes. No preserved 2026 outcome holdout was opened. There are no verified archived wager prices, so no ROI, profitability or live betting-edge claim is made.

Next model work should use timestamped quotes available at the actual decision cutoff and a separately locked market-aware challenger. Learn probability calibration on earlier held-out residuals/quotes, then score a genuinely untouched or prospective sample with immutable forecast records. These results must not be used to pick whichever threshold happened to look best.

## Reproduction and deliverables

From the existing `basketball-model` directory, using its existing basketball Python environment:

1. Read `confidence-check-20261017/CHARTER.md` and manifests.
2. `confidence_check.py predict` refuses to overwrite frozen predictions. The saved prediction worker implementation and hashes are included; use a new experiment directory for a new run.
3. `confidence_check.py grade` grades the saved immutable predictions; `confidence_check.py plot` renders the figure.
4. Run `python -m unittest discover -s tests -p test_blind_replay.py -v` and `python -m unittest discover -s tests -p test_confidence_check.py -v`.

Exports include every matched game and grade (`game-by-game.csv`), all fixed bands by season and timing population (`confidence-buckets.csv`), three predeclared 70% definitions (`70-percent-check.csv`), coverage exclusions, probability metrics, source/prediction manifests and integrity checks. The published site audit and this model diagnostic are separate workstreams; the production model was not changed.
'''
(OUT/'REPORT.md').write_text(report,encoding='utf-8')
print('Report written; frozen source and prediction hashes verified.')
