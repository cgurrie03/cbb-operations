"""Frozen market residual experiment: fit, predict, then grade in separate stages."""
import argparse,json
from datetime import datetime,timezone
import joblib
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge
from spread_v3 import ROOT,OUT as V3,FEATURES as BASIC,sha,dump
from spread_v4_features import OUT,NAMES
from confidence_check import probabilities

FEATURES=BASIC+['rating_market_edge']+[n for n in NAMES if n!='rating_edge']
CANDIDATES=['basic_logistic','enhanced_raw','enhanced_calibrated','enhanced_margin']

def inputs(final=False):
    path=V3/('closing-pregame-inputs.parquet' if final else 'pregame-through-2025.parquet')
    x=pd.read_parquet(path)
    if not final:x=x[x.season.le(2024)].copy()
    f=pd.read_parquet(OUT/'features.parquet')
    x=x.merge(f.drop(columns=['season','decision_time','latest_result_used']),on='game_id',validate='one_to_one')
    x['rating_market_edge']=x.rating_edge+x.line
    assert not set(['margin','home_delta','won','home_score','away_score']).intersection(x)
    assert np.isfinite(x[FEATURES].to_numpy()).all()
    return x

def label(x,year):
    y=pd.read_parquet(ROOT/'stage2/games.parquet',columns=['game_id','season','margin'],filters=[('season','<=',year)])
    t=x.merge(y[['game_id','margin']],on='game_id',validate='one_to_one')
    t['delta']=t.margin+t.line;t['push']=np.isclose(t.delta,0,atol=1e-10,rtol=0)
    t['y']=t.delta.gt(0).astype(int)
    return t

def fit(train,cal):
    assert train.season.max()<cal.season.min()
    assert train.tipoff.max()+pd.Timedelta(hours=24)<cal.feature_cutoff.min()
    a=train[~train.push];b=cal[~cal.push]
    basic=make_pipeline(StandardScaler(),LogisticRegression(C=1.,max_iter=2000)).fit(a[BASIC],a.y)
    enhanced=make_pipeline(StandardScaler(),LogisticRegression(C=.1,max_iter=2000)).fit(a[FEATURES],a.y)
    sigmoid=LogisticRegression(C=1e6,max_iter=2000).fit(enhanced.decision_function(b[FEATURES]).reshape(-1,1),b.y)
    margin=make_pipeline(StandardScaler(),Ridge(alpha=100.)).fit(train[FEATURES],train.delta)
    residual=cal.delta.to_numpy()-margin.predict(cal[FEATURES])
    strata={}
    for low in [True,False]:
        mask=cal.min_history.lt(8).to_numpy()==low
        strata[low]=residual[mask] if mask.sum()>=200 else residual
    integer=np.isclose(train.line,np.round(train.line),rtol=0,atol=1e-10)
    push_rate=(train.loc[integer,'push'].sum()+1)/(integer.sum()+2)
    return dict(basic=basic,enhanced=enhanced,sigmoid=sigmoid,margin=margin,
                residual=residual,strata=strata,push_rate=float(push_rate),
                train_seasons=sorted(map(int,train.season.unique())),calibration_season=int(cal.season.min()))

def payout(price):
    a=np.asarray(price,dtype=float)
    return np.where(a>0,a/100,100/np.maximum(np.abs(a),1))

def market_reference(x):
    if not {'home_price','away_price'}.issubset(x):return np.full(len(x),.5)
    h=np.asarray(x.home_price,dtype=float);a=np.asarray(x.away_price,dtype=float)
    valid=np.isfinite(h)&np.isfinite(a)&(np.abs(h)>=100)&(np.abs(a)>=100)
    hp=1/(1+payout(h));ap=1/(1+payout(a))
    return np.where(valid,hp/(hp+ap),.5)

def predict(models,x):
    if {'margin','delta','y','push','won','home_score','away_score'}.intersection(x):raise ValueError('Outcome present in prediction inputs')
    base=models['basic'].predict_proba(x[BASIC])[:,1]
    raw=models['enhanced'].predict_proba(x[FEATURES])[:,1]
    calibrated=models['sigmoid'].predict_proba(models['enhanced'].decision_function(x[FEATURES]).reshape(-1,1))[:,1]
    correction=models['margin'].predict(x[FEATURES]);point=-x.line.to_numpy()+correction
    hp=np.zeros(len(x));pp=hp.copy();low=hp.copy();high=hp.copy()
    for is_low in [True,False]:
        mask=x.min_history.lt(8).to_numpy()==is_low;r=models['strata'][is_low]
        if not mask.any():continue
        hp[mask],_,pp[mask]=probabilities(point[mask],x.line.to_numpy()[mask],r)
        low[mask]=point[mask]+np.quantile(r,.1);high[mask]=point[mask]+np.quantile(r,.9)
    generic=np.where(np.isclose(x.line,np.round(x.line),rtol=0,atol=1e-10),models['push_rate'],0.)
    # Fixed conservative shrinkage is not a fitted claim of uncertainty coverage.
    weight=.8*x.min_history.to_numpy()/(x.min_history.to_numpy()+8)
    reference=market_reference(x);rows=[]
    for name,p in [('market_50',np.full(len(x),.5)),('market_no_vig',reference),('basic_logistic',base),
                   ('enhanced_raw',reference+weight*(raw-.5)),
                   ('enhanced_calibrated',reference+weight*(calibrated-.5)),
                   ('enhanced_margin',reference+weight*(hp-.5))]:
        out=x.copy()
        out['candidate']=name;out['home_cover_probability']=np.clip(p,.000001,.999999)
        out['push_probability']=pp if name=='enhanced_margin' else generic
        out['uncertainty_weight']=weight if name.startswith('enhanced') else 1.
        out['min_history']=x.min_history.to_numpy()
        out['predicted_margin']=point if name=='enhanced_margin' else -x.line.to_numpy()
        out['margin_low_80']=low if name=='enhanced_margin' else np.nan
        out['margin_high_80']=high if name=='enhanced_margin' else np.nan
        out['injury_snapshot_verified']=False
        out['historical_timing_verified']=False
        rows.append(out)
    return pd.concat(rows,ignore_index=True)

def scores(pred,labels):
    a=pred.merge(labels[['game_id','margin']],on='game_id',validate='many_to_one')
    delta=a.margin+a.line;a=a[~np.isclose(delta,0,atol=1e-10,rtol=0)].copy()
    a['y']=(a.margin+a.line>0).astype(int);p=a.home_cover_probability
    a['ll']=-a.y*np.log(p)-(1-a.y)*np.log1p(-p);a['brier']=(p-a.y)**2
    return a.groupby(['candidate','season']).agg(games=('game_id','size'),log_loss=('ll','mean'),brier=('brier','mean')).reset_index()

def develop():
    if (OUT/'selection.json').exists():raise RuntimeError('Frozen selection exists')
    x=inputs();dev=label(x,2024);parts=[]
    for year in [2023,2024]:
        m=fit(dev[dev.season.le(year-2)],dev[dev.season.eq(year-1)])
        p=predict(m,x[x.season.eq(year)]);parts.append(p)
    p=pd.concat(parts,ignore_index=True);p.to_parquet(OUT/'development-predictions.parquet',index=False)
    s=scores(p,dev);s.to_csv(OUT/'development-metrics.csv',index=False)
    pivot=s.pivot(index='candidate',columns='season',values='log_loss');reference=pivot.loc['market_50']
    eligible=[c for c in CANDIDATES if (pivot.loc[c]<reference).all() and (reference-pivot.loc[c]).mean()>=.001]
    selected=min(eligible,key=lambda c:pivot.loc[c].mean()) if eligible else 'market_50'
    models=fit(dev[dev.season.le(2023)],dev[dev.season.eq(2024)])
    joblib.dump(models,OUT/'frozen-models.joblib')
    dump(OUT/'selection.json',dict(created_at=datetime.now(timezone.utc).isoformat(),candidate=selected,
        eligible=eligible,promotion=False,prospective_validation_required=True,
        reason='Both final seasons previously inspected; no newly untouched holdout',
        features=FEATURES,development=s.to_dict('records'),
        trees_added=False,tree_rule='Only after enhanced logistic beats simpler baselines in both development folds',
        charter_sha256=sha(OUT/'CHARTER.md'),feature_sha256=sha(OUT/'features.parquet'),
        model_sha256=sha(OUT/'frozen-models.joblib'),source_sha256=sha(__file__)))
    print(s.to_string(index=False),flush=True);print('Frozen development selection:',selected,flush=True)

def final_predict():
    if (OUT/'final-predictions.parquet').exists():raise RuntimeError('Frozen predictions exist')
    selection=json.loads((OUT/'selection.json').read_text());assert sha(OUT/'frozen-models.joblib')==selection['model_sha256']
    models=joblib.load(OUT/'frozen-models.joblib');x=inputs(True)
    p=predict(models,x);p.to_parquet(OUT/'final-predictions.parquet',index=False)
    dump(OUT/'prediction-manifest.json',dict(created_at=datetime.now(timezone.utc).isoformat(),
        prediction_sha256=sha(OUT/'final-predictions.parquet'),source_sha256=sha(__file__),
        selection_sha256=sha(OUT/'selection.json'),games_by_season={str(y):len(g) for y,g in x.groupby('season')},
        model_sha256=sha(OUT/'frozen-models.joblib'),labels_not_loaded_in_predictor=True,
        previously_observed_seasons=True))
    print('Frozen final predictions:',len(p),flush=True)

def decision(frame,minimum_ev=.02,minimum_history=8):
    """Select the best-priced side, including pushes; invalid/missing prices pass."""
    x=frame.copy();p=x.home_cover_probability.to_numpy();push=x.push_probability.to_numpy()
    h=np.asarray(x.home_price,dtype=float);a=np.asarray(x.away_price,dtype=float)
    valid=np.isfinite(h)&np.isfinite(a)&(np.abs(h)>=100)&(np.abs(a)>=100)
    hev=(1-push)*(p*payout(h)-(1-p));aev=(1-push)*((1-p)*payout(a)-p)
    home=hev>=aev;ev=np.where(home,hev,aev)
    take=valid&np.isfinite(ev)&(ev>=minimum_ev)&x.min_history.ge(minimum_history).to_numpy()
    x['selected_side']=np.where(take,np.where(home,'home','away'),'pass')
    x['selected_cover_probability']=np.where(home,p,1-p)
    x['selected_price']=np.where(take,np.where(home,h,a),np.nan)
    x['expected_profit']=np.where(valid,ev,np.nan);x['minimum_ev']=minimum_ev
    x['pass_reason']=np.where(~valid,'missing price',np.where(x.min_history.lt(minimum_history),'insufficient history',np.where(~take,'insufficient expected return','selected')))
    return x

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['develop','predict']);args=parser.parse_args()
    {'develop':develop,'predict':final_predict}[args.stage]()
