"""Locked, conditional research comparison; no live promotion or 2026 outcomes."""
from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from stage2_models import loss

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'blind-replay-20261014'
OUT=ROOT/'improvements-20261014'
NAMES=['frozen_core','expanding_core','recent_core','strength_core']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,default=str,allow_nan=False),encoding='utf8')
def columns(name,target):
    c=['eff_margin','venue_effect'] if target in ['won','margin'] else ['eff_total','expected_pace','venue_effect']
    return c+(['strength_margin'] if name=='strength_core' and target in ['won','margin'] else [])
def fit_predict(train,test,name):
    assert train.season.max()<test.season.min()
    assert train.release.max()<test.decision_time.min()
    result=test[['game_id','season','decision_time']].copy()
    for target in ['won','margin','total']:
        c=columns(name,target)
        model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=1000) if target=='won' else Ridge(alpha=20))
        model.fit(train[c],train[target])
        result[target+'_prediction']=model.predict_proba(test[c])[:,1] if target=='won' else model.predict(test[c])
    result['candidate']=name
    return result
def training_for(frame,season,name):
    x=frame[frame.season<(2023 if name=='frozen_core' and season>=2023 else season)]
    if name=='recent_core':x=x[x.season>=season-3]
    return x
def metrics(p):
    rows=[]
    for (name,season),g in p.groupby(['candidate','season']):
        rows.append(dict(candidate=name,season=int(season),n=len(g),log_loss=float(loss(g.won,g.won_prediction).mean()),
                         brier=float(((g.won-g.won_prediction)**2).mean()),accuracy=float(((g.won_prediction>=.5)==g.won).mean()),
                         margin_mae=float((g.margin_prediction-g.margin).abs().mean()),total_mae=float((g.total_prediction-g.total).abs().mean())))
    return pd.DataFrame(rows)
def main():
    OUT.mkdir(exist_ok=False)
    dump(OUT/'pre_run.json',{'created_at':datetime.now(timezone.utc).isoformat(),'charter_sha256':sha(ROOT/'IMPROVEMENT_CHARTER.md'),
        'implementation_sha256':sha(Path(__file__)),'input_sha256':{p.name:sha(p) for p in [OLD/'train-24.parquet',OLD/'pregame-24.parquet']},
        'verdict':'REVIEW REQUIRED; conditional research only','promotion':False,'candidates':NAMES})
    train=pd.read_parquet(OLD/'train-24.parquet');test=pd.read_parquet(OLD/'pregame-24.parquet')
    assert train.season.max()==2022 and test.season.max()==2025
    # Selection uses only pre-2023 labels and features. No test outcomes opened here.
    inner=[]
    for name in NAMES[1:]:
        for year in range(2018,2023):
            t=training_for(train,year,name);v=train[train.season==year]
            r=fit_predict(t,v,name).merge(v[['game_id','won','margin','total']],on='game_id',validate='one_to_one');inner.append(r)
    inner=pd.concat(inner,ignore_index=True);m=metrics(inner);m.to_csv(OUT/'selection_metrics.csv',index=False)
    means=m.groupby('candidate')[['log_loss','margin_mae','total_mae']].mean()
    selected={target:means[metric].idxmin() for target,metric in [('won','log_loss'),('margin','margin_mae'),('total','total_mae')]}
    dump(OUT/'frozen_selection.json',{'selected':selected,'selection_ending_years':[2018,2022],'test_results_opened':False,'tie_policy':'first listed candidate'})
    # Every outer fold learns only earlier labels. Raw test targets are restricted
    # to the preceding years when constructing an annual refit training file.
    source=pd.read_parquet(ROOT/'stage2/games.parquet',columns=['game_id','season','won','margin','total','tipoff'])
    source=source[source.season<=2025];source['release']=source.tipoff+pd.Timedelta(hours=24)
    prediction_files=[]
    for year in [2023,2024,2025]:
        prior=test[test.season<year].merge(source[source.season<year][['game_id','won','margin','total','release']],on='game_id',validate='one_to_one')
        available=pd.concat([train,prior],ignore_index=True)
        slate=test[test.season==year]
        preds=[]
        for name in NAMES:
            t=training_for(available,year,name);r=fit_predict(t,slate,name);r['train_n']=len(t);r['train_last_season']=int(t.season.max());preds.append(r)
        p=pd.concat(preds,ignore_index=True)
        chosen=slate[['game_id','season','decision_time']].copy();chosen['candidate']='pre2023_selected'
        for target,name in selected.items():chosen[target+'_prediction']=p[p.candidate==name].set_index('game_id').loc[chosen.game_id,target+'_prediction'].to_numpy()
        p=pd.concat([p,chosen],ignore_index=True);path=OUT/f'predictions-{year}.parquet';p.to_parquet(path,index=False);prediction_files.append(path)
    hashes={p.name:sha(p) for p in prediction_files};dump(OUT/'predictions_manifest.json',hashes)
    # Only now grade immutable predictions. Never tune or refit after this step.
    p=pd.concat([pd.read_parquet(f) for f in prediction_files],ignore_index=True).merge(source[['game_id','won','margin','total']],on='game_id',validate='many_to_one')
    outer=metrics(p);outer.to_csv(OUT/'evaluation_metrics.csv',index=False)
    for name,g in p.groupby('candidate'):
        b=g.assign(bin=np.minimum((g.won_prediction*10).astype(int),9)).groupby('bin').agg(n=('won','size'),mean_probability=('won_prediction','mean'),observed_win_rate=('won','mean'))
        b.to_csv(OUT/f'calibration-{name}.csv')
    p.to_parquet(OUT/'graded_predictions.parquet',index=False)
    assert hashes=={f.name:sha(f) for f in prediction_files}
    summary=outer.groupby('candidate').apply(lambda g:pd.Series({k:np.average(g[k],weights=g.n) for k in ['log_loss','brier','accuracy','margin_mae','total_mae']}),include_groups=False)
    summary.to_csv(OUT/'summary.csv');print(summary.to_string())
    dump(OUT/'outcome.json',{'status':'completed_conditional_research','selected_before_test':selected,'promotion':False,'leakage_verdict':'REVIEW REQUIRED',
        'reason':'Historical publication vintages and prior development selection unresolved. No 2026 game outcomes acquired.',
        'prediction_hashes_unchanged':True,'metrics':summary.reset_index().to_dict('records')})
if __name__=='__main__':main()
