"""Validate source-linked availability without converting absences into injuries."""
from datetime import datetime,timezone
def timestamp(value):
    value=datetime.fromisoformat(value.replace('Z','+00:00'))
    if value.tzinfo is None:raise ValueError('Timezone required')
    return value.astimezone(timezone.utc)
def eligible_report(report,decision_time):
    required=['game_id','team_id','athlete_id','status','source_url','published_at','observed_at']
    if any(not report.get(k) for k in required):return False
    if report['status'] not in ['available','out','questionable','doubtful','probable']:return False
    if not report['source_url'].startswith('https://'):return False
    try:
        published,observed,cutoff=map(timestamp,[report['published_at'],report['observed_at'],decision_time])
        return published<=observed<=cutoff and (cutoff-published).total_seconds()<=48*3600
    except (ValueError,TypeError):return False
def prior_contribution(appearances,team_id,athlete_id,decision_time):
    """Past minutes only. This is not an expected lineup or an injury label."""
    import pandas as pd
    cutoff=timestamp(decision_time)
    x=appearances[(appearances.team_id==team_id)&(appearances.tipoff+pd.Timedelta(hours=24)<=cutoff)].copy()
    last=x[['game_id','tipoff']].drop_duplicates().sort_values('tipoff').tail(10).game_id
    x=x[x.game_id.isin(last)]
    if not len(last):return {'games':0,'minutes_per_team_game':None,'contributor':None}
    minutes=float(x.loc[x.athlete_id==athlete_id,'minutes'].sum())/len(last)
    return {'games':len(last),'minutes_per_team_game':minutes,'contributor':minutes>=15}

def attach_reports(data,reports,checked_at):
    """Optional verified reports; a player's status does not certify full coverage."""
    from datetime import timedelta
    for game in data['upcoming']:
        cutoff=(timestamp(game['tipoff'])-timedelta(hours=1)).isoformat()
        applicable=[r for r in reports if r.get('game_id')==game['id'] and eligible_report(r,min(timestamp(cutoff),timestamp(checked_at)).isoformat())]
        if not applicable:continue
        # Conservative warning when contribution has not yet been established.
        uncertain=[r for r in applicable if r['status'] in ['out','questionable','doubtful'] and r.get('contributor') is not False]
        game['availabilityReports']=applicable;game['availabilityCheckedAt']=checked_at
        game['playerUncertainty']=bool(uncertain)
        if uncertain:
            r=max(uncertain,key=lambda r:r['observed_at'])
            game['availabilityReport']={'status':r['status'],'publishedAt':r['published_at'],'observedAt':r['observed_at'],'source':r['source_url'],'player':r.get('athlete_name','Player')}
    return data
