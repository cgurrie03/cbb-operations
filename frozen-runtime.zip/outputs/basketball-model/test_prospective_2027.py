"""No backdating, hindsight selection, fake odds, or future-result feature updates."""
import unittest,tempfile,json,hashlib,copy
from pathlib import Path
from datetime import datetime,timezone,timedelta
from unittest.mock import patch
import pandas as pd
from prospective_registry import save,canonical
from prospective_run import normalize_result,history_at
import prospective_run as runner
from preseason_features import OnlineFeatures

class PaperTests(unittest.TestCase):
    def record(self):
        t=datetime(2026,11,2,16,tzinfo=timezone.utc);features={'min_history':0.,'raw_edge':1.}
        return dict(game_id='espn:fixture',model_version='test-only',candidate='enhanced_raw',model_sha256='a'*64,
            issued_at=t.isoformat(),cutoff=(t+timedelta(hours=1)).isoformat(),tipoff=(t+timedelta(hours=2)).isoformat(),
            features_observed_at=t.isoformat(),features=features,feature_sha256=hashlib.sha256(json.dumps(features,sort_keys=True).encode()).hexdigest(),
            paper_side='pass',pass_reason='test fixture',status='paper',home_cover_probability=.55,line=-3.5,home_price=-110,away_price=-110,
            quote_observed_at=t.isoformat(),quote_at=(t-timedelta(minutes=1)).isoformat())
    def persist(self,r,folder):return save(r,folder,clock=lambda:datetime(2026,11,2,16,tzinfo=timezone.utc))
    def test_valid_snapshot_is_immutable(self):
        r=self.record()
        with tempfile.TemporaryDirectory() as folder:
            a=self.persist(r,folder);self.assertEqual(a,self.persist(r,folder))
            r['paper_side']='home'
            with self.assertRaises(ValueError):self.persist(r,folder)
    def test_backdating_rejected(self):
        r=self.record();r['issued_at']='2026-11-02T15:00:00+00:00'
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):self.persist(r,folder)
    def test_after_cutoff_and_future_feature_capture_rejected(self):
        for key,value in [('cutoff','2026-11-02T15:59:00+00:00'),('features_observed_at','2026-11-02T16:01:00+00:00')]:
            r=self.record();r[key]=value
            with tempfile.TemporaryDirectory() as folder:
                with self.assertRaises(ValueError):self.persist(r,folder)
    def test_outside_issue_window_rejected(self):
        r=self.record();r['tipoff']='2026-11-04T18:00:00+00:00'
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):self.persist(r,folder)
    def test_nested_outcome_rejected(self):
        r=self.record();r['features']['home_score']=77
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):self.persist(r,folder)
    def test_feature_hash_mismatch_rejected(self):
        r=self.record();r['features']['raw_edge']=100
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):self.persist(r,folder)
    def test_stale_future_and_missing_price_rejected(self):
        for key,value in [('quote_at','2026-11-02T15:44:00+00:00'),('quote_at','2026-11-02T16:01:00+00:00'),('home_price',None)]:
            r=self.record();r[key]=value
            with tempfile.TemporaryDirectory() as folder:
                with self.assertRaises(ValueError):self.persist(r,folder)
    def test_unpriced_pass_is_not_a_probability_claim(self):
        r=self.record();r.update(home_cover_probability=None,line=None,home_price=None,away_price=None,quote_at=None,quote_observed_at=None)
        with tempfile.TemporaryDirectory() as folder:self.persist(r,folder)
    def test_one_canonical_record_per_game_candidate(self):
        a=self.record();b=copy.deepcopy(a);b['issued_at']='2026-11-02T16:30:00+00:00';b['paper_side']='away'
        self.assertEqual(canonical([b,a])[0]['paper_side'],'away')
        self.assertEqual(len(canonical([a,b])),1)
    def fixture(self):
        c=dict(status={'type':{'completed':True},'period':2},neutralSite=False,timeValid=True,competitors=[
            {'homeAway':'home','team':{'id':'57'},'score':'70'}, {'homeAway':'away','team':{'id':'150'},'score':'60'}])
        return dict(id='fixture',date='2026-11-02T17:00:00Z',season={'year':2027,'type':2},competitions=[c])
    def test_same_day_and_exhibition_results_cannot_enter_history(self):
        e=self.fixture();g,_=normalize_result(e,{},'2026-11-03T16:59:00+00:00');self.assertIsNone(g)
        e['season']['type']=1;g,_=normalize_result(e,{},'2026-11-04T17:00:00+00:00');self.assertIsNone(g)
    def test_missing_box_is_explicit_not_fabricated(self):
        g,_=normalize_result(self.fixture(),{},'2026-11-04T17:00:00+00:00')
        self.assertFalse(g['box_usable']);self.assertEqual(g['margin'],10)
    def test_unconfirmed_placeholder_time_is_not_a_result_clock(self):
        e=self.fixture();e['competitions'][0]['timeValid']=False
        g,_=normalize_result(e,{},'2026-11-04T17:00:00+00:00');self.assertIsNone(g)
    def test_unobserved_results_do_not_affect_history(self):
        e=self.fixture();g,_=normalize_result(e,{},'2026-11-04T17:00:00+00:00');g['tipoff']=g['tipoff'].isoformat()
        with tempfile.TemporaryDirectory() as folder:
            f=Path(folder)/'settled';f.mkdir();(f/'fixture.json').write_text(json.dumps(dict(game=g,rotations={})))
            with patch('prospective_run.PRIVATE',Path(folder)):
                h,_,_=history_at(pd.Timestamp('2026-11-03T18:00:00Z'));self.assertTrue(h.empty)
                h,_,_=history_at(pd.Timestamp('2026-11-04T18:00:00Z'));self.assertEqual(len(h),1)
    def test_prior_does_not_invent_current_season_games(self):
        s=OnlineFeatures(prior={'espn:57':[20,10,-5]});g=dict(game_id='x',home_team='espn:57',away_team='espn:150',tipoff=pd.Timestamp('2026-11-02T17:00Z'),venue_effect=1)
        row=s.row(g,{});self.assertEqual(row['min_history'],0);self.assertEqual(row['rating_edge'],13)
    def test_opening_day_end_to_end_records_three_controls_and_passes(self):
        # Explicit synthetic fixture: no test record reaches real forecast storage.
        t=datetime(2026,11,2,16,tzinfo=timezone.utc)
        frame=pd.DataFrame([dict(game_id='espn:test-only',season=2027,tipoff=pd.Timestamp(t+timedelta(hours=2)),decision_time=pd.Timestamp(t+timedelta(hours=1)),
            home_team='espn:57',away_team='espn:150',home_name='Florida Gators',away_name='Duke Blue Devils',neutral=False,venue_effect=1,
            venue_state='FL',eligible=True,completed=False,time_confirmed=True,observed_at=t.isoformat(),source_sha256='fixture',source_url='https://example.com/fixture')])
        quote=dict(game_id='espn:test-only',line=-3.5,home_price=-110,away_price=-110,bookmaker='test-only',quote_observed_at=t.isoformat(),
            quote_at=t.isoformat(),quote_sha256='fixture',source_url='https://example.com/fixture',source_timing='synthetic test fixture')
        real_save=save
        with tempfile.TemporaryDirectory() as folder,patch.object(runner,'PRIVATE',Path(folder)),patch.object(runner,'now',lambda:t),patch.object(runner,'collect_results',lambda:0),patch.object(runner,'slate',lambda date:(frame,dict(observed_at=t.isoformat(),sha256='fixture'))),patch.object(runner,'refresh_rosters',lambda ids:None),patch.object(runner,'cached_quotes',lambda games,issued:[quote]),patch.object(runner,'coverage',lambda game,cutoff:True),patch.object(runner,'save',lambda r,p:real_save(r,p,clock=lambda:t)):
            result=runner.capture('2026-11-02');self.assertEqual(result['issued'],3)
            rows=[json.loads(p.read_text()) for p in (Path(folder)/'forecasts').glob('*.json')]
            self.assertTrue(all(r['paper_side']=='pass' for r in rows))
            self.assertTrue(all(r['features']['min_history']==0 for r in rows))
            self.assertEqual(len({r['candidate'] for r in rows}),3)
            frame['time_confirmed']=False
            result=runner.capture('2026-11-02');self.assertEqual(result['issued'],0)
            self.assertIsNone(result['previews'][0]['tipoff'])

if __name__=='__main__':unittest.main(verbosity=2)
