"""Auditable NCAA basketball pipeline. Historical sample runs are demonstrations."""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")


def config():
    return json.loads((ROOT / "config.json").read_text())


def fetch(cfg):
    """One bounded public scoreboard request per explicit date; immutable cache."""
    raw = (ROOT / cfg["raw_dir"]).resolve()
    raw.mkdir(parents=True, exist_ok=True)
    manifests = []
    for date in cfg["sample_dates"]:
        if int(date[:4]) >= cfg["holdout_season"]:
            raise ValueError("Holdout acquisition is locked")
        url = ("https://site.api.espn.com/apis/site/v2/sports/basketball/"
               f"mens-college-basketball/scoreboard?dates={date}&groups=50&limit=1000")
        index = raw / f"{date}.manifest.json"
        if index.exists():
            manifest = json.loads(index.read_text())
            if hashlib.sha256((raw / manifest["file"]).read_bytes()).hexdigest() != manifest["sha256"]:
                raise ValueError("Raw snapshot hash mismatch")
        else:
            requested = datetime.now(timezone.utc).isoformat()
            with urlopen(Request(url, headers={"User-Agent": "BasketballResearch/0.1"}), timeout=30) as response:
                blob = response.read()
            retrieved = datetime.now(timezone.utc).isoformat()
            payload = json.loads(blob)
            if len(payload.get("events", [])) >= 1000:
                raise ValueError("Potential truncated response; narrow the date slice")
            digest = hashlib.sha256(blob).hexdigest()
            name = f"{date}-{digest}.json"
            with (raw / name).open("xb") as f:
                f.write(blob)
            manifest = {"source": "ESPN public scoreboard", "url": url, "query_date": date,
                        "requested_at": requested, "retrieved_at": retrieved,
                        "sha256": digest, "file": name,
                        "events": len(payload.get("events", [])),
                        "historical_publication_time": None,
                        "license": "Source data terms unresolved; local research sample only"}
            save_json(index, manifest)
            time.sleep(0.5)
        manifests.append(manifest)
        print(f"{date}: {manifest['events']} events", flush=True)
    save_json(ROOT / "reports/source_manifest.json", manifests)


def normalize(cfg):
    import pandas as pd
    import duckdb
    raw = (ROOT / cfg["raw_dir"]).resolve()
    rows, excluded = [], []
    for date in cfg["sample_dates"]:
        manifest = json.loads((raw / f"{date}.manifest.json").read_text())
        blob = (raw / manifest["file"]).read_bytes()
        if hashlib.sha256(blob).hexdigest() != manifest["sha256"]:
            raise ValueError("Raw snapshot hash mismatch")
        for event in json.loads(blob).get("events", []):
            game_id = f"espn:{event['id']}"
            try:
                comp = event["competitions"][0]
                if not comp["status"]["type"]["completed"]:
                    excluded.append({"game_id": game_id, "reason": "not_completed"})
                    continue
                sides = {c["homeAway"]: c for c in comp["competitors"]}
                home, away = sides["home"], sides["away"]
                hs, aws = int(home["score"]), int(away["score"])
                if hs == aws or min(hs, aws) < 0:
                    raise ValueError("invalid completed score")
                neutral = comp.get("neutralSite")
                if not isinstance(neutral, bool):
                    raise ValueError("neutral-site flag missing")
                tip = pd.Timestamp(event["date"])
                if tip.tzinfo is None:
                    raise ValueError("timezone missing")
                season = int(event["season"]["year"])
                if season >= cfg["holdout_season"]:
                    raise ValueError("holdout encountered")
                rows.append({"game_id": game_id, "season": season, "tipoff": tip,
                             "decision_time": tip - pd.Timedelta(minutes=cfg["prediction_cutoff_minutes"]),
                             "result_available_assumed": tip + pd.Timedelta(hours=cfg["result_lag_hours"]),
                             "home_team": f"espn:{home['team']['id']}",
                             "away_team": f"espn:{away['team']['id']}",
                             "home_name": home["team"]["displayName"], "away_name": away["team"]["displayName"],
                             "home_score": hs, "away_score": aws, "won": int(hs > aws),
                             "margin": hs - aws, "total": hs + aws,
                             "neutral": neutral, "venue_effect": int(not neutral),
                             "season_type": int(event["season"].get("type", 0)),
                             "venue_id": comp.get("venue", {}).get("id"),
                             "overtime_periods": max(int(comp["status"].get("period", 2)) - 2, 0),
                             "division_verified": False, "retrieved_at": manifest["retrieved_at"],
                             "raw_sha256": manifest["sha256"], "source_publication_time": None})
            except (KeyError, ValueError, TypeError) as error:
                excluded.append({"game_id": game_id, "reason": str(error)})
    df = pd.DataFrame(rows).sort_values(["tipoff", "game_id"]).reset_index(drop=True)
    if df.empty or df.game_id.duplicated().any() or (df.home_team == df.away_team).any():
        raise ValueError("empty sample, duplicate games, or identical opponents")
    (ROOT / "data").mkdir(exist_ok=True)
    df.to_parquet(ROOT / "data/games.parquet", index=False)
    with duckdb.connect(str(ROOT / "data/basketball.duckdb")) as con:
        con.execute("CREATE OR REPLACE TABLE games AS SELECT * FROM df")
    save_json(ROOT / "reports/data_audit.json", {
        "games": len(df), "duplicate_game_ids": int(df.game_id.duplicated().sum()),
        "season_counts": {str(k): int(v) for k, v in df.groupby("season").size().items()},
        "neutral_games": int(df.neutral.sum()), "overtime_games": int((df.overtime_periods > 0).sum()),
        "missing_fraction": {k: float(v) for k, v in df.isna().mean().items()},
        "excluded": excluded, "division_status": "all games unverified, group=50 is a source filter only",
        "coverage": "selected dates only; not complete seasons",
        "timing": "revised history; no historical publication/schedule vintages"})
    return df


def features(games, cfg):
    """Replay result publication assumptions, never update a game at its start."""
    import pandas as pd
    ratings = defaultdict(lambda: float(cfg["elo_initial"]))
    counts = defaultdict(int)
    results = games.sort_values(["result_available_assumed", "game_id"]).to_dict("records")
    cursor, rows, current_season = 0, [], None
    for game in games.sort_values(["decision_time", "game_id"]).to_dict("records"):
        def apply(result):
            h, a = result["home_team"], result["away_team"]
            diff = ratings[h] - ratings[a] + cfg["elo_home_advantage"] * result["venue_effect"]
            p = 1 / (1 + 10 ** (-diff / 400))
            update = cfg["elo_k"] * (result["won"] - p)
            ratings[h] += update
            ratings[a] -= update
            counts[h] += 1
            counts[a] += 1
        # Settle preceding-season results before offseason regression.
        if current_season != game["season"]:
            while cursor < len(results) and results[cursor]["season"] < game["season"] and results[cursor]["result_available_assumed"] <= game["decision_time"]:
                apply(results[cursor])
                cursor += 1
            if current_season is not None:
                for team in list(ratings):
                    ratings[team] = cfg["elo_initial"] + cfg["elo_season_carryover"] * (ratings[team] - cfg["elo_initial"])
            current_season = game["season"]
        while cursor < len(results) and results[cursor]["result_available_assumed"] <= game["decision_time"]:
            apply(results[cursor])
            cursor += 1
        h, a = game["home_team"], game["away_team"]
        diff = ratings[h] - ratings[a]
        rows.append({"game_id": game["game_id"], "season": game["season"],
                     "decision_time": game["decision_time"], "venue_effect": game["venue_effect"],
                     "elo_diff": diff, "home_prior_games": counts[h], "away_prior_games": counts[a],
                     "elo_probability": 1 / (1 + 10 ** (-(diff + cfg["elo_home_advantage"] * game["venue_effect"]) / 400)),
                     "latest_result_used": results[cursor - 1]["result_available_assumed"] if cursor else None})
    df = pd.DataFrame(rows)
    known = df.latest_result_used.notna()
    if not (df.loc[known, "latest_result_used"] <= df.loc[known, "decision_time"]).all():
        raise ValueError("future result used")
    return df


def evaluate(games, feats, cfg):
    import numpy as np
    import pandas as pd
    from sklearn.linear_model import LogisticRegression, Ridge
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    df = games.merge(feats, on=["game_id", "season", "decision_time", "venue_effect"], validate="one_to_one")
    predictions, metrics, calibration = [], [], []
    seasons = sorted(df.season.unique())
    for season in seasons[1:]:
        test = df[df.season == season].copy()
        train = df[(df.season < season) & (df.result_available_assumed < test.decision_time.min())].copy()
        if train.empty or train.won.nunique() < 2:
            raise ValueError("training data inadequate")
        if train.tipoff.max() >= test.decision_time.min():
            raise ValueError("chronology violation")
        columns = ["venue_effect", "elo_diff"]
        logistic = make_pipeline(StandardScaler(), LogisticRegression(C=cfg["logistic_c"], max_iter=1000))
        logistic.fit(train[columns], train.won)
        margin_model = make_pipeline(StandardScaler(), Ridge(alpha=cfg["ridge_alpha"]))
        total_model = make_pipeline(StandardScaler(), Ridge(alpha=cfg["ridge_alpha"]))
        margin_model.fit(train[columns], train.margin)
        total_model.fit(train[columns], train.total)
        # Opponent-adjusted regularized least-squares team strengths.
        teams = sorted(set(train.home_team) | set(train.away_team))
        ids = {t: i for i, t in enumerate(teams)}
        def design(frame):
            x = np.zeros((len(frame), len(teams) + 1))
            for i, g in enumerate(frame.to_dict("records")):
                if g["home_team"] in ids:
                    x[i, ids[g["home_team"]]] = 1
                if g["away_team"] in ids:
                    x[i, ids[g["away_team"]]] = -1
                x[i, -1] = g["venue_effect"]
            return x
        rating_model = Ridge(alpha=cfg["ridge_alpha"], fit_intercept=False).fit(design(train), train.margin)
        rating_margin = rating_model.predict(design(test))
        # Scale from training residuals only; normal residual assumption is unvalidated.
        residual_scale = max(float(np.std(train.margin - rating_model.predict(design(train)))), 1.0)
        from scipy.special import ndtr
        probs = {"constant": np.full(len(test), train.won.mean()),
                 "venue": np.array([(train.loc[train.venue_effect == v, "won"].sum() + 1) /
                                    (int((train.venue_effect == v).sum()) + 2) for v in test.venue_effect]),
                 "elo": test.elo_probability.to_numpy(),
                 "logistic_elo": logistic.predict_proba(test[columns])[:, 1],
                 "margin_ratings": ndtr(rating_margin / residual_scale)}
        pm, pt = margin_model.predict(test[columns]), total_model.predict(test[columns])
        y = test.won.to_numpy()
        for model, p in probs.items():
            p = np.clip(p, 1e-6, 1 - 1e-6)
            metrics.append({"season": int(season), "model": model, "n": len(test), "train_n": len(train),
                            "log_loss": float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))),
                            "brier": float(np.mean((p - y) ** 2)), "accuracy": float(np.mean((p >= .5) == y))})
            bins = np.minimum((p * cfg["calibration_bins"]).astype(int), cfg["calibration_bins"] - 1)
            for b in range(cfg["calibration_bins"]):
                mask = bins == b
                calibration.append({"season": int(season), "model": model, "bin": b, "n": int(mask.sum()),
                                    "mean_probability": float(p[mask].mean()) if mask.any() else None,
                                    "observed_win_rate": float(y[mask].mean()) if mask.any() else None})
            for i, g in enumerate(test.to_dict("records")):
                predictions.append({"game_id": g["game_id"], "season": int(season), "model": model,
                                    "home_team": g["home_team"], "away_team": g["away_team"],
                                    "tipoff": g["tipoff"], "reconstructed_issue_time": g["decision_time"],
                                    "actual_issue_time": None, "win_probability": float(p[i]), "won": int(y[i]),
                                    "expected_margin": float(rating_margin[i] if model == "margin_ratings" else pm[i]),
                                    "expected_total": float(pt[i]), "model_version": "demo-v1",
                                    "interval_lower": None, "interval_upper": None,
                                    "data_freshness": "historical reconstructed sample",
                                    "missing_data_flags": "partial_history;division_unknown;publication_time_unknown;intervals_unavailable"})
        for target, pred in [("margin", pm), ("total", pt), ("margin_ratings", rating_margin)]:
            actual = test.margin.to_numpy() if "margin" in target else test.total.to_numpy()
            error = pred - actual
            metrics.append({"season": int(season), "model": f"ridge_{target}", "n": len(test), "train_n": len(train),
                            "mae": float(np.abs(error).mean()), "rmse": float(np.sqrt(np.mean(error ** 2)))})
    pd.DataFrame(metrics).to_csv(ROOT / "reports/results.csv", index=False)
    pd.DataFrame(predictions).to_csv(ROOT / "reports/predictions.csv", index=False)
    save_json(ROOT / "reports/calibration.json", {"verdict": "manual-review-required",
               "reason": "selected-date sample, sparse bins and unverified historical timing; no reliability claim", "bins": calibration})
    save_json(ROOT / "reports/experiment.json", {"experiment": "pipeline-smoke-v1", "config": cfg,
               "hypothesis": "ingestion and matched chronological evaluation run reproducibly",
               "holdout_scored": False, "leakage_verdict": "REVIEW REQUIRED",
               "decision": "No model promotion. Audit full-season coverage and historical timing next.",
               "training": "parameters frozen per season; Elo state updates after assumed availability",
               "uncertainty": "not estimated; temporal/shared-team dependence needs full data"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["fetch", "run"])
    args = parser.parse_args()
    cfg = config()
    if args.command == "fetch":
        fetch(cfg)
    else:
        games = normalize(cfg)
        feats = features(games, cfg)
        feats.to_parquet(ROOT / "data/features.parquet", index=False)
        evaluate(games, feats, cfg)
        print(f"Audited {len(games)} real games; pipeline demonstration complete.")


if __name__ == "__main__":
    main()
