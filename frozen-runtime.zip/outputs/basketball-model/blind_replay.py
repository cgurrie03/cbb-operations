"""Result-hidden replay: build pregame inputs, isolated prediction, then grading."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from stage2_models import CFG,fit_daily,loss

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'blind-replay-20261014'
SLATE=['game_id','season','tipoff','decision_time','home_team','away_team','neutral','venue_effect']
FEATURES=['game_id','season','decision_time','rating_cutoff','latest_result_used','history_n','venue_effect','eff_margin','eff_total','expected_pace','strength_margin']
INPUT=['venue_effect','eff_margin','eff_total','expected_pace']

def dump(path,value):path.write_text(json.dumps(value,indent=2,default=str,allow_nan=False),encoding='utf8')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

class ResultBroker:
    def __init__(self,results,lag):
        self.__results=results.copy()
        self.__results['release']=self.__results.tipoff+pd.Timedelta(hours=lag)
    def available(self,cutoff,season):
        h=self.__results[(self.__results.season==season)&(self.__results.release<=cutoff)].copy()
        assert h.empty or (h.tipoff<cutoff).all()
        return h

def emit_batch(batch,history,priors):
    """No target, score or box-score columns accepted on a prediction slate."""
    assert set(batch.columns)==set(SLATE),'Forbidden columns on pregame slate'
    cutoff=batch.decision_time.min()
    assert history.empty or history.release.max()<=cutoff
    assert set(batch.game_id).isdisjoint(set(history.game_id))
    teams=sorted(set(priors)|set(batch.home_team)|set(batch.away_team)|set(history.home_team)|set(history.away_team))
    ids,off,defense,tempo,strength,base,pace,delta=fit_daily(history,teams,priors)
    rows=[]
    for g in batch.itertuples(index=False):
        h,a=ids[g.home_team],ids[g.away_team]
        q=float(np.clip(pace+tempo[h]+tempo[a],40,100))
        he=base+off[h]+defense[a]+CFG['home_eff']*g.venue_effect
        ae=base+off[a]+defense[h]-CFG['home_eff']*g.venue_effect
        rows.append(dict(game_id=g.game_id,season=g.season,decision_time=g.decision_time,rating_cutoff=cutoff,
                         latest_result_used=history.release.max() if len(history) else pd.NaT,history_n=len(history),
                         venue_effect=g.venue_effect,eff_margin=(he-ae)*q/100,eff_total=(he+ae)*q/100,
                         expected_pace=q,strength_margin=strength[h]-strength[a]+CFG['home_margin']*g.venue_effect))
    return pd.DataFrame(rows)[FEATURES]

def build(games,lag):
    broker=ResultBroker(games,lag);slates=games[SLATE].sort_values(['decision_time','game_id'])
    priors={};allrows=[];tests=[]
    for season,frame in slates.groupby('season',sort=True):
        prior={t:[v*CFG['carryover'] for v in values] for t,values in priors.items()}
        for day,batch in frame.groupby(frame.decision_time.dt.strftime('%Y-%m-%d'),sort=True):
            cutoff=batch.decision_time.min();history=broker.available(cutoff,season)
            out=emit_batch(batch,history,prior);allrows.append(out)
            # Poison every unavailable result/statistic, including this slate's outcomes.
            if season in [2023,2024,2025] and day in {f'{season}-02-01',f'{season-1}-11-07',f'{season-1}-11-06',f'{season-1}-11-04'}:
                poisoned=games[games.season==season].copy();unavailable=poisoned.tipoff+pd.Timedelta(hours=lag)>cutoff
                poisoned.loc[unavailable,'margin']=-999.;poisoned.loc[unavailable,'won']=0
                poisoned.loc[unavailable,'home_eff']=250.;poisoned.loc[unavailable,'away_eff']=10.;poisoned.loc[unavailable,'pace40']=100.
                other=emit_batch(batch,ResultBroker(poisoned,lag).available(cutoff,season),prior)
                pd.testing.assert_frame_equal(out,other,check_exact=True)
                tests.append({'test':'unavailable_result_and_stat_poison','date':day,'season':int(season),'lag_hours':lag,'rows':len(batch),'pass':True})
        settled=broker.available(frame.decision_time.max()+pd.Timedelta(days=3),season)
        teams=sorted(set(prior)|set(settled.home_team)|set(settled.away_team))
        ids,o,d,t,m,*_=fit_daily(settled,teams,prior)
        priors={team:[float(o[i]),float(d[i]),float(t[i]),float(m[i])] for team,i in ids.items()}
        print(f'lag={lag} features season {season}: {len(frame)}',flush=True)
    f=pd.concat(allrows,ignore_index=True)
    assert f.game_id.is_unique
    assert (f.latest_result_used.dropna()<=f.loc[f.latest_result_used.notna(),'rating_cutoff']).all()
    assert (f.rating_cutoff<=f.decision_time).all()
    assert not set(['won','margin','total','home_score','away_score']).intersection(f.columns)
    return f,tests

def predict(lag):
    # This process opens only pregame test features and pre-2023 training targets.
    train=pd.read_parquet(OUT/f'train-{lag}.parquet');test=pd.read_parquet(OUT/f'pregame-{lag}.parquet')
    assert train.season.max()==2022 and test.season.min()==2023
    assert set(test.columns)==set(FEATURES)
    assert train.release.max()<test.decision_time.min()
    classifier=make_pipeline(StandardScaler(),LogisticRegression(C=CFG['logistic_C'],max_iter=1000))
    classifier.fit(train[['venue_effect','eff_margin']],train.won)
    result=test.copy();result['win_probability']=classifier.predict_proba(test[['venue_effect','eff_margin']])[:,1]
    for target,cols in [('margin',['eff_margin','venue_effect']),('total',['eff_total','expected_pace','venue_effect'])]:
        model=make_pipeline(StandardScaler(),Ridge(alpha=CFG['regression_alpha']))
        model.fit(train[cols],train[target]);result['predicted_'+target]=model.predict(test[cols])
    venue=train.groupby('venue_effect').won.agg(['sum','count'])
    result['baseline_probability']=result.venue_effect.map((venue['sum']+1)/(venue['count']+2))
    assert result[['win_probability','predicted_margin','predicted_total']].notna().all().all()
    result.to_parquet(OUT/f'predictions-{lag}.parquet',index=False)
    dump(OUT/f'prediction-manifest-{lag}.json',{'code':sha(Path(__file__)),'prediction_sha256':sha(OUT/f'predictions-{lag}.parquet'),
         'test_input_sha256':sha(OUT/f'pregame-{lag}.parquet'),'training_input_sha256':sha(OUT/f'train-{lag}.parquet'),
         'test_input_columns':list(test.columns),'training_last_season':int(train.season.max()),'frozen_through_season':2025,
         'created_at':datetime.now(timezone.utc).isoformat(),'rows':len(result),'process_inputs':['training data <=2022','pregame test features only']})

def grade():
    actual=pd.read_parquet(ROOT/'stage2/games.parquet');actual=actual[actual.season.between(2023,2025)]
    rows=[]
    for lag in [24,6]:
        path=OUT/f'predictions-{lag}.parquet';before=sha(path)
        p=pd.read_parquet(path).merge(actual[['game_id','won','margin','total','home_name','away_name','tipoff','home_team','away_team','neutral']],on='game_id',validate='one_to_one')
        assert len(p)==len(actual)
        for season,g in [('all',p),*list(p.groupby('season'))]:
            y=g.won.to_numpy();prob=g.win_probability.to_numpy()
            r=dict(lag_hours=lag,season=season,n=len(g),winner_correct=int(((prob>=.5)==y).sum()),winner_accuracy=float(((prob>=.5)==y).mean()),
                   log_loss=float(loss(y,prob).mean()),brier=float(np.mean((prob-y)**2)),baseline_log_loss=float(loss(y,g.baseline_probability.to_numpy()).mean()))
            for target in ['margin','total']:
                e=g['predicted_'+target]-g[target];r[target+'_mae']=float(e.abs().mean());r[target+'_rmse']=float(np.sqrt(np.mean(e**2)));r[target+'_bias']=float(e.mean())
            rows.append(r)
        p.to_parquet(OUT/f'graded-{lag}.parquet',index=False)
        assert sha(path)==before
    pd.DataFrame(rows).to_csv(OUT/'model_metrics.csv',index=False)

def main():
    OUT.mkdir(exist_ok=False)
    g=pd.read_parquet(ROOT/'stage2/games.parquet')
    assert g.season.max()==2025
    dump(OUT/'pre_run.json',{'id':'20261014-result-hidden-v1','created_at':datetime.now(timezone.utc).isoformat(),
         'charter_sha256':sha(ROOT/'BLIND_REPLAY_CHARTER.md'),'games_sha256':sha(ROOT/'stage2/games.parquet'),
         'code_sha256':sha(Path(__file__)),'config':CFG,'primary_lag_hours':24,'sensitivity_lag_hours':6,
         'train_seasons':[2016,2022],'test_seasons':[2023,2025],'primary_metric':'margin_mae',
         'selection_warning':'retrospective development replay; prior model selection saw these seasons',
         'status':'planned','seed':137,'command':'python blind_replay.py'})
    tests=[]
    for lag in [24,6]:
        f,t=build(g,lag);tests.extend(t)
        f[f.season.between(2023,2025)].to_parquet(OUT/f'pregame-{lag}.parquet',index=False)
        tr=f[f.season<=2022].merge(g[['game_id','won','margin','total','tipoff']],on='game_id',validate='one_to_one')
        tr['release']=tr.tipoff+pd.Timedelta(hours=lag)
        tr.to_parquet(OUT/f'train-{lag}.parquet',index=False)
        subprocess.run([sys.executable,str(Path(__file__)),'--predict',str(lag)],check=True)
    grade();dump(OUT/'integrity_checks.json',{'poison_tests':tests,'cutoff_invariants':True,'no_labels_in_test_input':True,'isolated_prediction_process':True,'prediction_hash_unchanged_after_grading':True,'verdict':'REVIEW REQUIRED: original source publication times and prior selection remain unresolved'})
    print(pd.read_csv(OUT/'model_metrics.csv').to_string(index=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--predict',type=int);args=parser.parse_args()
    if args.predict:predict(args.predict)
    else:main()
