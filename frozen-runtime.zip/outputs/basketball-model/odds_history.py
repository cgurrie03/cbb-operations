"""Normalize protected collector snapshots for point-in-time model evaluation.

This module never reads the provider key or makes an API call.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math

ROOT=Path(__file__).resolve().parents[2]
HISTORY=ROOT/'work/odds-snapshots/normalized'
def stamp(value):
    try:
        time=datetime.fromisoformat(value.replace('Z','+00:00'))
        return time.astimezone(timezone.utc) if time.tzinfo else None
    except (ValueError,AttributeError,TypeError):return None
def decimal(price):return 1+price/100 if price>0 else 1+100/abs(price)
def normalize(info):
    observed=stamp(info.get('collectedAt'))
    if not observed:raise ValueError('Missing collection time')
    rows=[]
    for event in info.get('events',[]):
        tip=stamp(event.get('commence_time'))
        if not tip:continue
        for book in event.get('bookmakers',[]):
            for market in book.get('markets',[]):
                kind=market.get('key');updated=stamp(market.get('last_update') or book.get('last_update'))
                if kind not in ['h2h','spreads','totals'] or not updated or updated>observed:continue
                for outcome in market.get('outcomes',[]):
                    price=outcome.get('price');point=outcome.get('point')
                    if not isinstance(price,(int,float)) or not math.isfinite(price) or abs(price)<100:continue
                    if kind!='h2h' and (not isinstance(point,(int,float)) or not math.isfinite(point)):continue
                    name=outcome.get('name');side=('over' if name=='Over' else 'under' if name=='Under' else None) if kind=='totals' else ('home' if name==event.get('home_team') else 'away' if name==event.get('away_team') else None)
                    if side is None:continue
                    rows.append(dict(event_id=event['id'],home=event['home_team'],away=event['away_team'],tipoff=tip.isoformat(),
                        observed_at=observed.isoformat(),quote_at=updated.isoformat(),book=book['key'],book_name=book['title'],market=kind,
                        selection=side,point=point if kind!='h2h' else None,price=price,decimal_price=decimal(price),source_sha256=info['sha256']))
    return rows
def record(info):
    HISTORY.mkdir(parents=True,exist_ok=True)
    rows=normalize(info);name=stamp(info['collectedAt']).strftime('%Y%m%dT%H%M%S')+'-'+info['sha256']+'.json'
    path=HISTORY/name
    payload=json.dumps({'collected_at':info['collectedAt'],'source_sha256':info['sha256'],'rows':rows},separators=(',',':')).encode()
    if path.exists():
        if path.read_bytes()!=payload:raise ValueError('Immutable normalized snapshot differs')
    else:path.write_bytes(payload)
    return rows
def history_for(event_id):
    rows=[]
    for path in sorted(HISTORY.glob('*.json')):
        rows.extend(r for r in json.loads(path.read_text())['rows'] if r['event_id']==event_id)
    return rows
def before_cutoff(rows,cutoff,max_age_hours=3):
    """Both observation and provider update must precede the decision."""
    cutoff=stamp(cutoff) if isinstance(cutoff,str) else cutoff
    eligible=[r for r in rows if stamp(r['observed_at'])<=cutoff and stamp(r['quote_at'])<=cutoff
              and 0<=(cutoff-stamp(r['quote_at'])).total_seconds()<=max_age_hours*3600
              and cutoff<stamp(r['tipoff'])]
    latest={}
    for row in sorted(eligible,key=lambda r:(r['observed_at'],r['quote_at'])):
        latest[(row['event_id'],row['book'],row['market'],row['selection'])]=row
    return list(latest.values())
def sync_existing():
    folder=ROOT/'work/odds-snapshots';n=0
    for path in folder.glob('????????T??????Z-*.json'):
        payload=path.read_bytes();events=json.loads(payload)
        metadata=path.with_suffix('.metadata.json')
        if metadata.exists():observed=json.loads(metadata.read_text())['collectedAt']
        elif not events:
            # Legacy empty snapshots contain no quote whose availability could be
            # misrepresented. Nonempty responses need an actual observation time.
            observed=datetime.strptime(path.name[:16],'%Y%m%dT%H%M%SZ').replace(tzinfo=timezone.utc).isoformat()
        else:continue
        record({'collectedAt':observed,'sha256':hashlib.sha256(payload).hexdigest(),'events':events});n+=1
    print(json.dumps({'normalized_snapshots':n,'network_requests':0}))
if __name__=='__main__':sync_existing()
