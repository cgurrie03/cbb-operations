"""Spread-first, market-aware candidates; isolated development/prediction/grading stages."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,re,unicodedata,ast
import numpy as np
import pandas as pd
import joblib
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge
from confidence_check import probabilities,summary as bucket_summary

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'spread-v3-20261017'
OLD=ROOT/'blind-replay-20261014'
RAW=ROOT.parents[1]/'work/basketball-seasons-raw'
LINES=ROOT.parents[1]/'work/blind-replay-source-probe/spreads-full.csv'
FEATURES=['raw_edge','line','absolute_line','venue_effect','expected_pace']
CANDIDATES=['market_50','historical_rate','cover_logistic_raw','cover_logistic_calibrated','market_residual_ridge']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2,default=str,allow_nan=False),encoding='utf-8')
def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower())
def old_features():
    cols=['game_id','season','decision_time','rating_cutoff','latest_result_used','eff_margin','eff_total','expected_pace','strength_margin','venue_effect']
    return pd.concat([pd.read_parquet(OLD/'train-24.parquet')[cols],pd.read_parquet(OLD/'pregame-24.parquet')[cols]],ignore_index=True)
def game_metadata():
    cols=['game_id','season','tipoff','decision_time','home_team','away_team','home_name','away_name','neutral']
    g=pd.read_parquet(ROOT/'stage2/games.parquet',columns=cols)
    if (OUT/'games-2026.parquet').exists():g=pd.concat([g,pd.read_parquet(OUT/'games-2026.parquet',columns=cols)],ignore_index=True)
    return g
def alias_map(games):
    aliases={}
    for season in sorted(games.season.unique()):
        p=OUT/'raw/team_crosswalk_2026.parquet' if season==2026 else next(RAW.glob(f'team_crosswalk_{season}-*.parquet'),None)
        if p and p.exists():
            for row in pd.read_parquet(p).to_dict('records'):
                tid='espn:'+str(int(row['espn_team_id']))
                for key in ['espn_display_name','fox_team_name','espn_location','bart_team','kp_team']:
                    value=row.get(key)
                    if isinstance(value,str):aliases.setdefault((int(season),norm(value)),set()).add(tid)
    for g in games.itertuples(index=False):
        for name,tid in [(g.home_name,g.home_team),(g.away_name,g.away_team)]:aliases.setdefault((g.season,norm(name)),set()).add(tid)
    tree=ast.parse((ROOT/'replay_market.py').read_text(encoding='utf-8'))
    explicit=next(ast.literal_eval(n.value) for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='explicit' for t in n.targets))
    return aliases,explicit
def resolve_quotes(games,raw=None):
    raw=pd.read_csv(LINES) if raw is None else raw.copy()
    raw=raw[raw.season.isin(games.season.unique())].copy()
    aliases,explicit=alias_map(games);audit=[]
    def resolve(season,name,canonical):
        for candidate,method in [(name,'exact name'),(re.sub(r' St (?=\w)',' State ',name),'State abbreviation'),(explicit.get(name,''),'explicit alias'),(canonical,'source canonical')]:
            ids=aliases.get((season,norm(candidate)),set())
            if len(ids)==1:return next(iter(ids)),method
        return None,'unresolved'
    for side in ['home','away']:
        lookup={}
        for season,name,canonical in raw[['season',side+'_team',side+'_team_canonical']].drop_duplicates().itertuples(index=False,name=None):
            tid,method=resolve(season,name,canonical);lookup[(season,name)]=tid;audit.append({'season':season,'name':name,'canonical':canonical,'team_id':tid,'method':method})
        raw[side+'_id']=[lookup[(s,n)] for s,n in zip(raw.season,raw[side+'_team'])]
    raw['quote_time']=pd.to_datetime(raw.timestamp,utc=True,errors='coerce');raw['source_tipoff']=pd.to_datetime(raw.commence_time,utc=True,errors='coerce')
    raw['date']=raw.source_tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    meta=games.copy();meta['date']=meta.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    rows=[];rejections=[]
    for orientation in ['same','reversed']:
        left=raw.copy()
        if orientation=='reversed':left['home_id'],left['away_id']=raw.away_id,raw.home_id
        x=left.merge(meta,left_on=['season','home_id','away_id','date'],right_on=['season','home_team','away_team','date'],validate='many_to_one',suffixes=('_source','_game'))
        x['line']=x.spread*(-1 if orientation=='reversed' else 1)
        x['quote_age_minutes']=(x.tipoff-x.quote_time).dt.total_seconds()/60
        x['tipoff_difference_minutes']=(x.tipoff-x.source_tipoff).abs().dt.total_seconds()/60
        good=x.quote_time.notna()&x.line.abs().lt(80)&x.quote_age_minutes.between(0,15)&x.tipoff_difference_minutes.le(5)
        x['orientation']=orientation
        rejections.append(x.loc[~good,['game_id','season','bookmaker','quote_time','tipoff','quote_age_minutes','tipoff_difference_minutes','line']])
        rows.append(x.loc[good,['game_id','season','event_id','bookmaker','quote_time','source_tipoff','tipoff','decision_time','line','orientation','quote_age_minutes','tipoff_difference_minutes']])
    q=pd.concat(rows,ignore_index=True).drop_duplicates();conflict=q.groupby(['game_id','bookmaker','quote_time']).line.transform('nunique')>1
    q=q[~conflict].sort_values(['quote_time','event_id']).drop_duplicates(['game_id','bookmaker'],keep='last')
    assert not q.duplicated(['game_id','bookmaker']).any()
    return q,pd.DataFrame(audit).drop_duplicates(),pd.concat(rejections,ignore_index=True)
def inputs(meta,features,quotes):
    f=features.rename(columns={'decision_time':'feature_decision_time'})
    x=quotes.merge(f.drop(columns=['season']),on='game_id',validate='many_to_one').merge(meta[['game_id','home_name','away_name']],on='game_id',validate='many_to_one')
    x['raw_edge']=x.eff_margin+x.line;x['absolute_line']=x.line.abs()
    assert (x.feature_decision_time<=x.quote_time).all()
    known=x.latest_result_used.notna();assert (x.loc[known,'latest_result_used']<=x.loc[known,'rating_cutoff']).all()
    assert not set(['margin','won','total','home_score','away_score']).intersection(x.columns)
    return x
def labels_through(year):return pd.read_parquet(ROOT/'stage2/games.parquet',columns=['game_id','season','margin'],filters=[('season','<=',year)])
def attach(x,labels):
    y=x.merge(labels.drop(columns=['season']),on='game_id',validate='one_to_one')
    y['home_delta']=y.margin+y.line;y['push']=np.isclose(y.home_delta,0,atol=1e-10,rtol=0);y['home_cover']=(y.home_delta>0).astype(int)
    return y
def fit_candidates(train,cal):
    assert train.season.max()<cal.season.min() and train.tipoff.max()+pd.Timedelta(hours=24)<cal.quote_time.min()
    t=train[~train.push];c=cal[~cal.push]
    if len(t)<1000 or len(c)<200:raise ValueError('Insufficient training/calibration sample')
    log=make_pipeline(StandardScaler(),LogisticRegression(C=1.,max_iter=1000)).fit(t[FEATURES],t.home_cover)
    sigmoid=LogisticRegression(C=1e6,max_iter=1000).fit(log.decision_function(c[FEATURES]).reshape(-1,1),c.home_cover)
    ridge=make_pipeline(StandardScaler(),Ridge(alpha=20.)).fit(train[FEATURES],train.home_delta)
    residual=cal.home_delta.to_numpy()-ridge.predict(cal[FEATURES])
    integer=np.isclose(train.line,np.round(train.line),rtol=0,atol=1e-10)
    push_rate=(int(train.loc[integer,'push'].sum())+1)/(int(integer.sum())+2)
    return {'logistic':log,'sigmoid':sigmoid,'ridge':ridge,'residual':residual,'rate':(int(t.home_cover.sum())+1)/(len(t)+2),'push_rate':push_rate}
def predict_candidates(models,x):
    assert not set(['margin','home_delta','home_cover','push','won','total']).intersection(x.columns)
    rows=[];raw=models['logistic'].predict_proba(x[FEATURES])[:,1]
    calibrated=models['sigmoid'].predict_proba(models['logistic'].decision_function(x[FEATURES]).reshape(-1,1))[:,1]
    correction=models['ridge'].predict(x[FEATURES]);point=-x.line.to_numpy()+correction
    home,away,ridge_push=probabilities(point,x.line.to_numpy(),models['residual'])
    generic_push=np.where(np.isclose(x.line,np.round(x.line),rtol=0,atol=1e-10),models['push_rate'],0)
    for name,p in [('market_50',np.full(len(x),.5)),('historical_rate',np.full(len(x),models['rate'])),('cover_logistic_raw',raw),('cover_logistic_calibrated',calibrated),('market_residual_ridge',home)]:
        out=x[['game_id','season','home_name','away_name','event_id','bookmaker','line','quote_time','tipoff','feature_decision_time','quote_age_minutes','tipoff_difference_minutes']].copy()
        out['candidate']=name;out['home_cover_probability']=np.clip(p,1e-6,1-1e-6)
        out['push_probability']=ridge_push if name=='market_residual_ridge' else generic_push
        out['home_win_probability']=(1-out.push_probability)*out.home_cover_probability
        out['away_win_probability']=(1-out.push_probability)*(1-out.home_cover_probability)
        out['selected_side']=np.where(p>.5+1e-12,'home',np.where(p<.5-1e-12,'away','pass'))
        out['selected_cover_probability']=np.maximum(out.home_cover_probability,1-out.home_cover_probability)
        out['predicted_margin']=point if name=='market_residual_ridge' else -x.line.to_numpy() if name=='market_50' else np.nan
        assert np.allclose(out.home_win_probability+out.away_win_probability+out.push_probability,1)
        rows.append(out)
    return pd.concat(rows,ignore_index=True)
def metric(pred,labels):
    rows=[];x=pred.merge(labels.drop(columns=['season']),on='game_id',validate='many_to_one');d=x.margin+x.line;push=np.isclose(d,0,atol=1e-10,rtol=0)
    for (candidate,season),g in x[~push].assign(y=(d[~push]>0).astype(int)).groupby(['candidate','season']):
        p=np.clip(g.home_cover_probability.to_numpy(),1e-6,1-1e-6);y=g.y.to_numpy()
        rows.append({'candidate':candidate,'season':int(season),'n':len(g),'log_loss':float(np.mean(-y*np.log(p)-(1-y)*np.log1p(-p))),'brier':float(np.mean((p-y)**2))})
    return pd.DataFrame(rows)
def develop():
    if (OUT/'selection.json').exists():raise RuntimeError('Frozen selection exists; use a new experiment version')
    meta=game_metadata();q,alias,reject=resolve_quotes(meta[meta.season.between(2021,2025)])
    q.to_parquet(OUT/'timestamped-quotes-through-2025.parquet',index=False);alias.to_csv(OUT/'alias-audit-through-2025.csv',index=False);reject.to_csv(OUT/'rejected-quotes-through-2025.csv',index=False)
    frame=inputs(meta,old_features(),q[q.bookmaker=='draftkings'])
    frame.to_parquet(OUT/'pregame-through-2025.parquet',index=False)
    labels=labels_through(2024);dev=attach(frame[frame.season<=2024],labels);predictions=[];folds=[]
    for test_year in [2023,2024]:
        train=dev[dev.season<=test_year-2];cal=dev[dev.season==test_year-1]
        test=frame[frame.season==test_year]
        models=fit_candidates(train,cal);prediction=predict_candidates(models,test);predictions.append(prediction)
        folds.append({'test_season':test_year,'fit_seasons':sorted(map(int,train.season.unique())),'calibration_season':test_year-1,'fit_n':len(train),'calibration_n':len(cal),'test_n':len(test)})
    p=pd.concat(predictions,ignore_index=True);p.to_parquet(OUT/'development-predictions.parquet',index=False)
    scores=metric(p,labels);scores.to_csv(OUT/'development-metrics.csv',index=False)
    pivot=scores.pivot(index='candidate',columns='season',values='log_loss');base=pivot.loc['market_50']
    eligible=[c for c in CANDIDATES[1:] if (pivot.loc[c]<base).all() and scores[scores.candidate==c].n.min()>=200]
    chosen=min(eligible,key=lambda c:pivot.loc[c].mean()) if eligible else 'market_50'
    if chosen!='market_50' and base.mean()-pivot.loc[chosen].mean()<.001:chosen='market_50'
    final=fit_candidates(dev[dev.season<=2023],dev[dev.season==2024]);joblib.dump(final,OUT/'frozen-models.joblib')
    dump(OUT/'selection.json',{'created_at':datetime.now(timezone.utc).isoformat(),'selected_candidate':chosen,'eligible_candidates':eligible,'folds':folds,'selection_metric':'mean development log loss; must beat market in both folds; 0.001 simplicity margin','test_seasons':[2025,2026],'final_fit_seasons':[2021,2022,2023],'calibration_season':2024,'2026_outcomes_acquired':False,'charter_sha256':sha(OUT/'CHARTER.md'),'model_sha256':sha(OUT/'frozen-models.joblib'),'source_code_sha256':sha(__file__),'line_source_sha256':sha(LINES),'development_metrics':scores.to_dict('records')})
    print(scores.to_string(index=False));print('Frozen selection:',chosen,flush=True)
def final_predict():
    if (OUT/'final-predictions.parquet').exists():raise RuntimeError('Refusing to overwrite final predictions')
    selection=json.loads((OUT/'selection.json').read_text());assert sha(OUT/'frozen-models.joblib')==selection['model_sha256']
    models=joblib.load(OUT/'frozen-models.joblib')
    meta=game_metadata();q,alias,reject=resolve_quotes(meta[meta.season.between(2025,2026)])
    q.to_parquet(OUT/'timestamped-final-quotes.parquet',index=False);alias.to_csv(OUT/'alias-audit-final.csv',index=False);reject.to_csv(OUT/'rejected-quotes-final.csv',index=False)
    features=pd.concat([old_features(),pd.read_parquet(OUT/'features-2026.parquet')],ignore_index=True)
    frame=inputs(meta,features,q[q.bookmaker=='draftkings']);frame.to_parquet(OUT/'final-pregame-inputs.parquet',index=False)
    pred=predict_candidates(models,frame)
    # Original frozen core point baseline is fitted on pre-2023 targets only.
    tr=pd.read_parquet(OLD/'train-24.parquet');core=make_pipeline(StandardScaler(),Ridge(alpha=20.)).fit(tr[['eff_margin','venue_effect']],tr.margin)
    old=pred[pred.candidate=='market_50'].copy();point=core.predict(frame[['eff_margin','venue_effect']]);old['candidate']='original_core';old['predicted_margin']=point
    # Diagnostic probability mapping is the already-frozen earlier residual map,
    # not a winner probability or a calibrated production spread probability.
    residual=pd.read_parquet(ROOT/'confidence-check-20261017/earlier-heldout-residuals.parquet').residual.to_numpy()
    h,a,push=probabilities(point,frame.line.to_numpy(),residual);old['home_cover_probability']=h;old['push_probability']=push
    edge=point+frame.line.to_numpy();old['selected_side']=np.where(edge>0,'home',np.where(edge<0,'away','pass'))
    old['selected_cover_probability']=np.where(edge>0,h,a);old['home_win_probability']=h*(1-push);old['away_win_probability']=a*(1-push)
    pred=pd.concat([pred,old],ignore_index=True);pred['is_selected']=pred.candidate.eq(selection['selected_candidate']);pred['market']='spreads';pred['model_version']='spread-v3-near-tipoff-research';pred['price_available']=False
    pred.to_parquet(OUT/'final-predictions.parquet',index=False)
    dump(OUT/'final-prediction-manifest.json',{'created_at':datetime.now(timezone.utc).isoformat(),'predictions_sha256':sha(OUT/'final-predictions.parquet'),'inputs_sha256':sha(OUT/'final-pregame-inputs.parquet'),'selection_sha256':sha(OUT/'selection.json'),'source_code_sha256':sha(__file__),'no_final_outcomes_in_predictor':True,'selected_candidate':selection['selected_candidate'],'games_by_season':{str(y):int(len(g)) for y,g in frame.groupby('season')},'latest_quote_age_minutes':float(frame.quote_age_minutes.max())})
    print('Final predictions saved before grading:',len(frame),'games',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['develop','predict']);args=p.parse_args();{'develop':develop,'predict':final_predict}[args.stage]()
