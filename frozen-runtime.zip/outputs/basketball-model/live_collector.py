"""Capture actual future-game schedule observations and timestamped warning inputs."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
from urllib.parse import urlencode
from zoneinfo import ZoneInfo
from acquire_seasons import request, ROOT
from stage2_data import write_json
from availability import warnings_for_game


def collect(date=None):
    now=datetime.now(timezone.utc)
    today=now.astimezone(ZoneInfo('America/New_York')).date()
    date=date or today.strftime('%Y%m%d')
    requested_day=datetime.strptime(date,'%Y%m%d').date()
    if requested_day<today: raise ValueError('Live collector does not acquire historical game data')
    url='https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/scoreboard?'+urlencode({'dates':date,'groups':50,'limit':1000})
    blob=request(url)
    observed=datetime.now(timezone.utc)
    payload=json.loads(blob)
    if len(payload.get('events',[]))>=1000: raise ValueError('Potential truncation')
    out=ROOT/'stage2/live'
    out.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(blob).hexdigest()
    stamp=observed.strftime('%Y%m%dT%H%M%S%fZ')
    rawname=f'{stamp}-{digest}.json'
    with (out/rawname).open('xb') as f: f.write(blob)
    normalized=out/'availability_reports.json'
    reports=json.loads(normalized.read_text()) if normalized.exists() else []
    slate=[]; excluded=[]
    for event in payload.get('events',[]):
        comp=event['competitions'][0]
        tip=datetime.fromisoformat(event['date'].replace('Z','+00:00'))
        if event['season']['year']<=2026:
            excluded.append({'game_id':event['id'],'reason':'holdout_or_historical_season'})
            continue
        if tip<=observed or comp['status']['type']['completed']:
            excluded.append({'game_id':event['id'],'reason':'started_or_completed'})
            continue
        cutoff=tip-timedelta(minutes=60)
        sides={c['homeAway']:c for c in comp['competitors']}
        gid='espn:'+event['id']
        slate.append({'game_id':gid,'season':event['season']['year'],'tipoff':tip.isoformat(),
                      'prediction_cutoff':cutoff.isoformat(),'observed_at':observed.isoformat(),
                      'home_team':'espn:'+sides['home']['team']['id'],'away_team':'espn:'+sides['away']['team']['id'],
                      'home_name':sides['home']['team']['displayName'],'away_name':sides['away']['team']['displayName'],
                      'neutral':comp.get('neutralSite'),'snapshot_before_cutoff':observed<=cutoff,
                      'division_verified':False,'eligibility_status':'season membership not yet cross-checked for live slate',
                      'warning_state':warnings_for_game(gid,min(observed,cutoff),reports),
                      'win_probability':None,'forecast_status':'not_issued_research_model_requires_approval_and_current_history'})
    info={'requested_date':date,'requested_at':now.isoformat(),'observed_at':observed.isoformat(),'url':url,
          'raw_file':rawname,'sha256':digest,'games_observed':len(payload.get('events',[])),
          'future_games':len(slate),'games':slate,'excluded':excluded,'forecasts_issued':0,
          'availability_source_status':'Official SEC widget could not be retrieved because its TLS certificate is expired; no unverified report substituted',
          'collection_mode':'one-shot; recurring collection not enabled','prediction_cutoff_minutes':60}
    write_json(out/f'{stamp}-slate.json',info)
    print(json.dumps({'date':date,'future_games':len(slate),'forecasts_issued':0,'manifest':str(out/f'{stamp}-slate.json')}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--date',help='future or current date YYYYMMDD; default today in New York')
    a=p.parse_args(); collect(a.date)
