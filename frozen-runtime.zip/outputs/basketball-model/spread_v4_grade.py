"""Independent retrospective outcome grading; no fitting or threshold selection."""
import json,zipfile
from functools import lru_cache
import numpy as np
import pandas as pd
from spread_v3 import ROOT,OUT as V3,sha,dump
from spread_v4 import OUT,decision,payout,scores

CATEGORIES=['all','home','away','favorite','underdog','neutral','home_venue','small_line','medium_line','large_line','early','late','conference','nonconference']
POLICIES=[0.,.02,.05]
REPLICATES=20000

def slices(g):
    side_line=np.where(g.selected_side.eq('away'),-g.line,g.line)
    return dict(all=np.ones(len(g),dtype=bool),home=g.selected_side.eq('home'),away=g.selected_side.eq('away'),
        favorite=side_line<0,underdog=side_line>0,neutral=g.neutral,home_venue=~g.neutral,
        small_line=g.line.abs().le(3),medium_line=g.line.abs().gt(3)&g.line.abs().le(10),large_line=g.line.abs().gt(10),
        early=g.tipoff.dt.month.isin([11,12]),late=~g.tipoff.dt.month.isin([11,12]),
        conference=g.home_conference.eq(g.away_conference),nonconference=g.home_conference.ne(g.away_conference))

@lru_cache(maxsize=3)
def blockweights(n):
    rng=np.random.default_rng(137);starts=rng.integers(0,n,size=(REPLICATES,int(np.ceil(n/7))))
    ix=((starts[:,:,None]+np.arange(7))%n).reshape(REPLICATES,-1)[:,:n]
    w=np.zeros((REPLICATES,n),dtype=np.int16);np.add.at(w,(np.arange(REPLICATES)[:,None],ix),1)
    return w.astype(float)

def evaluate():
    manifest=json.loads((OUT/'prediction-manifest.json').read_text());ph=sha(OUT/'final-predictions.parquet')
    assert ph==manifest['prediction_sha256']
    pred=pd.read_parquet(OUT/'final-predictions.parquet')
    old=pd.read_parquet(ROOT/'stage2/games.parquet');new=pd.read_parquet(V3/'games-2026.parquet')
    meta=pd.concat([old,new],ignore_index=True)[['game_id','season','margin','neutral','home_conference','away_conference']]
    metrics=scores(pred,meta);metrics.to_csv(OUT/'model-metrics.csv',index=False)
    x=pred.merge(meta.drop(columns='season'),on='game_id',validate='many_to_one')
    x['date']=x.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    ledgers=[];rows=[];calibration=[]
    oldbase=pd.read_parquet(V3/'provider_labeled_close-graded.parquet')
    oldbase=oldbase[oldbase.candidate.eq('cover_logistic_raw')].set_index('game_id')
    for threshold in POLICIES:
        d=decision(x,threshold);delta=d.margin+d.line
        d['actual_push']=np.isclose(delta,0,atol=1e-10,rtol=0)
        d['grade']=np.where(d.selected_side.eq('pass'),'pass',np.where(d.actual_push,'push',np.where((delta>0)==d.selected_side.eq('home'),'win','loss')))
        d['profit']=np.where(d.grade.eq('pass'),np.nan,np.where(d.grade.eq('win'),payout(d.selected_price),np.where(d.grade.eq('loss'),-1.,0.)))
        d['selected_handicap']=np.where(d.selected_side.eq('away'),-d.line,d.line)
        d['baseline_profit']=d.game_id.map(oldbase.hypothetical_profit)
        ledgers.append(d)
        for (candidate,season),g in d.groupby(['candidate','season']):
            for category,mask in slices(g).items():
                h=g[mask&g.selected_side.ne('pass')]
                n=len(h);w=int(h.grade.eq('win').sum());l=int(h.grade.eq('loss').sum())
                rows.append(dict(candidate=candidate,season=int(season),minimum_ev=threshold,category=category,
                    eligible_games=len(g),bets=n,wins=w,losses=l,pushes=int(h.grade.eq('push').sum()),
                    accuracy=w/(w+l) if w+l else None,mean_confidence=float(h.selected_cover_probability.mean()) if n else None,
                    profit_units=float(h.profit.sum()) if n else None,roi=float(h.profit.mean()) if n else None,
                    baseline_roi=float(h.baseline_profit.mean()) if n else None,
                    mean_predicted_ev=float(h.expected_profit.mean()) if n else None))
    ledger=pd.concat(ledgers,ignore_index=True)
    # Save the decision rules and every selection/pass, including losing slices.
    columns=['game_id','season','candidate','minimum_ev','tipoff','feature_cutoff','home_name','away_name','bookmaker','line',
        'home_price','away_price','home_cover_probability','push_probability','uncertainty_weight','min_history',
        'selected_side','selected_handicap','selected_price','selected_cover_probability','expected_profit','pass_reason',
        'grade','margin','profit','baseline_profit','predicted_margin','margin_low_80','margin_high_80','source_url',
        'source_timing','injury_snapshot_verified','historical_timing_verified']
    ledger[columns].to_parquet(OUT/'decision-ledger.parquet',index=False)
    with zipfile.ZipFile(OUT/'decision-ledger.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('decision-ledger.csv',ledger[columns].to_csv(index=False))
    family=len(pred.candidate.unique())*len(POLICIES)*len(CATEGORIES)
    alpha=.05/family
    # Preserve all dates, including dates with zero selections in the category.
    pooled=[]
    for candidate in sorted(pred.candidate.unique()):
        for threshold in POLICIES:
            g=ledger[ledger.candidate.eq(candidate)&ledger.minimum_ev.eq(threshold)]
            masks=slices(g)
            for year in ['all',2025,2026]:
                all_dates=sorted(g.date.unique() if year=='all' else g.loc[g.season.eq(year),'date'].unique())
                weights=blockweights(len(all_dates))
                for category,mask in masks.items():
                    h=g[mask&g.selected_side.ne('pass')]
                    if year!='all':h=h[h.season.eq(year)]
                    n=len(h);w=int(h.grade.eq('win').sum());l=int(h.grade.eq('loss').sum())
                    r=dict(candidate=candidate,season=year,minimum_ev=threshold,category=category,bets=n,wins=w,losses=l,
                        pushes=int(h.grade.eq('push').sum()),accuracy=w/(w+l) if w+l else None,
                        mean_confidence=float(h.selected_cover_probability.mean()) if n else None,
                        profit_units=float(h.profit.sum()) if n else None,roi=float(h.profit.mean()) if n else None,
                        baseline_roi=float(h.baseline_profit.mean()) if n else None,
                        mean_predicted_ev=float(h.expected_profit.mean()) if n else None,
                        roi_low=None,roi_high=None,adjusted_roi_low=None,paired_delta_low=None,paired_delta_high=None,adjusted_paired_delta_low=None,
                        max_drawdown_units=None)
                    if n:
                        daily=h.groupby('date').agg(n=('profit','size'),profit=('profit','sum'),baseline=('baseline_profit','sum')).reindex(all_dates,fill_value=0)
                        b=weights@daily.to_numpy();valid=b[:,0]>0;b=b[valid]
                        returns=b[:,1]/b[:,0];diff=(b[:,1]-b[:,2])/b[:,0]
                        equity=np.r_[0.,h.sort_values(['tipoff','game_id']).profit.cumsum().to_numpy()]
                        r.update(roi_low=float(np.quantile(returns,.025)),roi_high=float(np.quantile(returns,.975)),
                            adjusted_roi_low=float(np.quantile(returns,alpha)),paired_delta_low=float(np.quantile(diff,.025)),paired_delta_high=float(np.quantile(diff,.975)),
                            adjusted_paired_delta_low=float(np.quantile(diff,alpha)),
                            max_drawdown_units=float(np.max(np.maximum.accumulate(equity)-equity)))
                    pooled.append(r)
    f=pd.DataFrame(pooled);f['statistical_screen_passed']=False
    for (c,t,k),g in f.groupby(['candidate','minimum_ev','category']):
        years=g[g.season.ne('all')];a=g[g.season.eq('all')].iloc[0]
        passes=bool(len(years)==2 and years.bets.ge(100).all() and years.roi.gt(0).all() and pd.notna(a.adjusted_roi_low) and a.adjusted_roi_low>0 and a.adjusted_paired_delta_low>0)
        f.loc[g.index,'statistical_screen_passed']=passes
    f.to_csv(OUT/'category-results.csv',index=False)
    for (candidate,season),g in x.groupby(['candidate','season']):
        q=np.maximum(g.home_cover_probability,1-g.home_cover_probability)
        correct=((g.margin+g.line>0)==(g.home_cover_probability>=.5)).astype(int)
        for low,high in [(.5,.51),(.51,.52),(.52,.55),(.55,.60),(.60,.70),(.70,1.000001)]:
            h=g[q.ge(low)&q.lt(high)];idx=h.index
            calibration.append(dict(candidate=candidate,season=int(season),low=low,high=min(high,1.),games=len(h),
                predicted=float(q.loc[idx].mean()) if len(h) else None,observed=float(correct.loc[idx].mean()) if len(h) else None))
    assert sha(OUT/'final-predictions.parquet')==ph
    # JSON export: NaNs become null, so empty policies remain explicit.
    records=json.loads(f.to_json(orient='records'));cal=json.loads(pd.DataFrame(calibration).to_json(orient='records'))
    result=dict(experiment='spread-v4-20261017',promotion=False,selected_policy='pass',
        final_seasons_previously_inspected=True,prospective_validation_required=True,
        significance_family=family,bootstrap_replicates=REPLICATES,adjustment='Bonferroni one-sided familywise 95% lower return bound',
        statistical_winners=[r for r in records if r['season']=='all' and r['statistical_screen_passed']],
        selection=json.loads((OUT/'selection.json').read_text()),metrics=json.loads(metrics.to_json(orient='records')),
        categories=records,calibration=cal,
        limitations=['Both final seasons previously inspected; no prospective confirmation',
            'Provider-labeled closes have no exact capture timestamps',
            'Historical original feature publication/revision timestamps unverified',
            'No dated injury snapshots; observed prior rotations do not verify current availability',
            'Travel is a venue-state-change proxy, not distance or actual itinerary',
            'All returns are hypothetical one-unit risk at recorded prices; no wagers placed'])
    dump(OUT/'results.json',result)
    dump(OUT/'grading-integrity.json',dict(prediction_sha256_unchanged=ph,selection_sha256=sha(OUT/'selection.json'),
         source_sha256=sha(__file__),leakage_verdict='REVIEW REQUIRED: original historical publication vintages',fit_during_grading=False))
    print(f[f.season.eq('all')&f.category.eq('all')][['candidate','minimum_ev','bets','accuracy','roi','roi_low','roi_high','adjusted_roi_low']].to_string(index=False),flush=True)
    print('Statistical screen winners:',len(result['statistical_winners']),flush=True)

if __name__=='__main__':evaluate()
