"""Separate final-outcome grading. No training or probability changes occur here."""
import json,math
from pathlib import Path
import numpy as np
import pandas as pd
from spread_v3 import ROOT,OUT,sha,dump
from confidence_check import EDGES,LABELS,bands

WEIGHTS={}
def weights(n):
    if n not in WEIGHTS:
        rng=np.random.default_rng(137);starts=rng.integers(0,n,size=(2000,int(np.ceil(n/7))))
        ix=((starts[:,:,None]+np.arange(7))%n).reshape(2000,-1)[:,:n]
        w=np.zeros((2000,n),dtype=np.int32);np.add.at(w,(np.arange(2000)[:,None],ix),1);WEIGHTS[n]=w
    return WEIGHTS[n]
def interval(g,value,dates):
    if not len(g):return [None,None]
    d=g.assign(value=value).groupby('date').agg(n=('value','size'),value=('value','sum')).reindex(dates,fill_value=0).to_numpy()
    res=weights(len(dates))@d;res=res[res[:,0]>0]
    return list(map(float,np.quantile(res[:,1]/res[:,0],[.025,.975]))) if len(res) else [None,None]
def wilson(w,n):
    if not n:return [None,None]
    z=1.959963984540054;p=w/n;den=1+z*z/n;c=(p+z*z/(2*n))/den;h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [float(c-h),float(c+h)]
def grade_rows(pred,outcomes):
    x=pred.merge(outcomes,on='game_id',validate='many_to_one')
    assert len(x)==len(pred)
    x['home_delta']=x.margin+x.line;x['actual_push']=np.isclose(x.home_delta,0,atol=1e-10,rtol=0)
    x['grade']=np.where(x.selected_side=='pass','pass',np.where(x.actual_push,'push',np.where((x.home_delta>0)==(x.selected_side=='home'),'win','loss')))
    x['date']=x.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    x['selected_team']=np.where(x.selected_side=='home',x.home_name,np.where(x.selected_side=='away',x.away_name,''))
    x['selected_handicap']=np.where(x.selected_side=='away',-x.line,x.line)
    if 'home_price' not in x:x['home_price']=np.nan;x['away_price']=np.nan
    x['selected_price']=np.where(x.selected_side=='home',x.home_price,np.where(x.selected_side=='away',x.away_price,np.nan))
    price=x.selected_price.to_numpy();valid=np.isfinite(price)&(np.abs(price)>=100)&x.selected_side.ne('pass').to_numpy()
    payout=np.divide(100,np.abs(price),out=np.zeros(len(price)),where=np.isfinite(price)&(np.abs(price)>0));payout=np.where(price>0,price/100,payout)
    x['hypothetical_profit']=np.where(valid,np.where(x.grade=='win',payout,np.where(x.grade=='loss',-1.,0.)),np.nan)
    x['cover_band']=bands(x.selected_cover_probability)
    return x
def metric(g,dates):
    decided=g[~g.actual_push];n=len(decided);y=(decided.home_delta>0).to_numpy().astype(int);p=np.clip(decided.home_cover_probability.to_numpy(),1e-6,1-1e-6)
    picks=g[g.grade.isin(['win','loss'])];wins=int(picks.grade.eq('win').sum());losses=len(picks)-wins
    priced=g[g.hypothetical_profit.notna()]
    ece=0.
    for band in LABELS:
        part=picks[bands(picks.selected_cover_probability)==band]
        if len(part):ece+=len(part)/max(len(picks),1)*abs(part.selected_cover_probability.mean()-part.grade.eq('win').mean())
    valid_point=g.predicted_margin.notna()
    return {'games':len(g),'decided_games':n,'wins':wins,'losses':losses,'pushes':int(g.grade.eq('push').sum()),'sample_final_pushes':int(g.actual_push.sum()),'passes':int(g.grade.eq('pass').sum()),
            'cover_accuracy':wins/len(picks) if len(picks) else None,'accuracy_interval':interval(picks,picks.grade.eq('win').astype(int),dates),'wilson_interval':wilson(wins,len(picks)),
            'log_loss':float(np.mean(-y*np.log(p)-(1-y)*np.log1p(-p))) if n else None,'brier':float(np.mean((p-y)**2)) if n else None,'ece_selected':float(ece) if len(picks) else None,
            'mean_confidence':float(picks.selected_cover_probability.mean()) if len(picks) else None,'max_confidence':float(g.selected_cover_probability.max()) if len(g) else None,
            'margin_mae':float((g.loc[valid_point,'predicted_margin']-g.loc[valid_point,'margin']).abs().mean()) if valid_point.any() else None,
            'priced_hypothetical_picks':len(priced),'hypothetical_profit_units':float(priced.hypothetical_profit.sum()) if len(priced) else None,'hypothetical_roi':float(priced.hypothetical_profit.mean()) if len(priced) else None,
            'roi_interval':interval(priced,priced.hypothetical_profit,dates),'mean_quote_age_minutes':float(g.quote_age_minutes.mean()) if g.quote_age_minutes.notna().any() else None}
def bucket(g,dates):
    decided=g[g.grade.isin(['win','loss'])];w=int(decided.grade.eq('win').sum());n=len(decided)
    return {'games':len(g),'decided':n,'wins':w,'losses':n-w,'pushes':int(g.grade.eq('push').sum()),'passes':int(g.grade.eq('pass').sum()),'mean_probability':float(decided.selected_cover_probability.mean()) if n else None,'observed_cover_rate':w/n if n else None,'date_block_interval':interval(decided,decided.grade.eq('win').astype(int),dates),'wilson_interval':wilson(w,n),'sparse':n<100}
def main():
    paths={'timestamped_draftkings':('final-predictions.parquet','final-prediction-manifest.json'),'provider_labeled_close':('closing-predictions.parquet','closing-prediction-manifest.json')}
    original_hashes={}
    for cohort,(file,mfile) in paths.items():
        m=json.loads((OUT/mfile).read_text());assert sha(OUT/file)==m['predictions_sha256'];original_hashes[file]=sha(OUT/file)
    selected=json.loads((OUT/'selection.json').read_text())['selected_candidate']
    old=pd.read_parquet(ROOT/'stage2/games.parquet',columns=['game_id','season','margin'],filters=[('season','==',2025)])
    new=pd.read_parquet(OUT/'games-2026.parquet',columns=['game_id','season','margin'])
    outcomes=pd.concat([old,new],ignore_index=True).drop(columns='season');assert outcomes.game_id.is_unique
    metrics=[];buckets=[];highlights=[];paired=[];gradefiles=[];provider_counts=[];coverage=[]
    for cohort,(file,mfile) in paths.items():
        pred=pd.read_parquet(OUT/file);x=grade_rows(pred,outcomes);dates=sorted(x.date.unique())
        assert not x.duplicated(['game_id','candidate']).any()
        poison=outcomes.copy();poison['margin']=-999.;altered=grade_rows(pred,poison)
        for col in ['home_cover_probability','push_probability','selected_side','selected_cover_probability','cover_band']:
            pd.testing.assert_series_equal(x[col],altered[col])
        assert (x.grade!=altered.grade).any()
        x.to_parquet(OUT/(cohort+'-graded.parquet'),index=False);x.to_csv(OUT/(cohort+'-bet-ledger.csv'),index=False);gradefiles.append(cohort+'-bet-ledger.csv')
        one=x[x.candidate=='market_50'];provider_counts.extend([{'cohort':cohort,'season':int(y),'provider':name,'games':len(g)} for (y,name),g in one.groupby(['season','bookmaker'])])
        for y in [2025,2026]:
            total=len(old) if y==2025 else len(new);g=one[one.season==y]
            coverage.append({'cohort':cohort,'season':y,'eligible_games':total,'quoted_games':len(g),'missing_games':total-len(g),'with_both_prices':int((g.home_price.notna()&g.away_price.notna()).sum())})
        groups=[((c,int(y)),g) for (c,y),g in x.groupby(['candidate','season'])]+[((c,'all'),g) for c,g in x.groupby('candidate')]
        for (candidate,year),g in groups:
            metrics.append({'cohort':cohort,'candidate':candidate,'season':year,'is_selected':candidate==selected,**metric(g,dates)})
            for label in LABELS:
                part=g[g.cover_band==label];buckets.append({'cohort':cohort,'candidate':candidate,'season':year,'band':label,**bucket(part,dates)})
            for label,mask in [('about70',(g.selected_cover_probability>=.675)&(g.selected_cover_probability<.725)),('at_least70',g.selected_cover_probability>=.7)]:
                highlights.append({'cohort':cohort,'candidate':candidate,'season':year,'selection':label,**bucket(g[mask],dates)})
        for ref in ['market_50','market_no_vig']:
            reference=x[(x.candidate==ref)&~x.actual_push].copy()
            if reference.empty:continue
            pr=np.clip(reference.home_cover_probability.to_numpy(),1e-6,1-1e-6);yr=(reference.home_delta>0).to_numpy().astype(int)
            reference['ref_loss']=-yr*np.log(pr)-(1-yr)*np.log1p(-pr)
            for candidate,g in x[~x.actual_push].groupby('candidate'):
                a=g.merge(reference[['game_id','ref_loss']],on='game_id',validate='one_to_one');p=np.clip(a.home_cover_probability,1e-6,1-1e-6);y=(a.home_delta>0).astype(int);a['loss_delta']=-y*np.log(p)-(1-y)*np.log1p(-p)-a.ref_loss
                for year,part in [('all',a),*list(a.groupby('season'))]:
                    paired.append({'cohort':cohort,'candidate':candidate,'reference':ref,'season':year,'n':len(part),'model_minus_reference_log_loss':float(part.loss_delta.mean()),'date_block_interval':interval(part,part.loss_delta,dates)})
        if cohort=='timestamped_draftkings':
            exact=x[x.tipoff_difference_minutes.eq(0)]
            for (candidate,year),g in exact.groupby(['candidate','season']):metrics.append({'cohort':'timestamped_exact_tipoff_sensitivity','candidate':candidate,'season':int(year),'is_selected':candidate==selected,**metric(g,dates)})
    for file,h in original_hashes.items():assert sha(OUT/file)==h
    result={'experiment':'spread-v3-20261017','date':'2026-10-17','seasons':[2025,2026],'selected_candidate':selected,'promotion':False,
            'verdict':'No demonstrated repeatable improvement over the spread market in pre-2025 development; retain market baseline and do not issue high-confidence bets.',
            'timing_note':'Timestamped archive and provider-labeled closing fields are separate populations; exact closing capture timestamps are unavailable for ESPN closes.',
            'source_timing_verified':False,'coverage':coverage,'providers':provider_counts,'metrics':metrics,'confidence_buckets':buckets,'seventy_percent':highlights,'paired_comparisons':paired,
            'development':json.loads((OUT/'selection.json').read_text())['development_metrics'],
            'limitations':['2025 was already used in earlier development; 2026 acquired after frozen selection','Original historical publication and revision vintages remain unknown','Final candidates were trained/calibrated on DraftKings data; closing-source provider can differ','No actual wagers were placed; any return is hypothetical using recorded side prices','Calibration does not create a betting edge; empty high-confidence bins are honest outcomes']}
    # Preserve JSON null rather than NaN, including empty cohorts/buckets.
    dump(OUT/'results.json',result)
    pd.json_normalize(metrics).to_csv(OUT/'model-metrics.csv',index=False);pd.json_normalize(buckets).to_csv(OUT/'confidence-buckets.csv',index=False);pd.json_normalize(paired).to_csv(OUT/'paired-comparisons.csv',index=False);pd.DataFrame(coverage).to_csv(OUT/'coverage.csv',index=False)
    dump(OUT/'grading-integrity.json',{'prediction_hashes_unchanged':True,'outcome_poison_preserves_probabilities_sides_bands':True,'final_prediction_hashes':original_hashes,'selection_sha256':sha(OUT/'selection.json'),'grading_source_sha256':sha(__file__),'ledger_files':gradefiles,'verdict':'REVIEW REQUIRED for original historical source vintages; computational withholding passed'})
    print(pd.DataFrame(metrics).query("cohort=='provider_labeled_close' and season!='all'")[['candidate','season','games','wins','losses','pushes','passes','cover_accuracy','log_loss','brier','margin_mae','hypothetical_roi']].to_string(index=False),flush=True)

if __name__=='__main__':main()
