"""Boundary, future-data and market selection tests for the spread experiment."""
import unittest
import numpy as np
import pandas as pd
import joblib
from spread_v4_features import build,load_games,snapshot_asof,OUT,NAMES
from spread_v4 import decision,inputs,predict
from spread_v4_policy import issue

class SpreadV4Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.games=load_games().query('season==2025').sort_values(['decision_time','game_id']).head(500).copy()
        cls.cutoff=cls.games.decision_time.sort_values().iloc[250]

    def test_unreleased_outcomes_do_not_change_earlier_features(self):
        a=build(self.games,{},{});g=self.games.copy()
        hidden=g.tipoff+pd.Timedelta(hours=24)>self.cutoff
        for c in ['margin','home_eff','away_eff','home_score','away_score']:
            g.loc[hidden,c]=777
        b=build(g,{},{})
        pd.testing.assert_frame_equal(a[a.decision_time.le(self.cutoff)],b[b.decision_time.le(self.cutoff)])

    def test_current_player_participation_cannot_change_current_features(self):
        a=build(self.games,{},{});g=self.games.iloc[300]
        rotations={(g.game_id,g.home_team):{999:40.,888:40.}}
        b=build(self.games,rotations,{})
        pd.testing.assert_frame_equal(a[a.decision_time.le(g.decision_time)],b[b.decision_time.le(g.decision_time)])

    def test_source_row_order_does_not_change_features(self):
        pd.testing.assert_frame_equal(build(self.games,{},{}),build(self.games.sample(frac=1,random_state=2),{},{}))

    def test_release_boundary_and_initial_history(self):
        a=build(self.games,{},{});known=a.latest_result_used.notna()
        self.assertTrue((a.loc[known,'latest_result_used']<=a.loc[known,'feature_cutoff']).all())
        first=a.iloc[0];self.assertEqual(first.min_history,0)
        self.assertTrue(np.isfinite(a[NAMES].to_numpy()).all())

    def sample(self,p=.55,h=-110,a=-110,push=0.,n=10):
        return pd.DataFrame(dict(home_cover_probability=[p],push_probability=[push],home_price=[h],away_price=[a],min_history=[n]))

    def test_ev_selects_lower_probability_if_price_is_better(self):
        # Home 55% at -200 is inferior to away 45% at +150 (positive EV).
        d=decision(self.sample(h=-200,a=150),.02)
        self.assertEqual(d.selected_side.iloc[0],'away');self.assertAlmostEqual(d.expected_profit.iloc[0],.125)

    def test_market_cost_makes_51_percent_a_pass(self):
        self.assertEqual(decision(self.sample(p=.51),0).selected_side.iloc[0],'pass')

    def test_unpromoted_research_never_issues_a_selection(self):
        d=issue(self.sample(p=.9),{'promotion':False})
        self.assertEqual(d.selected_side.iloc[0],'pass')

    def test_production_requires_a_recent_quote_and_availability(self):
        cutoff=pd.Timestamp('2026-10-01',tz='UTC')
        x=self.sample(p=.7).assign(game_id='a',quote_time=cutoff-pd.Timedelta(minutes=5),decision_time=cutoff,injury_snapshot_verified=True,historical_timing_verified=True)
        self.assertEqual(issue(x,{'promotion':True}).selected_side.iloc[0],'home')
        for key,value in [('injury_snapshot_verified',False),('quote_time',cutoff+pd.Timedelta(seconds=1)),('quote_time',cutoff-pd.Timedelta(minutes=16))]:
            self.assertEqual(issue(x.assign(**{key:value}),{'promotion':True}).selected_side.iloc[0],'pass')

    def test_production_selects_only_one_offer_per_game(self):
        cutoff=pd.Timestamp('2026-10-01',tz='UTC')
        x=pd.concat([self.sample(p=.7,h=-110),self.sample(p=.7,h=100)],ignore_index=True).assign(game_id='a',quote_time=cutoff,decision_time=cutoff,injury_snapshot_verified=True,historical_timing_verified=True)
        d=issue(x,{'promotion':True});self.assertEqual(len(d),1);self.assertEqual(d.selected_price.iloc[0],100)

    def test_grading_labels_cannot_change_bet_decisions(self):
        x=self.sample(p=.6).assign(margin=15,grade='win')
        a=decision(x);b=decision(x.assign(margin=-999,grade='loss'))
        for c in ['selected_side','selected_price','selected_cover_probability','expected_profit','pass_reason']:
            pd.testing.assert_series_equal(a[c],b[c])

    def test_pushes_return_stake_in_expected_value(self):
        d=decision(self.sample(push=.1),0)
        self.assertAlmostEqual(d.expected_profit.iloc[0],.9*(.55*100/110-.45))

    def test_bad_prices_or_insufficient_history_pass(self):
        for frame in [self.sample(h=np.nan),self.sample(a=0),self.sample(n=7)]:
            self.assertEqual(decision(frame,0).selected_side.iloc[0],'pass')

    def test_cutoff_includes_equality(self):
        d=decision(self.sample(p=.6,h=100),.2)
        # Numeric float tolerance: use the exact calculated EV as cutoff.
        cutoff=.6*1-(1-.6)
        self.assertEqual(decision(self.sample(p=.6,h=100),cutoff).selected_side.iloc[0],'home')

    def test_availability_requires_publication_and_capture_by_cutoff(self):
        cutoff=pd.Timestamp('2025-01-01',tz='UTC')
        e=pd.DataFrame(dict(game_id=['a'],team_id=['t'],cutoff=[cutoff]))
        s=pd.DataFrame(dict(game_id=['a'],team_id=['t'],published_at=[cutoff-pd.Timedelta(hours=1)],captured_at=[cutoff+pd.Timedelta(seconds=1)],source_url=['https://example.com/report'],unavailable_minutes_share=[.3]))
        self.assertTrue(snapshot_asof(e,s).empty)
        s['captured_at']=cutoff
        self.assertEqual(len(snapshot_asof(e,s)),1)
        s['published_at']=None
        with self.assertRaises(ValueError):snapshot_asof(e,s)

    def test_predictions_refuse_outcomes_and_are_deterministic(self):
        m=joblib.load(OUT/'frozen-models.joblib');x=inputs(True).head(20)
        a=predict(m,x);b=predict(m,x)
        pd.testing.assert_frame_equal(a,b)
        with self.assertRaises(ValueError):predict(m,x.assign(margin=999))
        self.assertTrue(a.home_cover_probability.between(0,1).all())
        # With no empirical history, enhanced candidates fall back to the market.
        e=a[a.candidate.str.startswith('enhanced')&a.min_history.eq(0)]
        ref=a[a.candidate.eq('market_no_vig')].set_index('game_id').home_cover_probability
        for row in e.itertuples():self.assertAlmostEqual(row.home_cover_probability,ref[row.game_id])

if __name__=='__main__':unittest.main(verbosity=2)
