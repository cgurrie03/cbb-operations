"""Prior-event feature broker; no same-game box or participation is exposed."""
from collections import defaultdict, deque
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from spread_v3 import ROOT, RAW, OUT as V3, sha, dump

OUT=ROOT/'spread-v4-20261017'
NAMES=['rating_edge','offense_diff','defense_diff','form_diff','efg_matchup',
       'turnover_matchup','rebound_matchup','freethrow_matchup','three_rate_diff',
       'rest_diff','congestion_diff','min_history','history_diff','rotation_diff',
       'returning_diff','roster_missing','travel_change_diff','travel_missing',
       'rest_missing','box_missing','rotation_churn_diff']

def load_games():
    return pd.concat([pd.read_parquet(ROOT/'stage2/games.parquet'),
                      pd.read_parquet(V3/'games-2026.parquet')],ignore_index=True)

def load_context():
    """Only stable location metadata and player minutes; no current injuries inferred."""
    rotations={}; locations={}; manifest=[]
    for year in range(2016,2027):
        sched=V3/'raw/schedule_2026.parquet' if year==2026 else next(RAW.glob(f'schedule_{year}-*.parquet'))
        p=OUT/'raw/player_box_2026.parquet' if year==2026 else next(RAW.glob(f'player_box_{year}-*.parquet'))
        s=pd.read_parquet(sched,columns=['game_id','venue_address_state'])
        for gid,state in s.itertuples(index=False,name=None):
            locations['espn:'+str(int(gid))]=str(state) if pd.notna(state) else None
        b=pd.read_parquet(p,columns=['game_id','team_id','athlete_id','minutes'])
        b=b.dropna(); b=b[b.minutes.gt(0)&b.minutes.le(65)].copy()
        b['game_id']='espn:'+b.game_id.astype('int64').astype(str)
        b['team_id']='espn:'+b.team_id.astype('int64').astype(str)
        b['athlete_id']=b.athlete_id.astype('int64')
        if b.duplicated(['game_id','team_id','athlete_id']).any():
            raise ValueError('Duplicate player-game source identity')
        for (gid,team),g in b.groupby(['game_id','team_id'],sort=False):
            rotations[(gid,team)]=dict(zip(g.athlete_id,g.minutes))
        manifest.extend([{'path':str(p),'sha256':sha(p),'family':'player_box'},
                         {'path':str(sched),'sha256':sha(sched),'family':'schedule'}])
    return rotations,locations,manifest

def fresh(rating=0.,off=0.,defense=0.):
    return dict(rating=rating,off=off,defense=defense,n=0,boxes=0,
                factors=np.array([.5,.2,.3,.3,.35,.5,.2,.3,.3]),
                form=deque(maxlen=5),dates=deque(maxlen=5),rotation=None,
                returning=.5,concentration=.5,churn=0.,state=None)

def rates(g,side):
    other='away' if side=='home' else 'home'
    def n(s,k):return float(g[s+'_'+k])
    fga=n(side,'field_goals_attempted');fta=n(side,'free_throws_attempted')
    oppfga=n(other,'field_goals_attempted');oppfta=n(other,'free_throws_attempted')
    if min(fga,oppfga)<=0:return None
    return np.array([
        (n(side,'field_goals_made')+.5*n(side,'three_point_field_goals_made'))/fga,
        n(side,'total_turnovers')/max(fga+.44*fta+n(side,'total_turnovers'),1),
        n(side,'offensive_rebounds')/max(n(side,'offensive_rebounds')+n(other,'defensive_rebounds'),1),
        fta/fga,n(side,'three_point_field_goals_attempted')/fga,
        (n(other,'field_goals_made')+.5*n(other,'three_point_field_goals_made'))/oppfga,
        n(other,'total_turnovers')/max(oppfga+.44*oppfta+n(other,'total_turnovers'),1),
        n(other,'offensive_rebounds')/max(n(other,'offensive_rebounds')+n(side,'defensive_rebounds'),1),
        oppfta/oppfga])

def build(games,rotations,locations,progress=False):
    """Daily freeze; every state mutation is gated by tipoff + 24 hours."""
    rows=[];settled={};previous_players={}
    for season,frame in games.sort_values(['decision_time','game_id']).groupby('season',sort=True):
        states={};seen_players=defaultdict(set)
        def state(team):
            if team not in states:
                old=settled.get(team,(0.,0.,0.))
                states[team]=fresh(*[v*.5 for v in old])
            return states[team]
        history=frame.sort_values(['tipoff','game_id']).to_dict('records');i=0;latest=None
        for day,batch in frame.groupby(frame.decision_time.dt.strftime('%Y-%m-%d'),sort=True):
            cutoff=batch.decision_time.min()
            while i<len(history) and history[i]['tipoff']+pd.Timedelta(hours=24)<=cutoff:
                g=history[i];i+=1;latest=g['tipoff']+pd.Timedelta(hours=24)
                h=state(g['home_team']);a=state(g['away_team']);venue=3*g['venue_effect']
                err=float(np.clip(g['margin']-(h['rating']-a['rating']+venue),-30,30))
                h['rating']+=.08*err;a['rating']-=.08*err
                h['form'].append(err);a['form'].append(-err)
                if g['box_usable']:
                    he=float(np.clip(g['home_eff']-(100+h['off']+a['defense']+2*g['venue_effect']),-40,40))
                    ae=float(np.clip(g['away_eff']-(100+a['off']+h['defense']-2*g['venue_effect']),-40,40))
                    h['off']+=.08*he;a['defense']+=.08*he
                    a['off']+=.08*ae;h['defense']+=.08*ae
                for side,s in [('home',h),('away',a)]:
                    team=g[side+'_team'];s['n']+=1;s['dates'].append(g['tipoff']);s['state']=locations.get(g['game_id'])
                    if g['box_usable']:
                        r=rates(g,side)
                        if r is not None and np.isfinite(r).all():
                            alpha=1/(min(s['boxes'],9)+1+5);s['factors']+=(r-s['factors'])*alpha;s['boxes']+=1
                    rotation=rotations.get((g['game_id'],team))
                    if rotation:
                        total=sum(rotation.values());share={p:m/total for p,m in rotation.items()}
                        s['returning']=sum(v for p,v in share.items() if p in previous_players.get(team,set()))
                        s['concentration']=sum(sorted(share.values(),reverse=True)[:5])
                        s['churn']=1-sum(min(v,s['rotation'].get(p,0)) for p,v in share.items()) if s['rotation'] else 0.
                        s['rotation']=share;seen_players[team].update(share)
            for g in batch.to_dict('records'):
                h=state(g['home_team']);a=state(g['away_team']);hf=h['factors'];af=a['factors']
                rests=[min(max((g['tipoff']-s['dates'][-1]).total_seconds()/86400,0),30) if s['dates'] else None for s in [h,a]]
                congestion=[sum((g['tipoff']-d).total_seconds()<=7*86400 for d in s['dates']) for s in [h,a]]
                location=locations.get(g['game_id']);travel=[int(s['state']!=location) if s['state'] and location else None for s in [h,a]]
                row=dict(game_id=g['game_id'],season=int(season),decision_time=g['decision_time'],feature_cutoff=cutoff,
                    latest_result_used=latest,home_prior_games=h['n'],away_prior_games=a['n'],
                    rating_edge=h['rating']-a['rating']+3*g['venue_effect'],offense_diff=h['off']-a['off'],
                    defense_diff=h['defense']-a['defense'],form_diff=np.mean(h['form'])-np.mean(a['form']) if h['form'] and a['form'] else 0.,
                    efg_matchup=(hf[0]+af[5])-(af[0]+hf[5]),
                    turnover_matchup=(hf[1]+af[6])-(af[1]+hf[6]),
                    rebound_matchup=(hf[2]+af[7])-(af[2]+hf[7]),
                    freethrow_matchup=(hf[3]+af[8])-(af[3]+hf[8]),three_rate_diff=hf[4]-af[4],
                    rest_diff=rests[0]-rests[1] if None not in rests else 0.,rest_missing=int(None in rests),
                    congestion_diff=congestion[0]-congestion[1],min_history=min(h['n'],a['n']),history_diff=h['n']-a['n'],
                    rotation_diff=h['concentration']-a['concentration'],returning_diff=h['returning']-a['returning'],
                    rotation_churn_diff=h['churn']-a['churn'],roster_missing=int(h['rotation'] is None or a['rotation'] is None),
                    travel_change_diff=travel[0]-travel[1] if None not in travel else 0.,travel_missing=int(None in travel),
                    box_missing=int(h['boxes']<3 or a['boxes']<3))
                rows.append(row)
        # End-of-season state only becomes a prior for the NEXT season.
        # Finish unsettled games to preserve this rule without using them in same-season predictions.
        # Reuse the final observed pregame states rather than post-hoc full-season rating fits.
        settled={t:(s['rating'],s['off'],s['defense']) for t,s in states.items()}
        previous_players=dict(seen_players)
        if progress:print('v4 features',season,len(frame),flush=True)
    result=pd.DataFrame(rows)
    known=result.latest_result_used.notna()
    assert (result.loc[known,'latest_result_used']<=result.loc[known,'feature_cutoff']).all()
    assert (result.feature_cutoff<=result.decision_time).all()
    assert result.game_id.is_unique
    assert np.isfinite(result[NAMES].to_numpy()).all()
    return result

def snapshot_asof(events,snapshots):
    """Injury/roster inputs require BOTH pre-cutoff publication and capture evidence."""
    required={'game_id','team_id','published_at','captured_at','source_url','unavailable_minutes_share'}
    if not required.issubset(snapshots):raise ValueError('Timestamped availability schema is incomplete')
    s=snapshots.copy()
    for c in ['published_at','captured_at']:s[c]=pd.to_datetime(s[c],utc=True,errors='coerce')
    if s[['published_at','captured_at']].isna().any().any() or s.source_url.fillna('').eq('').any():
        raise ValueError('Missing availability publication/capture evidence')
    if not s.unavailable_minutes_share.between(0,1).all():raise ValueError('Invalid minute share')
    x=events.merge(s,on=['game_id','team_id'],how='left',validate='one_to_many')
    legal=x.published_at.le(x.cutoff)&x.captured_at.le(x.cutoff)
    return x[legal].sort_values(['published_at','captured_at']).drop_duplicates(['game_id','team_id'],keep='last')

def main():
    if (OUT/'features.parquet').exists():raise RuntimeError('Frozen features exist')
    games=load_games();rotations,locations,manifest=load_context()
    f=build(games,rotations,locations,True);f.to_parquet(OUT/'features.parquet',index=False)
    dump(OUT/'feature-manifest.json',dict(features=NAMES,source_files=manifest,release_lag_hours=24,
        source_vintage_verified=False,injuries='unknown: no timestamped snapshots supplied',
        roster='Observed prior rotation, NOT a current pregame roster or injury report',
        travel='State change from last known game venue; NOT travel distance or itinerary',
        feature_sha256=sha(OUT/'features.parquet'),code_sha256=sha(__file__)))

if __name__=='__main__':main()
