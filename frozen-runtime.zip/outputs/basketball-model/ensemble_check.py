"""Exploratory soft-voting check on stored chronological research predictions."""
from datetime import datetime, timezone
import hashlib
import json
import numpy as np
import pandas as pd
from stage2_data import OUT, write_json
from stage2_models import loss

def main():
    target=OUT/'ensemble-check'
    target.mkdir(exist_ok=False)
    write_json(target/'pre_run.json',{'created_at':datetime.now(timezone.utc).isoformat(),
        'hypothesis':'Margin ratings add complementary errors to the core efficiency model',
        'primary_metric':'log_loss','models':['efficiency_logistic','margin_ratings'],
        'weights':[0.,.25,.5,.75,1.],'first_season_weight':.5,
        'weight_selection':'earlier chronological out-of-fold predictions only; tie favors higher efficiency weight',
        'acceptance':'improve mean and majority of folds; no production promotion with unresolved source timing',
        'limits':'exploratory addition after reviewing base-model development results; 2026 untouched',
        'input_sha256':hashlib.sha256((OUT/'predictions.parquet').read_bytes()).hexdigest()})
    raw=pd.read_parquet(OUT/'predictions.parquet')
    core=raw[raw.model=='efficiency_logistic'][['game_id','season','decision_time','home_team','away_team','won','win_probability']].rename(columns={'win_probability':'core'})
    margin=raw[raw.model=='margin_ratings'][['game_id','win_probability']].rename(columns={'win_probability':'margin_model'})
    d=core.merge(margin,on='game_id',validate='one_to_one')
    rows=[]; predictions=[]; choices=[]
    for season in sorted(d.season.unique()):
        train=d[d.season<season]; test=d[d.season==season].copy(); y=test.won.to_numpy()
        w=.5
        if len(train):
            assert train.decision_time.max()<test.decision_time.min()
            candidates=[(float(loss(train.won.to_numpy(),weight*train.core.to_numpy()+(1-weight)*train.margin_model.to_numpy()).mean()),-weight) for weight in [0.,.25,.5,.75,1.]]
            w=-min(candidates)[1]
        choices.append({'season':int(season),'efficiency_weight':w,'margin_weight':1-w,'earlier_prediction_games':len(train)})
        models={'core':test.core.to_numpy(),'margin_ratings':test.margin_model.to_numpy(),
                'equal_blend':.5*test.core.to_numpy()+.5*test.margin_model.to_numpy(),
                'past_selected_blend':w*test.core.to_numpy()+(1-w)*test.margin_model.to_numpy()}
        for model,p in models.items():
            ll=loss(y,p)
            rows.append({'season':int(season),'model':model,'n':len(test),'log_loss':float(ll.mean()),
                         'brier':float(np.mean((p-y)**2)),'accuracy':float(np.mean((p>=.5)==y))})
            predictions.append(test.assign(model=model,win_probability=p,log_loss=ll))
    metrics=pd.DataFrame(rows); pred=pd.concat(predictions,ignore_index=True)
    metrics.to_csv(target/'by_season.csv',index=False); pred.to_parquet(target/'predictions.parquet',index=False)
    summary=metrics.groupby('model').apply(lambda g:pd.Series({'n':g.n.sum(),'log_loss':np.average(g.log_loss,weights=g.n),
                                    'brier':np.average(g.brier,weights=g.n),'accuracy':np.average(g.accuracy,weights=g.n)}))
    summary.to_csv(target/'summary.csv')
    wide=metrics.pivot(index='season',columns='model',values='log_loss')
    error_correlation=float(np.corrcoef(d.core-d.won,d.margin_model-d.won)[0,1])
    paired=[]; rng=np.random.default_rng(137)
    for model in ['equal_blend','past_selected_blend']:
        candidate=pred[pred.model==model].merge(pred[pred.model=='core'][['game_id','log_loss']].rename(columns={'log_loss':'core_loss'}),on='game_id',validate='one_to_one')
        candidate['delta']=candidate.log_loss-candidate.core_loss
        grouped=candidate.assign(date=candidate.decision_time.dt.strftime('%Y-%m-%d')).groupby(['season','date']).agg(s=('delta','sum'),n=('delta','size'))
        arrays=[g.to_numpy() for _,g in grouped.groupby(level=0)]; sampled=[]
        for _ in range(1000):
            s=n=0.
            for a in arrays:
                starts=rng.integers(0,len(a),size=int(np.ceil(len(a)/7)))
                idx=np.concatenate([(start+np.arange(7))%len(a) for start in starts])[:len(a)]
                s+=a[idx,0].sum(); n+=a[idx,1].sum()
            sampled.append(s/n)
        paired.append({'model':model,'delta_vs_core':float(candidate.delta.mean()),
                       'date_block_low':float(np.quantile(sampled,.025)),'date_block_high':float(np.quantile(sampled,.975)),
                       'folds_better':int((wide[model]<wide.core).sum()),'total_folds':len(wide),
                       'limitation':'exploratory date-block interval; shared-team/long-range dependence not fully represented'})
    write_json(target/'outcome.json',{'status':'completed','weights':choices,'probability_error_correlation':error_correlation,
        'paired_comparisons':paired,'holdout_acquired_or_scored':False,'source_timing_verdict':'REVIEW REQUIRED',
        'decision':'Keep core model as reference; no production promotion from development blending.'})
    assert pred.win_probability.between(0,1).all()
    assert not pred.duplicated(['game_id','model']).any()
    print(summary.to_string()); print(json.dumps(paired)); print('Error correlation',error_correlation)

if __name__=='__main__': main()
