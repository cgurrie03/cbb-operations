"""Reproduce the frozen numerical experiment into a new output directory."""
import argparse
from datetime import datetime,timezone
from pathlib import Path
import re
import shutil
import stage2_models
from stage2_data import OUT

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run-id',default='replay-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S'))
    a=p.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}',a.run_id): raise ValueError('Invalid run ID')
    target=OUT/'runs'/a.run_id
    target.mkdir(parents=True,exist_ok=False)
    shutil.copy2(OUT/'games.parquet',target/'games.parquet')
    stage2_models.OUT=target
    stage2_models.RUN_ID=a.run_id
    stage2_models.main()
    print(f'Replay saved to {target}')
