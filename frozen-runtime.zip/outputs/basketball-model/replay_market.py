"""Resolve archived full-game lines to ID-keyed replay games; never use scores to join."""
from pathlib import Path
import hashlib,json,re,unicodedata
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'blind-replay-20261014'
RAW=ROOT.parents[1]/'work/blind-replay-source-probe'
CACHE=ROOT.parents[1]/'work/basketball-seasons-raw'

def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower())

def resolve_and_join():
    games=pd.read_parquet(ROOT/'stage2/games.parquet');games=games[games.season.between(2023,2025)].copy()
    games['date']=games.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    # Public crosswalk aliases are keyed to ESPN IDs, never to scores or forecast outcomes.
    aliases={};ambiguous=[]
    for season in [2023,2024,2025]:
        ref=pd.read_parquet(next(CACHE.glob(f'team_crosswalk_{season}-*.parquet')))
        for row in ref.to_dict('records'):
            tid='espn:'+str(int(row['espn_team_id']))
            for col in ['espn_display_name','fox_team_name','espn_location','bart_team','kp_team']:
                n=row.get(col)
                if isinstance(n,str):aliases.setdefault((season,norm(n)),set()).add(tid)
        for row in games[games.season==season].to_dict('records'):
            for side in ['home','away']:aliases.setdefault((season,norm(row[side+'_name'])),set()).add(row[side+'_team'])
    explicit={
       'San Jos\ufffd St Spartans':'San Jose State','Army Knights':'Army','American Eagles':'American',
       "Florida Int'l Golden Panthers":'Florida International','Grand Canyon Antelopes':'Grand Canyon',
       'GW Revolutionaries':'George Washington','Houston Baptist Huskies':'Houston Christian',
       'Long Beach St 49ers':'Long Beach State','Grambling St Tigers':'Grambling',
       'Fort Wayne Mastodons':'Purdue Fort Wayne','LIU Sharks':'Long Island University',
       'UMKC Kangaroos':'Kansas City',"Mt. St. Mary's Mountaineers":"Mount St. Mary's",
       'N Colorado Bears':'Northern Colorado','Miss Valley St Delta Devils':'Mississippi Valley State',
       'Tenn-Martin Skyhawks':'UT Martin','Texas A&M-CC Islanders':'Texas A&M-Corpus Christi',
       'Seattle Redhawks':'Seattle U','St. Francis BKN Terriers':'St. Francis Brooklyn Terriers',
       'St. Thomas (MN) Tommies':'St. Thomas-Minnesota Tommies','Prairie View Panthers':'Prairie View A&M',
       'Arkansas-Little Rock Trojans':'Little Rock','SE Missouri St Redhawks':'Southeast Missouri State',
       'Texas A&M-Commerce Lions':'East Texas A&M Lions','IUPUI Jaguars':'IU Indianapolis Jaguars',
       'St. Francis (PA) Red Flash':'Saint Francis Red Flash',
    }
    def resolve(season,name,canonical):
        # A full-name exact match takes precedence; fallbacks must resolve to exactly one ID.
        for candidate,method in [(name,'exact full name'),(re.sub(r' St (?=\w)',' State ',name),'State abbreviation'),(explicit.get(name,''),'explicit identity alias'),(canonical,'reference canonical alias')]:
            if not candidate:continue
            ids=aliases.get((season,norm(candidate)),set())
            if len(ids)==1:return next(iter(ids)),method
        return None,'unresolved'
    mapping=[];allmarkets=[];rejected=[]
    for market,field in [('spreads','spread'),('totals','total')]:
        frame=pd.read_csv(RAW/(market+'-full.csv'));frame=frame[frame.season.between(2023,2025)].copy()
        frame['quote_time']=pd.to_datetime(frame.timestamp,utc=True,errors='coerce');frame['source_tipoff']=pd.to_datetime(frame.commence_time,utc=True,errors='coerce')
        frame['date']=frame.source_tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
        for side in ['home','away']:
            pairs=frame[['season',side+'_team',side+'_team_canonical']].drop_duplicates()
            lookup={}
            for season,name,canonical in pairs.itertuples(index=False,name=None):
                team,method=resolve(season,name,canonical);lookup[(season,name)]=team
                mapping.append(dict(season=season,source_name=name,canonical=canonical,espn_id=team,method=method))
            frame[side+'_id']=[lookup[(season,name)] for season,name in zip(frame.season,frame[side+'_team'])]
        for orientation in ['same','reversed']:
            left=frame.copy()
            if orientation=='reversed':left['home_id'],left['away_id']=frame.away_id,frame.home_id
            x=left.merge(games[['game_id','season','home_team','away_team','date','tipoff','decision_time']],left_on=['season','home_id','away_id','date'],right_on=['season','home_team','away_team','date'],how='inner',validate='many_to_one',suffixes=('_source','_game'))
            x['line']=x[field]*(-1 if orientation=='reversed' and market=='spreads' else 1)
            x['orientation']=orientation;x['market']=market
            valid=x.quote_time.notna() & x.line.notna() & (x.quote_time<=x.tipoff) & (x.quote_time>=x.tipoff-pd.Timedelta(hours=24)) & ((x.source_tipoff-x.tipoff).abs()<=pd.Timedelta(hours=2))
            valid &= x.line.abs().lt(80) if market=='spreads' else x.line.between(60,260)
            reject=x[~valid].copy();reject['reason']='quote timing, tipoff mismatch or invalid line';rejected.append(reject[['event_id','game_id','bookmaker','market','timestamp','line','reason']])
            allmarkets.append(x[valid][['event_id','game_id','season','market','bookmaker','quote_time','source_tipoff','tipoff','decision_time','line','orientation']])
    quotes=pd.concat(allmarkets,ignore_index=True).drop_duplicates()
    # Never choose arbitrarily among conflicting values stamped at the same time.
    keys=['game_id','market','bookmaker','quote_time'];conflicts=quotes.groupby(keys).line.transform('nunique')>1
    conflict_rows=quotes[conflicts];quotes=quotes[~conflicts].copy()
    quotes=quotes.sort_values(['quote_time','event_id']).drop_duplicates(['game_id','market','bookmaker'],keep='last')
    quotes['at_forecast_cutoff']=quotes.quote_time<=quotes.decision_time
    quotes['minutes_before_tip']=(quotes.tipoff-quotes.quote_time).dt.total_seconds()/60
    pd.DataFrame(mapping).drop_duplicates().to_csv(OUT/'market_team_alias_audit.csv',index=False)
    pd.concat(rejected,ignore_index=True).to_csv(OUT/'market_rejected_quotes.csv',index=False)
    conflict_rows.to_csv(OUT/'market_conflicting_quotes.csv',index=False)
    quotes.to_parquet(OUT/'matched_market_lines.parquet',index=False)
    quotes.groupby(['season','market','bookmaker']).agg(games=('game_id','nunique'),at_cutoff=('at_forecast_cutoff','sum'),median_minutes_before_tip=('minutes_before_tip','median')).reset_index().to_csv(OUT/'market_coverage.csv',index=False)
    used=set(quotes.game_id);missing=games[~games.game_id.isin(used)]
    missing[['game_id','season','tipoff','home_name','away_name']].to_csv(OUT/'games_without_market_lines.csv',index=False)
    print('Matched market rows',len(quotes),'games',len(used),'unresolved identities',pd.DataFrame(mapping).drop_duplicates().espn_id.isna().sum(),flush=True)
    return quotes

def summarize(g):
    if g.empty:return {}
    wins=int((g.grade=='win').sum());losses=int((g.grade=='loss').sum());pushes=int((g.grade=='push').sum());passes=int((g.grade=='pass').sum())
    a=g[g.grade.isin(['win','loss'])].copy();n=len(a)
    rate=wins/n if n else None
    if n:
        a['date']=a.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
        byday=a.groupby('date').grade.agg(n='size',wins=lambda x:(x=='win').sum()).to_numpy()
        rng=np.random.default_rng(137);boot=[]
        for _ in range(1000):
            starts=rng.integers(0,len(byday),size=int(np.ceil(len(byday)/7)));ix=np.concatenate([(s+np.arange(7))%len(byday) for s in starts])[:len(byday)]
            sample=byday[ix];boot.append(sample[:,1].sum()/sample[:,0].sum())
        low,high=map(float,np.quantile(boot,[.025,.975]))
    else:low=high=None
    return dict(n=len(g),wins=wins,losses=losses,pushes=pushes,passes=passes,accuracy=rate,date_block_95_low=low,date_block_95_high=high,
                model_mae=float((g.forecast-g.actual).abs().mean()),market_mae=float((g.market_forecast-g.actual).abs().mean()),
                at_forecast_cutoff=int(g.at_forecast_cutoff.sum()),median_minutes_before_tip=float(g.minutes_before_tip.median()))

def grade_market(quotes):
    summaries=[]
    for lag in [24,6]:
        pred=pd.read_parquet(OUT/f'graded-{lag}.parquet');x=quotes.merge(pred[['game_id','predicted_margin','predicted_total','margin','total']],on='game_id',validate='many_to_one')
        x['forecast']=np.where(x.market=='spreads',x.predicted_margin,x.predicted_total)
        x['market_forecast']=np.where(x.market=='spreads',-x.line,x.line)
        x['actual']=np.where(x.market=='spreads',x.margin,x.total)
        x['edge']=x.forecast-x.market_forecast
        x['pick']=np.where(x.market=='spreads',np.where(x.edge>0,'home','away'),np.where(x.edge>0,'over','under'))
        delta=x.actual-x.market_forecast
        x['grade']=np.where(x.edge.abs()<1e-10,'pass',np.where(delta.abs()<1e-10,'push',np.where(np.sign(x.edge)==np.sign(delta),'win','loss')))
        for (season,market,book),g in x.groupby(['season','market','bookmaker']):summaries.append(dict(lag_hours=lag,season=int(season),market=market,bookmaker=book,**summarize(g)))
        for (market,book),g in x.groupby(['market','bookmaker']):summaries.append(dict(lag_hours=lag,season='all',market=market,bookmaker=book,**summarize(g)))
        x.to_parquet(OUT/f'market_grades-{lag}.parquet',index=False)
    results=pd.DataFrame(summaries);results.to_csv(OUT/'market_metrics.csv',index=False)
    print(results[(results.lag_hours==24)&(results.bookmaker=='draftkings')].to_string(index=False),flush=True)

if __name__=='__main__':
    q=resolve_and_join();grade_market(q)
