"""Public schedule/results + cached protected quotes -> immutable paper records."""
import argparse,hashlib,json,math,re
from datetime import datetime,timezone,timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import joblib,numpy as np,pandas as pd
from preseason_prepare import OUT,ROOT,BASE,fetch,members,now,refresh_rosters
from preseason_features import OnlineFeatures
from spread_v3 import dump,sha
from spread_v4 import predict,decision,FEATURES
from blind_replay import emit_batch,SLATE
from stage2_models import CFG
from prospective_registry import save,canonical,stamp
from odds_history import normalize
from player_reports import eligible_report

SITE=ROOT.parent/'court-signal/dist'
PRIVATE=ROOT.parents[1]/'work/prospective-2027'
PAID_CACHE=ROOT.parents[1]/'work/odds-snapshots/latest.json'
OPENING='2026-11-02'

def slate(date):
    d,source=fetch(BASE+'scoreboard?dates='+date.replace('-','')+'&groups=50&limit=1000','schedules')
    events=d.get('events',[])
    if len(events)>=1000:raise ValueError('Schedule may be truncated')
    ids=members();rows=[]
    for e in events:
        c=e['competitions'][0];s={t['homeAway']:t for t in c['competitors']}
        if e['season']['year']!=2027 or e['season']['type'] not in [2,3]:continue
        tip=pd.Timestamp(e['date']);h='espn:'+str(s['home']['team']['id']);a='espn:'+str(s['away']['team']['id'])
        rows.append(dict(game_id='espn:'+e['id'],season=2027,tipoff=tip,decision_time=tip-pd.Timedelta(hours=1),
            home_team=h,away_team=a,home_name=s['home']['team']['displayName'],away_name=s['away']['team']['displayName'],
            neutral=c.get('neutralSite'),venue_effect=0 if c.get('neutralSite') else 1,
            time_confirmed=c.get('timeValid') is True,
            venue_state=c.get('venue',{}).get('address',{}).get('state'),
            eligible=h in ids and a in ids and isinstance(c.get('neutralSite'),bool),
            completed=c.get('status',{}).get('type',{}).get('completed',False),
            observed_at=source['observed_at'],source_sha256=source['sha256'],source_url=source['url']))
    return pd.DataFrame(rows),source

def normalize_result(event,summary,observed):
    """Only completed regular-season D1 games become prior-result data."""
    c=event['competitions'][0];s={t['homeAway']:t for t in c['competitors']};ids=members()
    h='espn:'+s['home']['team']['id'];a='espn:'+s['away']['team']['id'];tip=pd.Timestamp(event['date'])
    if event['season']['year']!=2027 or event['season']['type'] not in [2,3] or not c.get('timeValid') or not c['status']['type']['completed'] or h not in ids or a not in ids:return None,{}
    if tip+pd.Timedelta(hours=24)>pd.Timestamp(observed):return None,{}
    hs=float(s['home']['score']);aws=float(s['away']['score'])
    if hs<=0 or aws<=0 or hs==aws:raise ValueError('Invalid completed score')
    period=c['status'].get('period',2);duration=40+5*max(period-2,0)
    row=dict(game_id='espn:'+event['id'],season=2027,tipoff=tip,home_team=h,away_team=a,
        home_score=hs,away_score=aws,margin=hs-aws,won=int(hs>aws),total=hs+aws,
        neutral=bool(c.get('neutralSite')),venue_effect=0 if c.get('neutralSite') else 1,
        box_usable=False,pace40=np.nan,home_eff=np.nan,away_eff=np.nan,result_observed_at=observed,
        venue_state=c.get('venue',{}).get('address',{}).get('state'))
    boxes=summary.get('boxscore',{});lookup={str(t['team']['id']):{v['name']:v.get('displayValue') for v in t.get('statistics',[])} for t in boxes.get('teams',[])}
    try:
        for side,team in [('home',h),('away',a)]:
            v=lookup[team.split(':')[-1]]
            for key,prefix in [('fieldGoalsMade-fieldGoalsAttempted','field_goals'),('threePointFieldGoalsMade-threePointFieldGoalsAttempted','three_point_field_goals'),('freeThrowsMade-freeThrowsAttempted','free_throws')]:
                made,attempt=map(float,v[key].split('-'));row[side+'_'+prefix+'_made']=made;row[side+'_'+prefix+'_attempted']=attempt
            for key,name in [('offensiveRebounds','offensive_rebounds'),('defensiveRebounds','defensive_rebounds'),('turnovers','total_turnovers')]:row[side+'_'+name]=float(v[key])
            row[side+'_poss']=row[side+'_field_goals_attempted']-row[side+'_offensive_rebounds']+row[side+'_total_turnovers']+.475*row[side+'_free_throws_attempted']
        pace=(row['home_poss']+row['away_poss'])/2*40/duration
        if not 35<=pace<=110:raise ValueError('Invalid possessions')
        row.update(box_usable=True,pace40=pace,home_eff=100*hs/row['home_poss'],away_eff=100*aws/row['away_poss'])
    except (KeyError,ValueError,TypeError):row['box_usable']=False
    rotations={}
    for team in boxes.get('players',[]):
        tid='espn:'+str(team['team']['id']);minutes={}
        for group in team.get('statistics',[]):
            labels=group.get('labels',[])
            if 'MIN' not in labels:continue
            i=labels.index('MIN')
            for p in group.get('athletes',[]):
                try:
                    m=float(p['stats'][i]);aid=str(p['athlete']['id'])
                    if 0<m<=duration:minutes[aid]=m
                except (ValueError,TypeError,IndexError,KeyError):continue
        if minutes:rotations[tid]=minutes
    return row,rotations

def collect_results():
    folder=PRIVATE/'settled';folder.mkdir(parents=True,exist_ok=True)
    today=now().astimezone(ZoneInfo('America/New_York')).date()
    if today.isoformat()<=OPENING:return 0
    count=0
    cursor=PRIVATE/'result-cursor.json'
    start=datetime.fromisoformat(json.loads(cursor.read_text())['next_date']).date() if cursor.exists() else datetime.fromisoformat(OPENING).date()
    start=min(start,today-timedelta(days=1))
    for i in range(min((today-start).days,7)):
        day=start+timedelta(days=i)
        d,source=fetch(BASE+'scoreboard?dates='+day.strftime('%Y%m%d')+'&groups=50&limit=1000','results')
        for e in d.get('events',[]):
            path=folder/(e['id']+'.json')
            if path.exists() or e.get('season',{}).get('year')!=2027:continue
            if pd.Timestamp(e['date'])+pd.Timedelta(hours=24)>pd.Timestamp(source['observed_at']):continue
            if not e['competitions'][0]['status']['type'].get('completed'):continue
            summary,meta=fetch(BASE+'summary?event='+e['id'],'boxes')
            row,rotations=normalize_result(e,summary,meta['observed_at'])
            if row:
                dump(path,dict(game=row,rotations=rotations,source=meta));count+=1
        if day<today-timedelta(days=1):dump(cursor,dict(next_date=(day+timedelta(days=1)).isoformat()))
    return count

def history_at(cutoff):
    rows=[];rotations={};locations={}
    for path in (PRIVATE/'settled').glob('*.json'):
        d=json.loads(path.read_text());g=d['game'];g['tipoff']=pd.Timestamp(g['tipoff'])
        if max(g['tipoff']+pd.Timedelta(hours=24),pd.Timestamp(g['result_observed_at']))>cutoff:continue
        rows.append(g);locations[g['game_id']]=g.get('venue_state')
        for team,players in d['rotations'].items():rotations[(g['game_id'],team)]=players
    if rows:
        frame=pd.DataFrame(rows).sort_values(['tipoff','game_id']);frame['release']=frame.tipoff+pd.Timedelta(hours=24)
    else:
        frame=pd.read_parquet(OUT/'settled-history.parquet',filters=[('season','==',2027)])
        frame['release']=pd.Series(dtype='datetime64[ns, UTC]')
    return frame,rotations,locations

def feature_rows(frame,cutoff):
    history,rotations,locations=history_at(cutoff)
    seed=json.loads((OUT/'online-priors.json').read_text());state=OnlineFeatures(**seed)
    for g in history.to_dict('records'):state.update(g,rotations,locations)
    locations.update(dict(zip(frame.game_id,frame.venue_state)))
    online=pd.DataFrame([state.row(g,locations) for g in frame.to_dict('records')])
    batch=frame[SLATE].copy();batch['decision_time']=cutoff
    prior=json.loads((OUT/'efficiency-priors.json').read_text());prior={t:[v*CFG['carryover'] for v in a] for t,a in prior.items()}
    eff=emit_batch(batch,history,prior).rename(columns={'decision_time':'feature_decision_time'})
    x=frame.drop(columns='decision_time').merge(eff.drop(columns=['season','venue_effect']),on='game_id',validate='one_to_one')
    x=x.merge(online.drop(columns='season'),on='game_id',validate='one_to_one')
    x['decision_time']=frame.set_index('game_id').decision_time.reindex(x.game_id).to_numpy()
    return x

def cached_quotes(games,issued):
    """Read cached odds only; this function never opens a key or calls a paid API."""
    quotes=[]
    if not PAID_CACHE.exists():return quotes
    info=json.loads(PAID_CACHE.read_text());rows=normalize(info)
    safe=lambda s:re.sub('[^a-z0-9]','',s.lower())
    for game in games.itertuples():
        if not game.time_confirmed:continue
        relevant=[r for r in rows if r['market']=='spreads' and safe(r['home'])==safe(game.home_name) and safe(r['away'])==safe(game.away_name) and abs((pd.Timestamp(r['tipoff'])-game.tipoff).total_seconds())<=300]
        books={r['book'] for r in relevant}
        for book in books:
            r=[v for v in relevant if v['book']==book];h=[v for v in r if v['selection']=='home'];a=[v for v in r if v['selection']=='away']
            if len(h)!=1 or len(a)!=1 or abs(h[0]['point']+a[0]['point'])>1e-8:continue
            h,a=h[0],a[0];observed=pd.Timestamp(h['observed_at']);updated=max(pd.Timestamp(h['quote_at']),pd.Timestamp(a['quote_at']))
            if not updated<=observed<=issued or issued-observed>pd.Timedelta(minutes=15) or issued-updated>pd.Timedelta(minutes=15):continue
            if observed>game.decision_time:continue
            quotes.append(dict(game_id=game.game_id,line=h['point'],home_price=h['price'],away_price=a['price'],bookmaker=book,
                quote_observed_at=observed.isoformat(),quote_at=updated.isoformat(),quote_sha256=h['source_sha256'],source_url='https://the-odds-api.com/',
                source_timing='actual pre-cutoff observation and provider update'))
    return quotes

def coverage(game,cutoff):
    """Coverage is an explicit, source-linked attestation, not missing injury rows."""
    folder=ROOT.parents[1]/'work/player-reports';valid=set();uncertain=False
    for path in (folder/'coverage').glob('*.json'):
        for r in json.loads(path.read_text()):
            if r.get('game_id')!=game.game_id or not r.get('all_roster_reviewed'):continue
            try:
                pub,obs=map(stamp,[r['published_at'],r['observed_at']])
                if pub<=obs<=cutoff.to_pydatetime() and cutoff.to_pydatetime()-pub<=timedelta(hours=48) and r['source_url'].startswith('https://'):valid.add(r['team_id'])
            except (KeyError,ValueError,TypeError):continue
    for path in folder.glob('*.json'):
        for r in json.loads(path.read_text()):
            if r.get('game_id')==game.game_id and eligible_report(r,cutoff.isoformat()) and r.get('status') in ['out','questionable','doubtful']:uncertain=True
    return game.home_team in valid and game.away_team in valid and not uncertain

def capture(date):
    collect_results();frame,source=slate(date);observed=pd.Timestamp(source['observed_at'])
    eligible=frame[frame.eligible&frame.tipoff.gt(observed)&frame.decision_time.ge(observed)].copy()
    if eligible.empty:return dict(date=date,total=len(frame),eligible=0,issued=0,source=source,previews=[])
    refresh_rosters(list(eligible.home_team)+list(eligible.away_team))
    roster=json.loads((OUT/'roster-audit.json').read_text());teams={r['team_id']:r for r in roster['teams']}
    x=feature_rows(eligible,observed);quotes=cached_quotes(eligible,observed);q=pd.DataFrame(quotes)
    if len(q):
        x=x.merge(q,on='game_id',how='left',validate='one_to_many')
    else:
        for k in ['line','home_price','away_price']:x[k]=np.nan
        x['bookmaker']='unpriced';x['quote_observed_at']=None;x['quote_at']=None;x['quote_sha256']=None
    x['priced']=x.line.notna();x['line']=x.line.fillna(0.)
    x['raw_edge']=x.eff_margin+x.line;x['absolute_line']=x.line.abs();x['rating_market_edge']=x.rating_edge+x.line
    manifest=json.loads((OUT/'model-manifest.json').read_text());assert sha(OUT/'frozen-models.joblib')==manifest['model_sha256']
    p=predict(joblib.load(OUT/'frozen-models.joblib'),x)
    p=p[p.candidate.isin([manifest['candidate'],*manifest['controls']])].copy()
    p=decision(p,manifest['minimum_ev'],manifest['minimum_history'])
    offers=p[p.candidate.eq(manifest['candidate'])].sort_values(['expected_profit','bookmaker'],ascending=[False,True],na_position='last').drop_duplicates('game_id')[['game_id','bookmaker']]
    # Controls must score the SAME handicap and price, not pick a different event.
    p=p.merge(offers,on=['game_id','bookmaker'],validate='many_to_one')
    issued=0;previews=[]
    for g in eligible.itertuples():
        t=teams.get(g.home_team,{});a=teams.get(g.away_team,{})
        home=p[p.game_id.eq(g.game_id)&p.candidate.eq(manifest['candidate'])].iloc[0]
        previews.append(dict(game_id=g.game_id,home=g.home_name,away=g.away_name,tipoff=g.tipoff.isoformat() if g.time_confirmed else None,cutoff=g.decision_time.isoformat() if g.time_confirmed else None,time_confirmed=g.time_confirmed,
            carryover_margin=float(home.eff_margin),roster_uncertainty=t.get('uncertainty')=='high' or a.get('uncertainty')=='high',
            home_retained_minutes=t.get('retained_2026_d1_minutes_share'),away_retained_minutes=a.get('retained_2026_d1_minutes_share'),
            priced=bool(home.priced),paper_status='preview outside 24-hour issue window' if g.tipoff-observed>pd.Timedelta(hours=24) else 'paper snapshot window',
            availability_verified=False))
        if not g.time_confirmed or g.tipoff-observed>pd.Timedelta(hours=24):continue
        for row in p[p.game_id.eq(g.game_id)].to_dict('records'):
            issue=now();cutoff=g.decision_time.to_pydatetime()
            if issue>cutoff:continue
            verified=coverage(g,pd.Timestamp(issue));side=row['selected_side'];reason=row['pass_reason']
            if not row['priced']:side='pass';reason='missing or stale pre-cutoff spread price'
            elif not verified:side='pass';reason='availability coverage unverified'
            features={k:float(row[k]) for k in FEATURES};feature_hash=hashlib.sha256(json.dumps(features,sort_keys=True).encode()).hexdigest()
            record=dict(game_id=g.game_id,home=g.home_name,away=g.away_name,model_version=manifest['model_version'],candidate=row['candidate'],
                model_sha256=manifest['model_sha256'],issued_at=issue.isoformat(),cutoff=g.decision_time.isoformat(),tipoff=g.tipoff.isoformat(),
                features_observed_at=observed.isoformat(),feature_sha256=feature_hash,features=features,status='paper',
                bookmaker=row['bookmaker'],line=float(row['line']) if row['priced'] else None,
                home_price=float(row['home_price']) if row['priced'] else None,away_price=float(row['away_price']) if row['priced'] else None,
                home_cover_probability=float(row['home_cover_probability']) if row['priced'] else None,push_probability=float(row['push_probability']) if row['priced'] else None,
                research_side=row['selected_side'] if row['priced'] else 'pass',paper_side=side,pass_reason=reason,
                expected_profit=float(row['expected_profit']) if row['priced'] else None,availability_verified=verified,
                quote_observed_at=row['quote_observed_at'] if pd.notna(row['quote_observed_at']) else None,
                quote_at=row['quote_at'] if pd.notna(row['quote_at']) else None,quote_sha256=row['quote_sha256'] if pd.notna(row['quote_sha256']) else None,
                schedule_sha256=source['sha256'],roster_audit_sha256=sha(OUT/'roster-audit.json'),
                operational_release_sha256=sha(OUT/'release-manifest.json') if (OUT/'release-manifest.json').exists() else None,
                projected_margin=float(row['eff_margin']),production_promoted=False)
            save(record,PRIVATE/'forecasts');issued+=1
    return dict(date=date,total=len(frame),eligible=len(eligible),priced_games=len({q['game_id'] for q in quotes}),issued=issued,source=source,previews=previews)

def grade():
    records=[json.loads(p.read_text()) for p in (PRIVATE/'forecasts').glob('*.json')];rows=[]
    for r in canonical(records):
        path=PRIVATE/'settled'/(r['game_id'].split(':')[-1]+'.json')
        if not path.exists():continue
        g=json.loads(path.read_text())['game'];row={**r}
        timing=stamp(r['issued_at'])<=stamp(g['tipoff'])-timedelta(hours=1)
        q=r['home_cover_probability'];line=r['line'];side=r['paper_side'];row['timing_valid']=timing
        row['grade']='unpriced' if q is None else 'invalid timing' if not timing else 'pass' if side=='pass' else 'push' if math.isclose(g['margin']+line,0,abs_tol=1e-10) else 'win' if ((g['margin']+line>0)==(side=='home')) else 'loss'
        row['profit']=None
        if row['grade'] in ['win','loss','push']:
            price=r['home_price'] if side=='home' else r['away_price'];row['profit']=-1. if row['grade']=='loss' else 0. if row['grade']=='push' else price/100 if price>0 else 100/abs(price)
        row['log_loss']=None;row['brier']=None
        if q is not None and timing and not math.isclose(g['margin']+line,0,abs_tol=1e-10):
            y=int(g['margin']+line>0);q=min(max(q,1e-6),1-1e-6);row['log_loss']=-y*math.log(q)-(1-y)*math.log(1-q);row['brier']=(q-y)**2
        row['actual_margin']=g['margin'];rows.append(row)
    dump(PRIVATE/'grades-latest.json',dict(graded_at=now().isoformat(),rows=rows))
    return rows

def run(date=None):
    release=OUT/'release-manifest.json'
    if release.exists():
        for file,digest in json.loads(release.read_text())['files'].items():
            if sha(ROOT/file)!=digest:raise RuntimeError('Frozen preseason source/artifact changed: '+file)
    PRIVATE.mkdir(parents=True,exist_ok=True)
    today=now().astimezone(ZoneInfo('America/New_York')).date();date=date or max(today.isoformat(),OPENING)
    result=capture(date);graded=grade();roster=json.loads((OUT/'roster-audit.json').read_text());manifest=json.loads((OUT/'model-manifest.json').read_text())
    records=canonical([json.loads(p.read_text()) for p in (PRIVATE/'forecasts').glob('*.json')])
    current=[r for r in records if r['candidate']==manifest['candidate']];valid=[r for r in graded if r['candidate']==manifest['candidate'] and r['log_loss'] is not None]
    bets=[r for r in graded if r['candidate']==manifest['candidate'] and r['profit'] is not None]
    dates={r['tipoff'][:10] for r in valid};eligible_review=len(valid)>=1000 and len(bets)>=200 and len(dates)>=30
    bands=[]
    for candidate in [manifest['candidate'],*manifest['controls']]:
        for low,high in [(.5,.51),(.51,.52),(.52,.55),(.55,.60),(.60,.70),(.70,1.000001)]:
            part=[r for r in graded if r['candidate']==candidate and r['log_loss'] is not None and low<=max(r['home_cover_probability'],1-r['home_cover_probability'])<high]
            probs=[max(r['home_cover_probability'],1-r['home_cover_probability']) for r in part]
            correct=[int((r['actual_margin']+r['line']>0)==(r['home_cover_probability']>=.5)) for r in part]
            bands.append(dict(candidate=candidate,low=low,high=min(high,1),games=len(part),predicted=sum(probs)/len(part) if part else None,observed=sum(correct)/len(part) if part else None))
    graded_by_id={(r['game_id'],r['candidate'],r['issued_at']):r for r in graded}
    public_ledger=[]
    for r in records:
        row={k:r.get(k) for k in ['game_id','home','away','model_version','candidate','issued_at','cutoff','tipoff','bookmaker','line','home_price','away_price','home_cover_probability','paper_side','pass_reason','availability_verified','quote_observed_at','quote_at','model_sha256','feature_sha256']}
        g=graded_by_id.get((r['game_id'],r['candidate'],r['issued_at']))
        if g:row.update(grade=g['grade'],hypothetical_profit=g['profit'],actual_margin=g['actual_margin'])
        else:row.update(grade='pending',hypothetical_profit=None)
        public_ledger.append(row)
    dump(SITE/'paper-ledger-2027.json',dict(updated_at=now().isoformat(),records=public_ledger))
    public=dict(updated_at=now().isoformat(),opening_day=OPENING,mode='paper only',production_promoted=False,
        model_version=manifest['model_version'],model_sha256=manifest['model_sha256'],frozen_at=manifest['frozen_at'],
        fit_through=2025,calibration_season=2026,minimum_ev=.02,minimum_history=8,
        schedule_date=date,schedule_games=result['total'],eligible_d1_games=result['eligible'],priced_games=result.get('priced_games',0),
        confirmed_tipoff_games=sum(bool(r['time_confirmed']) for r in result['previews']),
        forecasts_issued_total=len(current),new_snapshots=result['issued'],canonical_priced_graded=len(valid),paper_bets_graded=len(bets),active_dates=len(dates),
        roi=sum(r['profit'] for r in bets)/len(bets) if bets else None,log_loss=sum(r['log_loss'] for r in valid)/len(valid) if valid else None,
        formal_review_eligible=eligible_review,roster_teams=len(roster['teams']),rosters_captured=sum(t['roster_observed'] for t in roster['teams']),
        roster_observed_at=roster['observed_at'],coach_changes=sum(bool(t['coach_changed']) for t in roster['teams']),
        unverified_availability_teams=len(roster['teams']),previews=result['previews'],teams=roster['teams'],
        collection='Existing local five-per-day schedule; requires this computer and Codex to be available',
        limitations=['Roster presence is not injury clearance','No actual wagers or promoted betting advice','Missing or stale odds remain unpriced',
        'Opening forecasts shown today are previews, not issued paper forecasts outside 24 hours','Eight current-season games are required before selections',
            'First-week review checks data and timing, not refitting calibration'])
    public.update(calibration=bands,collection_review_due=today.isoformat()>='2026-11-09',
        operational_release_frozen=release.exists(),
        missed_settled_games=len({p.stem for p in (PRIVATE/'settled').glob('*.json')}-{r['game_id'].split(':')[-1] for r in records}))
    dump(SITE/'preseason-2027.json',public);dump(OUT/'readiness-latest.json',public)
    print(json.dumps({k:public[k] for k in ['opening_day','schedule_games','eligible_d1_games','priced_games','rosters_captured','forecasts_issued_total','new_snapshots','formal_review_eligible']}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--date');args=parser.parse_args();run(args.date)
