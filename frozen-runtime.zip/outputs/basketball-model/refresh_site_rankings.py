"""Refresh display-only AP ranks, refusing cross-season or future-dated polls."""
import json
from pathlib import Path
from datetime import datetime, timezone
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parents[2]
SITE=ROOT/'outputs/court-signal/dist/data.json'

def apply_poll(data, response, checked):
    polls=[p for p in response.get('rankings',[]) if p.get('type')=='ap']
    changed=0
    for game in data['upcoming']:
        valid=[p for p in polls if p.get('season',{}).get('year')==game.get('season')
               and p.get('date','')[:10]<=checked[:10] and p.get('date','')[:10]<=game['day']]
        poll=max(valid,key=lambda p:p.get('date',''),default=None)
        # The user selected CBS's dated initial snapshot. Keep it until a new-season poll exists.
        if poll is None and data.get('rankingsFeed',{}).get('initialSnapshot'):
            continue
        ranks={str(r.get('team',{}).get('id')):r.get('current') for r in (poll or {}).get('ranks',[])}
        for side in ['home','away']:
            key=game.get(side+'TeamId')
            if not key:
                import re
                match=re.search(r'/([0-9]+)\.png',game.get(side+'LogoSource') or '')
                key=match.group(1) if match else None
            rank=ranks.get(str(key))
            value=rank if isinstance(rank,int) and 1<=rank<=25 else None
            changed+=game.get(side+'Rank')!=value
            game[side+'Rank']=value
            game[side+'RankDate']=(poll or {}).get('date')
    valid=any(p.get('season',{}).get('year') in {g.get('season') for g in data['upcoming']} for p in polls)
    if valid or not data.get('rankingsFeed',{}).get('initialSnapshot'):
        data['rankingsFeed']={'source':'ESPN / AP Top 25','checkedAt':checked,'status':'available' if valid else 'current_season_unavailable'}
    return changed

def main():
    data=json.loads(SITE.read_text(encoding='utf8'))
    season=max(g['season'] for g in data['upcoming'])
    url=f'https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/rankings?season={season}'
    try:
        with urlopen(Request(url,headers={'User-Agent':'BasketballResearch/0.4'}),timeout=20) as response:
            result=json.load(response)
    except Exception:
        print('Rankings refresh unavailable; existing cache preserved')
        return
    changed=apply_poll(data,result,datetime.now(timezone.utc).isoformat())
    SITE.write_text(json.dumps(data,separators=(',',':')),encoding='utf8')
    print('Rankings:',data['rankingsFeed']['status'],'/',changed,'rank changes')

if __name__=='__main__':main()
