"""Normalize full-season public releases, preserving exclusions and unknowns."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from acquire_seasons import RAW, ROOT

OUT = ROOT / 'stage2'


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False, default=str), encoding='utf-8')


def load(family, season):
    manifest = json.loads((RAW / f'{family}_{season}.manifest.json').read_text())
    blob = (RAW / manifest['file']).read_bytes()
    if hashlib.sha256(blob).hexdigest() != manifest['sha256']:
        raise ValueError('Raw snapshot hash mismatch')
    return pd.read_parquet(RAW / manifest['file']), manifest


def normalize():
    OUT.mkdir(exist_ok=True)
    games, coverage, exclusions, manifests, memberships = [], [], [], [], []
    for season in range(2016, 2026):
        s, sm = load('schedule', season)
        b, bm = load('team_box', season)
        m, mm = load('membership', season)
        ncaa, nm = load('ncaa_schedule', season)
        cross, cm = load('game_crosswalk', season)
        manifests.extend([sm, bm, mm, nm, cm])
        if s.game_id.duplicated().any() or b.duplicated(['game_id','team_id']).any() or m.duplicated(['team_id','season']).any():
            raise ValueError(f'Duplicate source keys in {season}')
        if not (s.season == season).all() or not (b.season == season).all():
            raise ValueError('Season convention mismatch')
        members = set(m.loc[(m.subdivision_id == 'mbb:d1') & (m.team_id_source == 'espn'), 'team_id'].astype(str))
        memberships.append(m)
        s['home_team'] = s.home_id.astype('Int64').astype(str)
        s['away_team'] = s.away_id.astype('Int64').astype(str)
        member_ok = s.home_team.isin(members) & s.away_team.isin(members)
        complete = s.status_type_completed.eq(True) & s.status_type_state.eq('post')
        valid_score = s.home_score.notna() & s.away_score.notna() & s.home_score.ne(s.away_score) & s.home_score.gt(0) & s.away_score.gt(0)
        valid_time = s.date.notna() & s.time_valid.eq(True)
        valid_neutral = s.neutral_site.notna()
        eligible = member_ok & complete & valid_score & valid_time & valid_neutral
        for row in s.loc[~eligible].to_dict('records'):
            reasons=[]
            if str(row['home_team']) not in members or str(row['away_team']) not in members: reasons.append('non_D1_or_unmatched_membership')
            if not bool(row.get('status_type_completed')) or row.get('status_type_state') != 'post': reasons.append('not_completed')
            if pd.isna(row.get('home_score')) or pd.isna(row.get('away_score')) or row.get('home_score') == row.get('away_score') or min(row.get('home_score',0),row.get('away_score',0)) <= 0: reasons.append('invalid_score')
            if not bool(row.get('time_valid')) or pd.isna(row.get('date')): reasons.append('time_invalid')
            if pd.isna(row.get('neutral_site')): reasons.append('venue_unknown')
            exclusions.append({'season':season,'game_id':str(row['game_id']),'reasons':';'.join(reasons),'status':row.get('status_type_name')})
        s = s.loc[eligible].copy()
        s['tipoff'] = pd.to_datetime(s.date, utc=True)
        s['decision_time'] = s.tipoff - pd.Timedelta(minutes=60)
        s['result_available_assumed'] = s.tipoff + pd.Timedelta(hours=6)
        s['neutral'] = s.neutral_site.astype(bool)
        s['venue_effect'] = (~s.neutral).astype(int)
        s['overtime_periods'] = (s.status_period - s.format_regulation_periods).clip(lower=0)
        s['duration_minutes'] = 40 + 5*s.overtime_periods
        s['won'] = (s.home_score > s.away_score).astype(int)
        s['margin'] = s.home_score - s.away_score
        s['total'] = s.home_score + s.away_score
        s['home_name'], s['away_name'] = s.home_display_name, s.away_display_name
        s['home_conference'] = s.home_team.map(m.set_index('team_id').conference_id)
        s['away_conference'] = s.away_team.map(m.set_index('team_id').conference_id)
        fields=['team_score','field_goals_made','field_goals_attempted','three_point_field_goals_made',
                'three_point_field_goals_attempted','free_throws_made','free_throws_attempted',
                'offensive_rebounds','defensive_rebounds','total_turnovers']
        for side in ['home','away']:
            box = b.rename(columns={'team_id':side+'_id',**{f:side+'_'+f for f in fields}})
            s = s.merge(box[['game_id',side+'_id']+[side+'_'+f for f in fields]], on=['game_id',side+'_id'], how='left',validate='one_to_one')
        needed=[side+'_'+f for side in ['home','away'] for f in fields]
        box_ok=s[needed].notna().all(axis=1)
        mismatch=np.zeros(len(s),dtype=bool)
        for side in ['home','away']:
            fgm=s[side+'_field_goals_made']; fga=s[side+'_field_goals_attempted']
            tpm=s[side+'_three_point_field_goals_made']; tpa=s[side+'_three_point_field_goals_attempted']
            ftm=s[side+'_free_throws_made']; fta=s[side+'_free_throws_attempted']
            valid=(fgm>=0)&(fga>=fgm)&(tpm>=0)&(tpa>=tpm)&(tpm<=fgm)&(tpa<=fga)&(ftm>=0)&(fta>=ftm)
            valid &= (2*fgm+tpm+ftm == s[side+'_score']) & (s[side+'_team_score']==s[side+'_score'])
            valid &= s[side+'_offensive_rebounds'].ge(0)&s[side+'_defensive_rebounds'].ge(0)&s[side+'_total_turnovers'].ge(0)
            mismatch |= (box_ok & ~valid).to_numpy()
            s[side+'_poss'] = fga-s[side+'_offensive_rebounds']+s[side+'_total_turnovers']+.475*fta
        s['possessions'] = (s.home_poss+s.away_poss)/2
        s['pace40'] = s.possessions*40/s.duration_minutes
        s['home_eff'] = 100*s.home_score/s.possessions
        s['away_eff'] = 100*s.away_score/s.possessions
        s['box_usable'] = box_ok & ~mismatch & s.pace40.between(35,110) & s.overtime_periods.notna()
        s['box_score_mismatch'] = mismatch
        s['box_missing'] = ~box_ok
        s['phase'] = np.select([s.notes_headline.fillna('').str.contains('CHAMPIONSHIP',case=False)&s.season_type.eq(3),s.season_type.eq(3)],['national_postseason','other_postseason'],default='regular_or_conference_tournament')
        s['early_season'] = s.tipoff.dt.month.isin([11,12])
        s['source_publication_time'] = None
        s['retrieved_at'] = sm['retrieved_at']
        s['raw_sha256'] = sm['sha256']
        s['division_verified'] = True
        crossids=set(pd.to_numeric(cross.espn_game_id,errors='coerce').dropna().astype('int64'))
        # Independent count/date-score cross-check; no fuzzy name joins.
        ncaa_dates=pd.to_datetime(ncaa.game_date,format='mixed',errors='coerce')
        ns=pd.DataFrame({'date':ncaa_dates.dt.strftime('%Y-%m-%d'),'lo':ncaa[['home_score','away_score']].min(axis=1),'hi':ncaa[['home_score','away_score']].max(axis=1)})
        es=pd.DataFrame({'date':s.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d'),'lo':s[['home_score','away_score']].min(axis=1),'hi':s[['home_score','away_score']].max(axis=1)})
        nkeys=ns.groupby(['date','lo','hi']).size(); ekeys=es.groupby(['date','lo','hi']).size()
        matched=nkeys.to_frame('ncaa').join(ekeys.rename('espn'),how='inner')
        unique_matches=int(((matched.ncaa==1)&(matched.espn==1)).sum())
        coverage.append({'season':season,'schedule_rows':len(load('schedule',season)[0]),'completed_source_rows':int(complete.sum()),
                         'membership_teams':len(members),'membership_sources_disagree':int(m.sources_agree.eq(False).sum()),
                         'D1_eligible_games':len(s),'excluded_games':int((~eligible).sum()),'usable_box_games':int(s.box_usable.sum()),
                         'missing_box_games':int((~box_ok).sum()),'box_score_mismatches':int(mismatch.sum()),
                         'neutral_games':int(s.neutral.sum()),'overtime_games':int(s.overtime_periods.gt(0).sum()),
                         'crosswalk_id_matches':int(s.game_id.isin(crossids).sum()),'ncaa_schedule_rows':len(ncaa),
                         'ncaa_unique_date_score_agreements':unique_matches,
                         'min_tipoff':str(s.tipoff.min()),'max_tipoff':str(s.tipoff.max()),
                         'claim':'source-season coverage audited; exhaustive historical completeness not certified'})
        cols=['game_id','season','tipoff','decision_time','result_available_assumed','home_team','away_team','home_name','away_name',
              'home_score','away_score','won','margin','total','neutral','venue_effect','venue_id','home_venue_id','away_venue_id',
              'home_conference','away_conference','overtime_periods','duration_minutes','season_type','phase','early_season',
              'possessions','pace40','home_eff','away_eff','box_usable','box_score_mismatch','box_missing','source_publication_time',
              'division_verified','retrieved_at','raw_sha256']+needed
        games.append(s[cols])
        print(f'{season}: {len(s)} D1 games, {int(s.box_usable.sum())} usable boxes',flush=True)
    result=pd.concat(games,ignore_index=True).sort_values(['decision_time','game_id']).reset_index(drop=True)
    result.game_id='espn:'+result.game_id.astype(str)
    result.home_team='espn:'+result.home_team
    result.away_team='espn:'+result.away_team
    assert result.game_id.is_unique
    assert result.season.max()<2026
    result.to_parquet(OUT/'games.parquet',index=False)
    pd.concat(memberships).to_parquet(OUT/'memberships.parquet',index=False)
    pd.DataFrame(coverage).to_csv(OUT/'coverage.csv',index=False)
    pd.DataFrame(exclusions).to_csv(OUT/'excluded_games.csv',index=False)
    write_json(OUT/'source_manifest.json',manifests)
    write_json(OUT/'audit.json',{'verdict':'REVIEW REQUIRED','games':len(result),'seasons':10,
                               'missing_publication_times':len(result),'holdout_game_data_acquired':False,
                               'possession_coefficient':.475,'issues':['historical publication/schedule vintages unknown',
                               'NCAA cross-check is not exhaustive denominator','membership disagreement counts require review',
                               'box-score failures excluded from efficiency updates, not silently zero-filled']})
    return result


if __name__=='__main__': normalize()
