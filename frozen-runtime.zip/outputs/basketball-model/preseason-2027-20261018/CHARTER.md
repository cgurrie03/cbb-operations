# 2026–27 prospective paper-test charter

Frozen preparation date: October 18, 2026. Opening day: November 2, 2026 (season ending 2027).

Purpose: contemporaneous, append-only paper forecasts and no-bet decisions. No real wagers or live recommendations. Old retrospective seasons remain research, not fresh validation.

Primary candidate: enhanced_raw, unchanged spread-v4 algorithm and feature list. Refit only on information through 2025, calibrate 2026. These seasons are development history for this new forward test. Freeze all fitted parameters and hashes before any 2027 regular-season result. The calibrated candidate and market reference are recorded as controls. No hyperparameter tuning or candidate selection after opening-day outcomes.

Primary decision: choose the better expected-return side at the exact available bookmaker handicap and price; minimum expected profit .02 per unit risked; >=8 prior current-season D1 games for BOTH teams. Unverified/missing prices, stale quotes, insufficient history and unverified availability are recorded as passes. Early-season passes are expected; do not lower the threshold because a slate is empty. No force-bet rule.

Original information cutoff: listed tipoff minus60 minutes. Every actual issue/capture time is stored; no backdating. Quotes must have been captured before the cutoff and within15 minutes of issue, with provider update time no later than capture when supplied. Missing provider update time is flagged, not invented. Canonical per-game record is the latest actual eligible pre-cutoff snapshot, selected solely by timestamps. If no qualifying snapshot exists, label missed cutoff/unpriced; never reconstruct a forecast after the game.

Roster preparation: acquire season-tagged2027 rosters and2026 coach/roster controls with source hashes and actual capture times. Match ESPN player/team IDs. Compute retained2026 D1 minutes, incoming transfer minutes and coach-change warnings. These are descriptive inputs and uncertainty flags. There is no historically validated player-impact/coach coefficient: do not arbitrarily add points for a transfer or silently change the frozen primary model. A roster-adjusted projection, if emitted, is a separate explicitly exploratory companion, not calibrated betting confidence.

Availability: no report is not proof of health. Only source-linked game/player reports with published_at<=observed_at<=cutoff and age<=48h can be used. Explicit coverage attestation needed to mark team coverage verified. Current injury/participation cannot be inferred from later boxes or DNPs. Official sources are archived with TLS verification enabled. Failure of a source is reported; never disable TLS checks.

Features update from settled PRIOR2027 D1 results after a24h delay. Coefficients/calibration/selection rule stay frozen. Full settled2026 team strengths form offseason priors; previous feature code excludes any current-game outcome. Every artifact records model, feature, roster, quote and source hashes.

Evaluation: log loss and Brier on all eligible nonpush forecasts; calibration by fixed confidence bands, season month and minimum-history groups; ROI and drawdown on canonical paper selections at recorded prices; coverage, missing inputs, passes and missed cutoffs. Never count both sides/books as independent games. Keep controls on the identical game population. First-week review is for collector/timing/data failures only, not probability refitting. Formal performance review after>=1000 canonical priced forecasts and>=200 paper selections over>=30 active game dates. Insufficient evidence means continue paper collection. Any retraining is a new version scored prospectively.

Existing five-per-day odds requests and quota/key safeguards remain unchanged. Public ESPN schedule/result snapshots require no paid odds credits. Collection depends on this computer/Codex being awake; monitoring configuration does not prove a run occurred. No automation should publish credentials or private raw storage.
