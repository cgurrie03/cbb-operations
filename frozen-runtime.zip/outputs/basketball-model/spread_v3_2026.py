"""Acquire/normalize 2026 only after model selection; build prior-result-only ratings."""
import hashlib,inspect,json,urllib.request
from pathlib import Path
from datetime import datetime,timezone
import pandas as pd
import numpy as np
import stage2_data
from stage2_models import CFG,fit_daily
from blind_replay import ResultBroker,emit_batch,SLATE
from spread_v3 import ROOT,OUT,sha,dump

def main():
    selection=json.loads((OUT/'selection.json').read_text());raw=OUT/'raw';raw.mkdir(exist_ok=True)
    for family,tag,stem in [('ncaa_schedule','ncaa_mbb_schedule','ncaa_mbb_schedule'),('game_crosswalk','mbb_crosswalk','mbb_schedule_crosswalk')]:
        dest=raw/(family+'_2026.parquet')
        if not dest.exists():
            url=f'https://github.com/sportsdataverse/sportsdataverse-data/releases/download/{tag}/{stem}_2026.parquet'
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'BasketballResearch/0.7'}),timeout=60) as r:blob=r.read()
            dest.write_bytes(blob)
    acquisition=json.loads((OUT/'2026-acquisition-manifest.json').read_text())
    def load(family,year):
        assert year==2026
        path=raw/(family+'_2026.parquet');info=next((x for x in acquisition if x['family']==family),{'family':family,'season':2026,'sha256':sha(path)})
        info={**info,'retrieved_at':info.get('acquired_at',datetime.now(timezone.utc).isoformat())}
        return pd.read_parquet(path),info
    # Reuse the project's exact normalization rules in a separate output scope.
    # The old experiment and its acquisition guard are intentionally unchanged.
    source=inspect.getsource(stage2_data.normalize)
    assert 'range(2016, 2026)' in source and 'assert result.season.max()<2026' in source
    source=source.replace('range(2016, 2026)','[2026]').replace('assert result.season.max()<2026','assert result.season.max()==2026')
    (OUT/'normalization-source.py').write_text(source,encoding='utf-8')
    env=dict(vars(stage2_data));env.update({'OUT':OUT/'normalization','load':load})
    exec(compile(source,'normalization-source.py','exec'),env)
    games=env['normalize']();games.to_parquet(OUT/'games-2026.parquet',index=False)
    old=pd.read_parquet(ROOT/'stage2/games.parquet');priors={}
    for season,g in old.groupby('season',sort=True):
        prior={t:[v*CFG['carryover'] for v in values] for t,values in priors.items()}
        teams=sorted(set(prior)|set(g.home_team)|set(g.away_team))
        ids,o,d,t,m,*_=fit_daily(g,teams,prior)
        priors={team:[float(o[i]),float(d[i]),float(t[i]),float(m[i])] for team,i in ids.items()}
    prior={t:[v*CFG['carryover'] for v in values] for t,values in priors.items()}
    broker=ResultBroker(games,24);rows=[];poison=[]
    slate=games[SLATE].sort_values(['decision_time','game_id'])
    groups=list(slate.groupby(slate.decision_time.dt.strftime('%Y-%m-%d'),sort=True))
    for i,(day,batch) in enumerate(groups):
        cutoff=batch.decision_time.min();history=broker.available(cutoff,2026);f=emit_batch(batch,history,prior);rows.append(f)
        if i in [0,len(groups)//2,len(groups)-1]:
            altered=games.copy();hidden=altered.tipoff+pd.Timedelta(hours=24)>cutoff
            for col in ['margin','won','home_eff','away_eff','pace40','home_score','away_score','total']:
                if col in altered:altered.loc[hidden,col]=777
            other=emit_batch(batch,ResultBroker(altered,24).available(cutoff,2026),prior)
            pd.testing.assert_frame_equal(f,other,check_exact=True);poison.append({'date':day,'rows':len(batch),'passed':True})
        if i%35==0:print('2026 feature dates completed',i+1,'/',len(groups),flush=True)
    result=pd.concat(rows,ignore_index=True);assert result.game_id.is_unique
    assert not {'margin','won','home_score','away_score','total'}.intersection(result.columns)
    result.to_parquet(OUT/'features-2026.parquet',index=False)
    dump(OUT/'2026-feature-integrity.json',{'selection_frozen_before_acquisition':True,'selection_sha256':sha(OUT/'selection.json'),'games':len(games),'features':len(result),'poison_tests':poison,'release_lag_hours':24,'source_vintage_verified':False,'features_sha256':sha(OUT/'features-2026.parquet'),'games_sha256':sha(OUT/'games-2026.parquet')})
    print('2026 prior-result-only features ready:',len(result),flush=True)

if __name__=='__main__':main()
