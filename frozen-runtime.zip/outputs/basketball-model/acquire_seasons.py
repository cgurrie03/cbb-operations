"""Acquire bounded, hash-preserved SportsDataverse season releases."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
RAW = ROOT.parents[1] / 'work' / 'basketball-seasons-raw'
TAGS = {'schedule': ('espn_mens_college_basketball_schedules', 'mbb_schedule'),
        'team_box': ('espn_mens_college_basketball_team_boxscores', 'team_box'),
        'player_box': ('espn_mens_college_basketball_player_boxscores', 'player_box'),
        'membership': ('mbb_groups', 'mbb_team_group_seasons'),
        'ncaa_schedule': ('ncaa_mbb_schedule', 'ncaa_mbb_schedule'),
        'team_crosswalk': ('mbb_crosswalk', 'mbb_team_crosswalk'),
        'game_crosswalk': ('mbb_crosswalk', 'mbb_schedule_crosswalk')}


def request(url):
    with urlopen(Request(url, headers={'User-Agent': 'BasketballResearch/0.2'}), timeout=60) as r:
        return r.read()


def acquire(seasons, families):
    RAW.mkdir(parents=True, exist_ok=True)
    for family in families:
        tag, stem = TAGS[family]
        metadata = json.loads(request(f'https://api.github.com/repos/sportsdataverse/sportsdataverse-data/releases/tags/{tag}'))
        assets = {a['name']: a for a in metadata['assets']}
        for season in seasons:
            if season >= 2026 or season < 2016:
                raise ValueError('Development acquisition is restricted to 2016–2025')
            name = f'{stem}_{season}.parquet'
            asset = assets[name]
            index = RAW / f'{family}_{season}.manifest.json'
            if index.exists():
                info = json.loads(index.read_text())
                blob = (RAW / info['file']).read_bytes()
                if hashlib.sha256(blob).hexdigest() != info['sha256']:
                    raise ValueError('Raw release hash mismatch')
            else:
                blob = request(asset['browser_download_url'])
                if len(blob) != asset['size']:
                    raise ValueError('Incomplete release download')
                digest = hashlib.sha256(blob).hexdigest()
                fname = f'{family}_{season}-{digest}.parquet'
                with (RAW / fname).open('xb') as f:
                    f.write(blob)
                info = {'family': family, 'season': season, 'file': fname, 'sha256': digest,
                        'url': asset['browser_download_url'], 'asset_id': asset['id'],
                        'asset_updated_at': asset['updated_at'], 'bytes': len(blob),
                        'retrieved_at': datetime.now(timezone.utc).isoformat(),
                        'original_publication_time': None,
                        'source': 'SportsDataverse hoopR-mbb-data / ESPN revised history'}
                with index.open('x', encoding='utf-8') as f:
                    json.dump(info, f, indent=2)
                time.sleep(0.3)
            print(f'{family} {season}: {len(blob):,} bytes cached', flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seasons', type=int, nargs='+', default=list(range(2016, 2026)))
    p.add_argument('--families', nargs='+', choices=list(TAGS), default=['schedule', 'team_box'])
    a = p.parse_args()
    acquire(a.seasons, a.families)
