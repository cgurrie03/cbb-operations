"""Copy reproducible research artifacts and publish explicit, complete findings."""
from pathlib import Path
import json,shutil,hashlib
import numpy as np
import pandas as pd
from spread_v3 import ROOT,sha,dump
from spread_v4 import OUT,FEATURES

DELIVER=Path(r'C:\Users\coope\Documents\Codex\2026-10-17\rev\outputs\spread-model-improvements')
SITE=ROOT.parent/'court-signal'

def main():
    DELIVER.mkdir(parents=True,exist_ok=True)
    result=json.loads((OUT/'results.json').read_text());f=pd.DataFrame(result['categories'])
    lines=['# Spread model improvements — October 17, 2026','',
        'Implemented and retrospectively evaluated stronger spread models, price-aware selection rules, and passing on weak or unverified games. No model demonstrated statistically significant return improvement. The production policy remains pass; enhanced models are research comparisons.','',
        '## Observed results','',
        'Fixed research rule: choose the side with the larger expected return at its recorded closing price, require at least 2% expected profit per unit risked and eight prior games for both teams. No threshold was optimized on these final results.','',
        '| Candidate / season | Bets | Wins–losses | Accuracy | Hypothetical ROI |','|---|---:|---:|---:|---:|']
    for candidate in ['basic_logistic','enhanced_raw','enhanced_margin','enhanced_calibrated']:
        for year in ['all',2025,2026]:
            r=f[(f.candidate==candidate)&(f.season==year)&f.minimum_ev.eq(.02)&f.category.eq('all')].iloc[0]
            label='Both seasons' if year=='all' else f'{year-1}–{str(year)[-2:]}'
            lines.append(f'| {candidate} / {label} | {r.bets:,} | {r.wins}–{r.losses} | {r.accuracy:.2%} | {r.roi:+.2%} |' if r.bets else f'| {candidate} / {label} | 0 | — | — | — |')
    r=f[f.candidate.eq('enhanced_raw')&f.season.eq('all')&f.minimum_ev.eq(.02)&f.category.eq('all')].iloc[0]
    lines += ['',f'The enhanced direct model selected {r.bets:,} of 11,505 covered games (2.15%), won {r.wins} and lost {r.losses}, and earned {r.profit_units:.3f} hypothetical units. Its 95% date-block return interval was {r.roi_low:+.2%} to {r.roi_high:+.2%}. Mean selected confidence was {r.mean_confidence:.2%}.',
        '',f'The previous raw model, forced to select on those SAME 247 games at its own side price, returned {r.baseline_roi:+.2%}. The enhanced-minus-previous return difference interval was {r.paired_delta_low:+.2%} to {r.paired_delta_high:+.2%}. Comparing the new selective portfolio only to the old all-game portfolio would confound model quality with selection.',
        '', 'No category passed the significance screen. The screen covers 252 combinations (six candidates × three fixed EV thresholds × fourteen predefined categories). It requires at least 100 selections in each final season, positive returns in both, and a positive one-sided Bonferroni-corrected lower bound for both return and paired improvement. Categories overlap. All cells, including zero selections and losses, are preserved in category-results.csv.',
        '', '## Changes implemented','',
        '| Change | Implementation and limits |','|---|---|',
        '| Market-based predictions | Retains each handicap as the starting point; estimates residual margin or conditional cover probability relative to it. |',
        '| Opponent-adjusted form | Sequential offense, defense and margin-strength updates; recent-five opponent-adjusted margin residuals. |',
        '| Matchup statistics | Smoothed prior effective shooting, turnover, rebounding, free-throw and three-point attempt rates, paired with opponent allowances. |',
        '| Rest and schedule | Prior rest and games within seven days; missing-history indicators. |',
        '| Observed roster continuity | Returning-player minute share, top-five concentration and rotation churn from prior player boxes only. Current-game participation is never used. This is not a verified current roster or injury report. |',
        '| Travel context | Change of venue state from the last known game, with missingness. It is a proxy, not distance, travel itinerary or time-zone adjustment. |',
        '| Uncertainty | Early-history and missing-data indicators; fixed shrinkage toward market probability; calibrated residual distributions split by history; 80% predictive margin intervals. Shrinkage is conservative policy, not proof of statistical coverage. |',
        '| Calibration | Sigmoid mapping fitted on a separate earlier season. The calibrated candidate did not produce a 2% EV opportunity. No invented high-confidence bets. |',
        '| Price-aware selections | Compare both sides using actual payouts and push probability; pass on invalid prices, low history or insufficient expected profit. |',
        '| Availability inputs | Added timestamped snapshot schema and as-of validation. Both publication and capture must precede cutoff. No trustworthy historical injury snapshots were available in this experiment, so injury effects were not fitted or backfilled. |',
        '| Production protection | Research results cannot authorize a live selection. A promoted model still requires fresh pre-cutoff prices and verified availability/timing. At most one offer is chosen per game. |',
        '| Category analysis | Home/away, favorite/underdog, venue, handicap size, season period and conference groups, by season and fixed rule, including negative results. |',
        '', '## Validation and model selection','',
        'Development fold 1: fit through 2021, calibrate 2022, evaluate 2023. Fold 2: fit through 2022, calibrate 2023, evaluate 2024. Final models: fit through 2023, calibrate 2024, retrospectively evaluate 2025 and 2026. Preprocessing is fitted inside each training fold. Log loss was fixed as the primary probability metric; Brier, ROI, calibration, margin intervals and drawdown are secondary.',
        '', 'The new candidates did not beat the 50% spread reference in both development seasons with the required 0.001 mean log-loss improvement. The rule therefore retained the reference and did not add a tree ensemble. There was no tuning after the final results. Both 2025 and 2026 had already been inspected in previous research, so these results are NOT a new untouched holdout and cannot support a prospective profitability claim.',
        '', 'Features freeze at the earliest pregame decision time in a UTC slate date, at least 60 minutes before listed tipoff. New historical scores, boxes and player minutes are released only at listed tipoff plus 24 hours. Offseason online rating carryover is 50%; rates reset; prior rotation identities come from the prior season already available at its last pregame cutoff. The final late-season games not settled by that cutoff do not update that prior. Existing efficiency features use their earlier frozen replay policy.',
        '', 'Return uncertainty uses 20,000 circular bootstrap resamples of seven active game dates, retaining zero-bet dates. Flat one-unit risk uses the recorded selected-side American price. Pushes return zero profit; this closing source has only half-point lines and no pushes. No wagers were placed. Bonferroni extreme-tail bounds are Monte Carlo estimates and are not a substitute for future validation.',
        '', '## Source and timing limitations','',
        'Games, team boxes, schedules and player minutes come from hash-preserved SportsDataverse/ESPN revised archives. Earlier market training lines are timestamped DraftKings records; final lines are ESPN provider-labeled closing fields, preferring DraftKings, then ESPN BET, then Caesars. The final cohort is 11,505 of 11,516 eligible games. Both selected-side prices are recorded. Exact closing capture timestamps are absent; do not claim these closing prices were executable at the earlier feature cutoff. Training/final sportsbook and season distributions differ.',
        '', 'Leakage verdict: REVIEW REQUIRED for historical original publication/revision vintages and schedule snapshots. Computational withholding tests passed; this does not certify the historical archive as a complete real-time reconstruction. The availability importer is implemented but no new verified injury feed or distance data is connected.',
        '', '## Next evidence required','',
        'Freeze the candidate and rule before any new outcomes, archive contemporaneous inputs and quotes, paper-grade every pass and selection, and evaluate after sufficient new games. Neither profitable retrospective slices nor these already-inspected seasons can replace that prospective test.',
        '', '## Reproduction','',
        'Implementation is in implementation/. Run spread_v4_features.py, then spread_v4.py develop, spread_v4.py predict, then spread_v4_grade.py and write_spread_v4_report.py. Feature/model/prediction stages refuse overwriting frozen artifacts. Original raw snapshots and earlier-stage dependencies are retained in the project workspace; the delivery includes manifests and hashes, not every historical raw box. Tests: python -m unittest test_spread_v4 -v.',
        '', 'The report, category results and ZIP ledger are linked from the website. The ledger contains every candidate/rule decision and pass, the exact side, handicap, price, cutoff, probabilities, expected profit and actual grade.']
    (OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    files=['REPORT.md','CHARTER.md','feature-manifest.json','selection.json','prediction-manifest.json','grading-integrity.json',
        'results.json','model-metrics.csv','development-metrics.csv','category-results.csv','decision-ledger.zip',
        'decision-ledger.parquet','frozen-models.joblib','final-predictions.parquet','features.parquet']
    for file in files:shutil.copy2(OUT/file,DELIVER/file)
    sources=['spread_v4.py','spread_v4_features.py','spread_v4_grade.py','spread_v4_policy.py','test_spread_v4.py','write_spread_v4_report.py']
    for directory in [DELIVER/'implementation',SITE/'research/spread-v4']:
        directory.mkdir(parents=True,exist_ok=True)
        for file in sources:shutil.copy2(ROOT/file,directory/file)
        for file in ['CHARTER.md','selection.json','feature-manifest.json','prediction-manifest.json','grading-integrity.json']:shutil.copy2(OUT/file,directory/file)
    dump(DELIVER/'artifact-checksums.json',{p.name:sha(p) for p in DELIVER.iterdir() if p.is_file() and p.name!='artifact-checksums.json'})
    for source,dest in [('results.json','spread-v4-results.json'),('REPORT.md','spread-v4-method.md'),('decision-ledger.zip','spread-v4-decisions.zip')]:
        shutil.copy2(OUT/source,SITE/'dist'/dest)
    print('Report, source snapshot and public data ready:',DELIVER,flush=True)

if __name__=='__main__':main()
