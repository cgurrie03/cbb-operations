"""First-party provider-labeled closes. Never fall back to current/live odds."""
import argparse,gzip,hashlib,json,re,time,urllib.request,urllib.error
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import numpy as np
import pandas as pd
from spread_v3 import OUT,ROOT,OLD,game_metadata,old_features,predict_candidates,probabilities,sha,dump
import joblib

PRIORITY={'draftkings':0,'espn bet':1,'caesars sportsbook':2,'caesars':2}
def number(value,price=False):
    if isinstance(value,dict):value=value.get('american',value.get('alternateDisplayValue'))
    if value is None:return None
    text=str(value).strip().replace('−','-')
    if text.upper() in ['EVEN','EV','PK','PICK','PICK\'EM']:return 100. if price else 0.
    try:
        result=float(text)
        return result if np.isfinite(result) and (not price or abs(result)>=100) else None
    except (ValueError,TypeError):return None
def team_id(team):
    ref=(team or {}).get('$ref','');m=re.search(r'/teams/(\d+)',ref)
    return 'espn:'+m.group(1) if m else None
def extract_close(response,game):
    valid=[];reasons=[]
    for item in response.get('items',[]):
        provider=item.get('provider',{});name=provider.get('name','');key=name.lower().strip()
        if 'live' in key or key not in PRIORITY:continue
        h=item.get('homeTeamOdds',{});a=item.get('awayTeamOdds',{})
        if not h.get('close') or not a.get('close'):reasons.append('missing_explicit_close');continue
        if team_id(h.get('team'))!=game['home_team'] or team_id(a.get('team'))!=game['away_team']:reasons.append('team_id_mismatch');continue
        line=number(h['close'].get('pointSpread'));other=number(a['close'].get('pointSpread'))
        if line is None or other is None or abs(line)>=80 or abs(line+other)>1e-8:reasons.append('invalid_or_asymmetric_handicap');continue
        hp=number(h['close'].get('spread'),price=True);ap=number(a['close'].get('spread'),price=True)
        row={'game_id':game['game_id'],'season':game['season'],'event_id':game['game_id'].split(':')[-1],'bookmaker':name,'provider_id':str(provider.get('id','')),'line':line,'home_price':hp,'away_price':ap,
             'tipoff':game['tipoff'],'quote_time':None,'quote_age_minutes':None,'tipoff_difference_minutes':None,'source_timing':'provider-labeled close; exact capture time unavailable',
             'source_url':item.get('$ref','').replace('http:','https:'),'priority':PRIORITY[key]}
        valid.append(row)
    if not valid:return None,';'.join(sorted(set(reasons))) or 'no_supported_nonlive_closing_provider'
    valid.sort(key=lambda r:(r['priority'],r['provider_id']))
    best=valid[0]
    same=[v for v in valid if v['provider_id']==best['provider_id']]
    if any(v['line']!=best['line'] or v['home_price']!=best['home_price'] or v['away_price']!=best['away_price'] for v in same):return None,'conflicting_provider_closes'
    return best,None
def fetch_all():
    assert (OUT/'selection.json').exists()
    meta=game_metadata();meta=meta[meta.season.isin([2025,2026])]
    cache=OUT/'raw/espn-close';cache.mkdir(parents=True,exist_ok=True)
    def get(game):
        event=game['game_id'].split(':')[-1];dest=cache/(event+'.json.gz');url=f'https://sports.core.api.espn.com/v2/sports/basketball/leagues/mens-college-basketball/events/{event}/competitions/{event}/odds'
        if dest.exists():
            with gzip.open(dest,'rb') as f:blob=f.read()
        else:
            error=None
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'CollegeBasketballResearch/0.8'}),timeout=25) as r:blob=r.read()
                    with gzip.open(dest,'wb') as f:f.write(blob)
                    break
                except Exception as e:
                    error=str(e)
                    if attempt<2:time.sleep(1+attempt*2)
            else:return {'game_id':game['game_id'],'error':error,'source_url':url},None
        try:
            data=json.loads(blob);row,reason=extract_close(data,game)
            info={'game_id':game['game_id'],'season':game['season'],'source_url':url,'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'accepted':row is not None,'reason':reason}
            return info,row
        except Exception as e:return {'game_id':game['game_id'],'error':str(e),'source_url':url},None
    manifest=[];rows=[];total=len(meta)
    with ThreadPoolExecutor(max_workers=6) as pool:
        jobs=[pool.submit(get,g) for g in meta.to_dict('records')]
        for i,job in enumerate(as_completed(jobs),1):
            info,row=job.result();manifest.append(info)
            if row:rows.append(row)
            if i%300==0:print(f'Closing-source records checked {i}/{total}; accepted {len(rows)}',flush=True)
    q=pd.DataFrame(rows)
    if len(q):
        q['tipoff']=pd.to_datetime(q.tipoff,utc=True);q['quote_time']=pd.to_datetime(q.quote_time,utc=True)
        q.to_parquet(OUT/'espn-closing-quotes.parquet',index=False)
    dump(OUT/'espn-closing-source-manifest.json',{'retrieved_at':datetime.now(timezone.utc).isoformat(),'selection_sha256':sha(OUT/'selection.json'),'source_code_sha256':sha(__file__),'games_requested':len(meta),'accepted':len(q),'records':manifest})
    print('Closing source fetch complete:',len(q),'accepted /',total,'requested',flush=True)
def predict_closes():
    target=OUT/'closing-predictions.parquet'
    if target.exists():raise RuntimeError('Refusing to overwrite frozen closing predictions')
    selection=json.loads((OUT/'selection.json').read_text());assert sha(OUT/'frozen-models.joblib')==selection['model_sha256']
    models=joblib.load(OUT/'frozen-models.joblib');quotes=pd.read_parquet(OUT/'espn-closing-quotes.parquet')
    meta=game_metadata();features=pd.concat([old_features(),pd.read_parquet(OUT/'features-2026.parquet')],ignore_index=True).rename(columns={'decision_time':'feature_decision_time'})
    x=quotes.merge(features.drop(columns=['season']),on='game_id',validate='one_to_one').merge(meta[['game_id','home_name','away_name']],on='game_id',validate='one_to_one')
    assert (x.feature_decision_time<=x.tipoff).all()
    x['raw_edge']=x.eff_margin+x.line;x['absolute_line']=x.line.abs()
    assert not {'margin','won','total','home_score','away_score'}.intersection(x.columns)
    x.to_parquet(OUT/'closing-pregame-inputs.parquet',index=False)
    p=predict_candidates(models,x)
    # Keep actual closing prices and source timing separate from the modeled event.
    p=p.merge(quotes[['game_id','home_price','away_price','source_url','source_timing','provider_id']],on='game_id',validate='many_to_one')
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import Ridge
    tr=pd.read_parquet(OLD/'train-24.parquet')
    core=make_pipeline(StandardScaler(),Ridge(alpha=20.)).fit(tr[['eff_margin','venue_effect']],tr.margin)
    base=p[p.candidate=='market_50'].copy();point=core.predict(x[['eff_margin','venue_effect']]);base['candidate']='original_core';base['predicted_margin']=point
    r=pd.read_parquet(ROOT/'confidence-check-20261017/earlier-heldout-residuals.parquet').residual.to_numpy()
    h,a,push=probabilities(point,x.line.to_numpy(),r);base['home_cover_probability']=h;base['push_probability']=push;base['selected_cover_probability']=np.where(point+x.line.to_numpy()>0,h,a)
    base['selected_side']=np.where(point+x.line.to_numpy()>0,'home',np.where(point+x.line.to_numpy()<0,'away','pass'));base['home_win_probability']=h*(1-push);base['away_win_probability']=a*(1-push)
    priced=p[p.candidate=='market_50'].copy();priced=priced[priced.home_price.notna()&priced.away_price.notna()].copy()
    decimal=lambda a:np.where(a>0,1+a/100,1+100/np.abs(a))
    hp=1/decimal(priced.home_price.to_numpy());ap=1/decimal(priced.away_price.to_numpy());prob=hp/(hp+ap)
    priced['candidate']='market_no_vig';priced['home_cover_probability']=prob;priced['selected_cover_probability']=np.maximum(prob,1-prob);priced['selected_side']=np.where(prob>.5+1e-12,'home',np.where(prob<.5-1e-12,'away','pass'));priced['home_win_probability']=prob*(1-priced.push_probability);priced['away_win_probability']=(1-prob)*(1-priced.push_probability)
    p=pd.concat([p,base,priced],ignore_index=True);p['is_selected']=p.candidate.eq(selection['selected_candidate']);p['model_version']='spread-v3-closing-research';p['market']='spreads';p['price_available']=p.home_price.notna()&p.away_price.notna()
    p.to_parquet(target,index=False)
    dump(OUT/'closing-prediction-manifest.json',{'created_at':datetime.now(timezone.utc).isoformat(),'predictions_sha256':sha(target),'inputs_sha256':sha(OUT/'closing-pregame-inputs.parquet'),'selection_sha256':sha(OUT/'selection.json'),'source_sha256':sha(OUT/'espn-closing-quotes.parquet'),'source_code_sha256':sha(__file__),'no_final_outcomes_in_predictor':True,'games_by_season':{str(y):int(len(g)) for y,g in x.groupby('season')},'capture_timestamp_available':False})
    print('Closing predictions frozen and hashed:',len(x),'games',flush=True)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['fetch','predict']);args=a.parse_args();{'fetch':fetch_all,'predict':predict_closes}[args.stage]()
