"""Streaming v4 feature state seeded from settled history before the 2027 season."""
from collections import defaultdict
import numpy as np,pandas as pd
from spread_v4_features import fresh,rates,NAMES

class OnlineFeatures:
    def __init__(self,prior=None,previous_players=None):
        self.prior=prior or {};self.previous_players=previous_players or {};self.states={};self.players=defaultdict(set)
    def state(self,team):
        if team not in self.states:self.states[team]=fresh(*[v*.5 for v in self.prior.get(team,[0.,0.,0.])])
        return self.states[team]
    def update(self,g,rotations,locations):
        h=self.state(g['home_team']);a=self.state(g['away_team'])
        err=float(np.clip(g['margin']-(h['rating']-a['rating']+3*g['venue_effect']),-30,30))
        h['rating']+=.08*err;a['rating']-=.08*err;h['form'].append(err);a['form'].append(-err)
        if g['box_usable']:
            he=float(np.clip(g['home_eff']-(100+h['off']+a['defense']+2*g['venue_effect']),-40,40))
            ae=float(np.clip(g['away_eff']-(100+a['off']+h['defense']-2*g['venue_effect']),-40,40))
            h['off']+=.08*he;a['defense']+=.08*he;a['off']+=.08*ae;h['defense']+=.08*ae
        for side,s in [('home',h),('away',a)]:
            team=g[side+'_team'];s['n']+=1;s['dates'].append(g['tipoff']);s['state']=locations.get(g['game_id'])
            if g['box_usable']:
                r=rates(g,side)
                if r is not None and np.isfinite(r).all():
                    alpha=1/(min(s['boxes'],9)+6);s['factors']+=(r-s['factors'])*alpha;s['boxes']+=1
            rotation=rotations.get((g['game_id'],team))
            if rotation:
                total=sum(rotation.values());share={str(p):m/total for p,m in rotation.items()}
                s['returning']=sum(v for p,v in share.items() if p in self.previous_players.get(team,set()))
                s['concentration']=sum(sorted(share.values(),reverse=True)[:5])
                s['churn']=1-sum(min(v,s['rotation'].get(p,0)) for p,v in share.items()) if s['rotation'] else 0.
                s['rotation']=share;self.players[team].update(share)
    def seed(self):
        return dict(prior={t:[s['rating'],s['off'],s['defense']] for t,s in self.states.items()},previous_players={t:sorted(p) for t,p in self.players.items()})
    def row(self,g,locations):
        h=self.state(g['home_team']);a=self.state(g['away_team']);hf=h['factors'];af=a['factors']
        rests=[min(max((g['tipoff']-s['dates'][-1]).total_seconds()/86400,0),30) if s['dates'] else None for s in [h,a]]
        congestion=[sum((g['tipoff']-d).total_seconds()<=7*86400 for d in s['dates']) for s in [h,a]]
        loc=locations.get(g['game_id']);travel=[int(s['state']!=loc) if s['state'] and loc else None for s in [h,a]]
        row=dict(game_id=g['game_id'],season=2027,home_prior_games=h['n'],away_prior_games=a['n'],
            rating_edge=h['rating']-a['rating']+3*g['venue_effect'],offense_diff=h['off']-a['off'],defense_diff=h['defense']-a['defense'],
            form_diff=np.mean(h['form'])-np.mean(a['form']) if h['form'] and a['form'] else 0.,
            efg_matchup=(hf[0]+af[5])-(af[0]+hf[5]),turnover_matchup=(hf[1]+af[6])-(af[1]+hf[6]),
            rebound_matchup=(hf[2]+af[7])-(af[2]+hf[7]),freethrow_matchup=(hf[3]+af[8])-(af[3]+hf[8]),three_rate_diff=hf[4]-af[4],
            rest_diff=rests[0]-rests[1] if None not in rests else 0.,rest_missing=int(None in rests),congestion_diff=congestion[0]-congestion[1],
            min_history=min(h['n'],a['n']),history_diff=h['n']-a['n'],rotation_diff=h['concentration']-a['concentration'],
            returning_diff=h['returning']-a['returning'],rotation_churn_diff=h['churn']-a['churn'],
            roster_missing=int(h['rotation'] is None or a['rotation'] is None),travel_change_diff=travel[0]-travel[1] if None not in travel else 0.,
            travel_missing=int(None in travel),box_missing=int(h['boxes']<3 or a['boxes']<3))
        assert np.isfinite([row[k] for k in NAMES]).all()
        return row
