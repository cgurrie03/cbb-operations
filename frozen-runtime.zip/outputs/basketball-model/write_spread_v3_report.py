"""Write research report and publishable derived summaries; never fit models."""
import json,shutil,math,zipfile
from pathlib import Path
import pandas as pd
import numpy as np
from spread_v3 import OUT,ROOT,sha,dump

SITE=ROOT.parent/'court-signal/dist'
NAMES={'market_50':'Market 50% reference','market_no_vig':'Market prices, no vig','historical_rate':'Historical home-cover rate','cover_logistic_raw':'Direct spread model','cover_logistic_calibrated':'Calibrated spread model','market_residual_ridge':'Market margin correction','original_core':'Original core (diagnostic)'}
def pct(x):return 'Unavailable' if x is None or pd.isna(x) else f'{100*x:.2f}%'
def num(x,n=4):return 'Unavailable' if x is None or pd.isna(x) else f'{x:.{n}f}'
def ci(x):return 'Unavailable' if not x or x[0] is None else f'{pct(x[0])} to {pct(x[1])}'
def metric_table(records):
    t='| Model | Games | W–L / pushes / passes | Cover rate | Log loss | Brier | Margin MAE | Hypothetical ROI |\n| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |\n'
    for r in records:
        t+=f"| {NAMES[r['candidate']]} | {r['games']:,} | {r['wins']:,}–{r['losses']:,} / {r['pushes']} / {r['passes']:,} | {pct(r['cover_accuracy'])} | {num(r['log_loss'])} | {num(r['brier'])} | {num(r['margin_mae'],3)} | {pct(r['hypothetical_roi'])} |\n"
    return t
def development_table(records):
    text='| Candidate | Season | Nonpush games | Log loss | Brier |\n| --- | ---: | ---: | ---: | ---: |\n'
    for r in records:text+=f"| {NAMES[r['candidate']]} | {r['season']} | {r['n']:,} | {r['log_loss']:.6f} | {r['brier']:.6f} |\n"
    return text
def main():
    data=json.loads((OUT/'results.json').read_text());selection=json.loads((OUT/'selection.json').read_text())
    closing=[r for r in data['metrics'] if r['cohort']=='provider_labeled_close'];primary=[r for r in data['metrics'] if r['cohort']=='timestamped_draftkings']
    coverage=[r for r in data['coverage'] if r['cohort']=='provider_labeled_close']
    source=json.loads((OUT/'espn-closing-source-manifest.json').read_text())
    report='''# Spread-first model evaluation — October 17, 2026

**Finding: the current model does not demonstrate a usable spread-betting advantage.** The spread-focused implementation is complete: market-aware candidates, chronological calibration, frozen per-bet probabilities, recorded prices, individual grades, confidence tables and a two-season closing-line comparison. None of the candidates passed the predeclared development gate, so the market reference is retained and no high-confidence betting model is promoted.

![Spread-cover reliability](spread-reliability.png)

## Two completed seasons, substantially complete line coverage

The requested last two completed seasons are **2024–25 and 2025–26** (ending years 2025 and 2026). The first response in this work initially described the older two-season range; it was corrected before development and acquisition. Earlier conversations only examined seasons through 2024–25. This experiment newly acquires 2025–26 after the candidate-selection lock.

The project found first-party historical **closing** fields at ESPN Core, even though ESPN's ordinary summary/scoreboard responses did not expose them. Each accepted record has explicit closes for both teams, a named non-live provider, exact ESPN team IDs, opposite handicaps and recorded side prices. Source priorities were fixed in advance: DraftKings, then ESPN BET, then Caesars. The source returned **11,505 valid closing records from 11,516 eligible games (99.90%)**:

| Completed season | Eligible D1–D1 games | Accepted closing lines | Missing |
| --- | ---: | ---: | ---: |
| 2024–25 | 5,764 | 5,762 | 2 |
| 2025–26 | 5,752 | 5,743 | 9 |

Providers: 2024–25 uses ESPN BET for 5,762 games. In 2025–26, 4,740 accepted records are DraftKings and 1,003 ESPN BET. All 11,505 accepted records have valid actual spread prices for both sides. These are provider-labeled closing records, **not authenticated exact capture timestamps** or guaranteed executable prices one hour earlier. Preserve that limitation when interpreting results.

All closing handicaps returned in this source population are half points, explaining zero pushes in the closing comparison. They were not rounded or altered by this analysis. The independent timestamped archive includes whole lines and pushes; it remains a separate sensitivity population. On 7,617 games shared with the accepted timestamped DraftKings archive, median absolute spread difference is zero and 62.65% of lines agree exactly; none differ by more than 10 points. This cross-check does not authenticate publication vintages or make the two providers identical.

## Original model versus the closing market

| Completed season | Original spread W–L | Original cover rate | Original margin MAE | Closing-line margin MAE | Original hypothetical ROI |
| --- | --- | ---: | ---: | ---: | ---: |
| 2024–25 | 2,856–2,906 | 49.57% | 9.102 points | **8.792 points** | −5.51% |
| 2025–26 | 2,862–2,881 | 49.83% | 9.293 points | **8.940 points** | −5.04% |

The original model was less accurate than the closing line as a point-margin forecast in both seasons. Its selected spread sides covered about half the time, and recorded prices produced negative hypothetical flat-stake returns.

## Newly implemented spread candidates

- Direct spread classifier: learn home cover from the pregame efficiency-versus-line gap, home handicap, absolute handicap, venue and expected pace.
- Calibrated classifier: a separate sigmoid mapping learned from a later calibration season, never from the final scored seasons.
- Market margin correction: Ridge predicts the residual around the sportsbook's margin, with a held-out earlier residual distribution and discrete push treatment.
- Market references: conditional 50% and same-book no-vig probabilities from actual prices; historical home-cover rate as a sanity baseline.

Base fits use 2021–2023; calibration uses 2024. The final two seasons are excluded from base fitting, probability calibration and candidate selection. Prior-result team ratings can update from legally earlier games; no same-game score or box statistic enters its own forecast. The source still uses revised historical vintages with unknown original publication times.

### 2024–25 closing-line comparison

'''+metric_table([r for r in closing if r['season']==2025])+'''

### 2025–26 closing-line comparison

'''+metric_table([r for r in closing if r['season']==2026])+'''

### Both seasons pooled

'''+metric_table([r for r in closing if r['season']=='all'])+'''

The direct raw spread classifier increased cover accuracy to **50.76% and 51.11%**, compared with the original 49.57% and 49.83%. That improvement did not cover the recorded prices: hypothetical returns remained **−2.98% and −2.26%**. The calibrated model's proper scores are much closer to the market reference than the original generic-error mapping, but this largely reflects correcting unsupported confidence toward 50%; it does not create an exploitable signal. The calibrated selection's cover rates are **49.93% and 49.12%**.

Market no-vig is a probability reference. Choosing whichever side has the larger market probability does not imply that its offered price is favorable; its hypothetical return is shown only as a descriptive comparison. Market 50% makes no betting selections and records passes; its margin forecast is simply the negative handicap.

## Development selection was frozen before the final seasons

Development folds scored 2023 and 2024, using earlier base-fitting and calibration seasons. Each learned candidate had to beat market log loss in both folds, with at least a 0.001 average gain to displace the simpler market reference. None passed. No trees were added because the simpler models did not establish repeated baseline improvement. The retained research policy is therefore **50% reference, no bet**. We did not select a favorable final-season model or confidence threshold after looking at results.

'''+development_table(data['development'])+'''

## Confidence bands: each side/line is graded individually

Every output record contains the game, sportsbook, handicap, actual price, probability, push probability, selected side, final grade and hypothetical profit. A different line or provider is a different recorded decision. Multiple models and books on the same game are not counted as independent evidence; comparisons use identical game populations and date-clustered uncertainty.

The calibrated model is not entitled to 70% confidence merely because a user wants a strong selection. If no calibrated predictions populate that band, the table must say so. The earlier original-core residual mapping remains labeled diagnostic and is not confused with the new calibrated spread probabilities.

'''
    for candidate in ['cover_logistic_raw','cover_logistic_calibrated','market_residual_ridge','original_core']:
        report+=f"\n### {NAMES[candidate]} — pooled closing confidence\n\n| Band | Decided | Mean predicted | Actual cover rate | W–L / pushes | 95% date-block interval |\n| --- | ---: | ---: | ---: | --- | --- |\n"
        rows=[r for r in data['confidence_buckets'] if r['cohort']=='provider_labeled_close' and r['season']=='all' and r['candidate']==candidate]
        for r in rows:report+=f"| {r['band']} | {r['decided']:,} | {pct(r['mean_probability'])} | {pct(r['observed_cover_rate'])} | {r['wins']}–{r['losses']} / {r['pushes']} | {ci(r['date_block_interval'])}{'; sparse' if r['sparse'] and r['decided'] else ''} |\n"
        h=next(r for r in data['seventy_percent'] if r['cohort']=='provider_labeled_close' and r['season']=='all' and r['candidate']==candidate and r['selection']=='about70')
        report+=f"\nAbout 70% (67.5–72.5%): **{h['decided']:,} decided games**, mean predicted {pct(h['mean_probability'])}, actual covers {pct(h['observed_cover_rate'])}; {h['wins']} W, {h['losses']} L, {h['pushes']} pushes.\n"
    report+='''

## Timing sensitivity: independently timestamped DraftKings archive

The original public archive provides actual quote timestamps. Apply the locked rule: latest nonconflicting quote before tipoff, age <=15 minutes, source/model tipoffs within five minutes, exact identity with explicit reversal when necessary. This source ends during 2025–26; do not call it full-season coverage or replace its missing dates with a closing field that has no timestamp.

'''+metric_table([r for r in primary if r['season']=='all'])+'''

Detailed per-season, exact-tipoff sensitivity, coverage exclusions, probability errors and paired log-loss intervals are in `results.json` and the CSV files. Missing games are not counted as wins. No actual prices were supplied in this timestamped archive, so its ROI remains unavailable. The full first-party closing source supplies the broader two-season comparison and price-aware diagnostic separately.

## Interpretation and limitations

**The model is not currently good enough to claim a spread-betting edge.** Its raw market-aware candidate modestly improves cover accuracy over the original point model, but remains below the level needed at its recorded prices; no learned candidate passed the locked development gate. A correct calibration layer shrinks unsupported probabilities rather than promising 70% covers. The appropriate outcome is to retain a no-edge reference while preserving the experiments for future testing.

2024–25 was already examined in previous development. 2025–26 was acquired only after this experiment's model/selection lock, and no final-season labels were used to fit or calibrate. However, team-feature publication times, historical schedule revisions and old provider vintages remain unresolved. The new closing-source evaluation also spans providers while the learned models were fitted on timestamped DraftKings data. This is a conditional historical research result, not a prospective performance guarantee.

Returns are hypothetical one-unit stakes at each recorded selected-side closing price. There were no actual wagers, no threshold search on final results and no claim of execution availability. Probability scoring includes all eligible nonpush events, even when the market reference's policy passes. Accuracy uses decided selections; pushes/passes and price coverage remain explicit. All-win/all-loss small groups can have degenerate nonparametric intervals; Wilson intervals are included as a descriptive supplement with an independence assumption.

## Verification and reproduction

Development choice, final model serialization and prediction files were hashed. Separate prediction workers read pregame fields and pre-2025 fitting/calibration data, then wrote frozen probabilities before the grading worker opened final outcomes. 2026 daily feature tests poison unavailable final scores and box fields at three cutoffs; earlier features remain exactly identical. Grading-time outcome poisoning changes only grades, never probabilities, sides or confidence bands. Proper probability sums, same-book prices, source IDs, exact joins, chronology and stored hashes are tested.

Sources:

- [ESPN Core historical game odds, example](https://sports.core.api.espn.com/v2/sports/basketball/leagues/mens-college-basketball/events/401746082/competitions/401746082/odds): only non-live explicit `close` fields, never `current` or `open` fallbacks. Individual source URLs/hashes are preserved in the source manifest.
- [SportsDataverse historical schedules](https://github.com/sportsdataverse/sportsdataverse-data/releases/tag/espn_mens_college_basketball_schedules): schedules, outcomes and team box scores; raw 2026 downloads are hash-preserved.
- [Timestamped historical archive](https://github.com/JDSB123/ncaam-historical-data/tree/b8c207c4a663c7a4378ebd4b6f2a245549f05198): independent timestamped spread sensitivity, with no archived prices.

Scripts: `spread_v3.py develop`, then `spread_v3_2026.py`, `spread_v3.py predict`, `espn_closing_lines.py fetch`, `espn_closing_lines.py predict`, `spread_v3_grade.py`, `write_spread_v3_report.py`. Existing frozen stages refuse to overwrite predictions/selection. Use a new experiment directory for a genuinely new fit. The current result can be regraded without editing forecasts. Core existing replay files were not overwritten. User-facing research is separate from upcoming forecast issuance; upcoming bets remain unissued.
'''
    (OUT/'REPORT.md').write_text(report,encoding='utf-8')
    # Derived summaries only; preserve the main schedule/odds data.json untouched.
    (SITE/'spread-research.json').write_text(json.dumps(data,separators=(',',':'),allow_nan=False),encoding='utf-8')
    shutil.copy2(OUT/'results.json',SITE/'spread-evaluation.json')
    notes=(OUT/'CHARTER.md').read_text(encoding='utf-8')+'\n\n'+(OUT/'CLOSING_SOURCE_ADDENDUM.md').read_text(encoding='utf-8')
    (SITE/'spread-method.md').write_text(notes,encoding='utf-8')
    compact=[];exports=[]
    for cohort in ['provider_labeled_close','timestamped_draftkings']:
        g=pd.read_parquet(OUT/(cohort+'-graded.parquet'));g['cohort']=cohort
        g['analysis_cutoff']=g.tipoff if cohort=='provider_labeled_close' else g.quote_time
        if 'source_timing' not in g:g['source_timing']='timestamped archive; <=15 minutes before tipoff'
        if 'source_url' not in g:g['source_url']='https://github.com/JDSB123/ncaam-historical-data/tree/b8c207c4a663c7a4378ebd4b6f2a245549f05198'
        columns=['cohort','game_id','season','candidate','model_version','bookmaker','tipoff','quote_time','analysis_cutoff','feature_decision_time','source_timing','source_url','home_name','away_name','selected_side','selected_team','selected_handicap','selected_price','selected_cover_probability','push_probability','grade','margin','hypothetical_profit']
        exports.append(g[columns])
        for gid,part in g.groupby('game_id',sort=False):
            r=part.iloc[0]
            clean=lambda v:None if pd.isna(v) else float(v)
            compact.append({'source':cohort,'id':gid,'season':int(r.season),'tipoff':r.tipoff.isoformat(),'home':r.home_name,'away':r.away_name,'book':r.bookmaker,'line':float(r.line),'homePrice':clean(r.home_price),'awayPrice':clean(r.away_price),'margin':float(r.margin),
                 'models':{row.candidate:{'side':row.selected_side,'probability':float(row.selected_cover_probability),'push':float(row.push_probability),'grade':row.grade,'profit':clean(row.hypothetical_profit)} for row in part.itertuples()}})
    compact.sort(key=lambda r:(r['tipoff'],r['id']),reverse=True)
    model_keys=list(NAMES);source_keys=['provider_labeled_close','timestamped_draftkings'];side_keys=['pass','home','away'];grade_keys=['pass','win','loss','push']
    rounded=lambda n:None if n is None else round(float(n),6)
    packed={'format':'spread-ledger-v1','models':model_keys,'sources':source_keys,'sides':side_keys,'grades':grade_keys,'rows':[]}
    for r in compact:
        forecasts=[[model_keys.index(name),side_keys.index(v['side']),rounded(v['probability']),rounded(v['push']),grade_keys.index(v['grade']),rounded(v['profit'])] for name,v in r['models'].items()]
        packed['rows'].append([source_keys.index(r['source']),r['id'],r['season'],r['tipoff'],r['home'],r['away'],r['book'],r['line'],r['homePrice'],r['awayPrice'],r['margin'],forecasts])
    (SITE/'spread-games.json').write_text(json.dumps(packed,separators=(',',':'),allow_nan=False),encoding='utf-8')
    pd.concat(exports,ignore_index=True).to_csv(OUT/'all-bet-decisions.csv',index=False)
    with zipfile.ZipFile(SITE/'spread-research-bets.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(OUT/'all-bet-decisions.csv','spread-research-bets.csv')
    previous_csv=SITE/'spread-research-bets.csv'
    if previous_csv.exists():
        assert previous_csv.resolve().parent==SITE.resolve();previous_csv.unlink()
    dump(OUT/'public-export-manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in [SITE/'spread-research.json',SITE/'spread-evaluation.json',SITE/'spread-games.json',SITE/'spread-research-bets.zip',SITE/'spread-method.md']},'per_game_quote_records':len(compact),'candidate_decisions':sum(len(e) for e in exports),'web_ledger_decimal_places':6,'csv_precision':'Full stored prediction precision'})
    print('Report, public summaries and per-bet ledger ready.',flush=True)

if __name__=='__main__':main()
