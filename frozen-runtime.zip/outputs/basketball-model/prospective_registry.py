"""Append-only spread paper forecasts, with real issue-time enforcement."""
from datetime import datetime,timezone,timedelta
from pathlib import Path
import hashlib,json,math

FORBIDDEN={'margin','won','total','home_score','away_score','final_score','actual_result','result','grade','profit'}
def stamp(value):
    t=datetime.fromisoformat(value.replace('Z','+00:00'))
    if t.tzinfo is None:raise ValueError('Timezone missing')
    return t.astimezone(timezone.utc)
def target_free(obj):
    if isinstance(obj,dict):
        if FORBIDDEN.intersection(obj):raise ValueError('Outcome leaked into forecast')
        for value in obj.values():target_free(value)
    elif isinstance(obj,list):
        for value in obj:target_free(value)
def save(record,folder,clock=None):
    current=clock() if clock else datetime.now(timezone.utc)
    target_free(record)
    required={'game_id','model_version','candidate','model_sha256','issued_at','cutoff','tipoff','features_observed_at',
              'feature_sha256','features','paper_side','pass_reason','status','home_cover_probability'}
    if not required.issubset(record):raise ValueError('Incomplete paper record')
    issued,cutoff,tip,observed=map(stamp,[record[k] for k in ['issued_at','cutoff','tipoff','features_observed_at']])
    if not observed<=issued<=cutoff<tip or not -5<=(current-issued).total_seconds()<=300:raise ValueError('Late or backdated paper forecast')
    if tip-issued>timedelta(hours=24):raise ValueError('Outside frozen 24-hour issue window')
    if record['status']!='paper' or record['paper_side'] not in ['home','away','pass']:raise ValueError('Invalid issue status')
    p=record['home_cover_probability']
    if p is not None and (not math.isfinite(p) or not 0<=p<=1):raise ValueError('Invalid probability')
    if hashlib.sha256(json.dumps(record['features'],sort_keys=True).encode()).hexdigest()!=record['feature_sha256']:raise ValueError('Feature hash mismatch')
    if p is not None:
        quote,updated=map(stamp,[record['quote_observed_at'],record['quote_at']])
        if not updated<=quote<=issued or issued-quote>timedelta(minutes=15) or issued-updated>timedelta(minutes=15):raise ValueError('Stale or future quote')
        if not all(isinstance(record.get(k),(int,float)) and math.isfinite(record[k]) for k in ['line','home_price','away_price']):raise ValueError('Incomplete priced forecast')
        if min(abs(record['home_price']),abs(record['away_price']))<100:raise ValueError('Invalid spread price')
    payload=json.dumps(record,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    identity='|'.join(str(record.get(k,'')) for k in ['game_id','model_version','candidate','issued_at'])
    key=hashlib.sha256(identity.encode()).hexdigest();folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);path=folder/(key+'.json')
    if path.exists():
        if path.read_bytes()!=payload:raise ValueError('Cannot revise an issued paper forecast')
    else:
        with path.open('xb') as f:f.write(payload)
    return dict(path=str(path),sha256=hashlib.sha256(payload).hexdigest())

def canonical(records):
    """One last eligible pre-cutoff snapshot per game/candidate; no outcome input."""
    rows={}
    for r in records:
        if stamp(r['issued_at'])>stamp(r['cutoff']):continue
        key=(r['game_id'],r['model_version'],r['candidate'])
        if key not in rows or stamp(r['issued_at'])>stamp(rows[key]['issued_at']):rows[key]=r
    return list(rows.values())
