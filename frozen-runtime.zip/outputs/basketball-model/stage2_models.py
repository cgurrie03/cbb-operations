"""Daily, cutoff-safe team ratings and matched season walk-forward experiments."""
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import ndtr, logit
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from stage2_data import OUT, ROOT, write_json
from pipeline import features as elo_features, config as stage1_config

CFG={'prior_games':8.,'carryover':.65,'home_eff':2.,'home_margin':3.,'iterations':60,
     'logistic_C':1.,'regression_alpha':20.,'venue_prior_games':30.,'seed':137,
     'first_test_season':2018,'last_test_season':2025,'interval_coverage':.8}


def fit_daily(history, teams, priors):
    """Alternating regularized offense/defense, pace and margin adjustments."""
    n=len(teams); ids={t:i for i,t in enumerate(teams)}
    prior=np.array([priors.get(t,[0,0,0,0]) for t in teams],dtype=float)
    off,defense,tempo,strength=prior.T.copy()
    league_eff,league_pace=100.,70.
    if history.empty:
        return ids,off,defense,tempo,strength,league_eff,league_pace,0.
    h=history.home_team.map(ids).to_numpy(dtype=int); a=history.away_team.map(ids).to_numpy(dtype=int)
    margin=history.margin.to_numpy()-CFG['home_margin']*history.venue_effect.to_numpy()
    ms=np.r_[h,a]; mo=np.r_[a,h]; my=np.r_[margin,-margin]
    mc=np.bincount(ms,minlength=n)
    b=history[history.box_usable].copy()
    if not b.empty:
        bh=b.home_team.map(ids).to_numpy(dtype=int); ba=b.away_team.map(ids).to_numpy(dtype=int)
        t=np.r_[bh,ba]; o=np.r_[ba,bh]
        y=np.r_[b.home_eff.to_numpy(),b.away_eff.to_numpy()]
        loc=np.r_[b.venue_effect.to_numpy(),-b.venue_effect.to_numpy()]
        q=np.r_[b.pace40.to_numpy(),b.pace40.to_numpy()]
        counts=np.bincount(t,minlength=n)
        league_eff=(1000*100+y.sum())/(1000+len(y))
        league_pace=(1000*70+q.sum())/(1000+len(q))
    p=CFG['prior_games']; delta=0.
    for _ in range(CFG['iterations']):
        old=np.c_[off,defense,tempo,strength]
        if not b.empty:
            off=(p*prior[:,0]+np.bincount(t,weights=y-league_eff-defense[o]-CFG['home_eff']*loc,minlength=n))/(p+counts)
            defense=(p*prior[:,1]+np.bincount(o,weights=y-league_eff-off[t]-CFG['home_eff']*loc,minlength=n))/(p+counts)
            next_t=(p*prior[:,2]+np.bincount(t,weights=q-league_pace-tempo[o],minlength=n))/(p+counts)
            tempo=.5*tempo+.5*next_t
        next_m=(p*prior[:,3]+np.bincount(ms,weights=my+strength[mo],minlength=n))/(p+mc)
        strength=.5*strength+.5*next_m
        delta=float(np.max(np.abs(np.c_[off,defense,tempo,strength]-old)))
    return ids,off,defense,tempo,strength,league_eff,league_pace,delta


def build_features(games, save_diagnostics=False):
    games=games.sort_values(['decision_time','game_id']).reset_index(drop=True)
    rows=[]; priors={}; convergence=[]
    for season, frame in games.groupby('season',sort=True):
        teams=sorted(set(frame.home_team)|set(frame.away_team))
        prior={t:[v*CFG['carryover'] for v in priors.get(t,[0,0,0,0])] for t in teams}
        decisions=frame.groupby(frame.decision_time.dt.strftime('%Y-%m-%d'),sort=True)
        for day,batch in decisions:
            cutoff=batch.decision_time.min()
            history=frame[frame.result_available_assumed<=cutoff]
            ids,off,defense,tempo,strength,base,pace,delta=fit_daily(history,teams,prior)
            convergence.append({'season':int(season),'date':day,'delta':delta})
            last=history.groupby('home_team').tipoff.max().to_dict()
            for t,v in history.groupby('away_team').tipoff.max().items():
                last[t]=max(last.get(t,v),v)
            appearances=pd.concat([history.home_team,history.away_team]).value_counts().to_dict()
            boxes=history[history.box_usable]
            boxcounts=pd.concat([boxes.home_team,boxes.away_team]).value_counts().to_dict()
            venue_edges={}
            if not history.empty:
                hist_pred=history.home_team.map(lambda t:strength[ids[t]])-history.away_team.map(lambda t:strength[ids[t]])+CFG['home_margin']*history.venue_effect
                residual=history.assign(venue_residual=history.margin-hist_pred)
                for venue,g in residual[~residual.neutral].groupby('venue_id',dropna=True):
                    venue_edges[str(int(venue))]=float(g.venue_residual.sum()/(CFG['venue_prior_games']+len(g)))
            for g in batch.to_dict('records'):
                h,a=ids[g['home_team']],ids[g['away_team']]
                expected_pace=float(np.clip(pace+tempo[h]+tempo[a],40,100))
                he=base+off[h]+defense[a]+CFG['home_eff']*g['venue_effect']
                ae=base+off[a]+defense[h]-CFG['home_eff']*g['venue_effect']
                rests=[]
                for team in [g['home_team'],g['away_team']]:
                    rests.append(min(max((g['tipoff']-last[team]).total_seconds()/86400,0),30) if team in last else None)
                rest_missing=int(any(r is None for r in rests))
                rest_diff=(rests[0]-rests[1]) if not rest_missing else 0.
                venue_edge=venue_edges.get(str(int(g['venue_id'])),0.) if pd.notna(g['venue_id']) and not g['neutral'] else 0.
                rows.append({'game_id':g['game_id'],'season':int(season),'decision_time':g['decision_time'],
                             'rating_cutoff':cutoff,'latest_result_used':history.result_available_assumed.max() if len(history) else None,
                             'venue_effect':g['venue_effect'],'eff_margin':(he-ae)*expected_pace/100,
                             'eff_total':(he+ae)*expected_pace/100,'expected_pace':expected_pace,
                             'home_offense':base+off[h],'away_offense':base+off[a],
                             'home_defense':base+defense[h],'away_defense':base+defense[a],
                             'strength_margin':strength[h]-strength[a]+CFG['home_margin']*g['venue_effect'],
                             'venue_edge':venue_edge,'rest_diff':rest_diff,'rest_missing':rest_missing,
                             'home_prior_games':appearances.get(g['home_team'],0),'away_prior_games':appearances.get(g['away_team'],0),
                             'home_prior_boxes':boxcounts.get(g['home_team'],0),'away_prior_boxes':boxcounts.get(g['away_team'],0),
                             'iteration_delta':delta})
        # Offseason prior uses the previous season's settled final results, all before next season.
        ids,off,defense,tempo,strength,_,_,_=fit_daily(frame,teams,prior)
        priors={t:[float(off[i]),float(defense[i]),float(tempo[i]),float(strength[i])] for t,i in ids.items()}
        print(f'features {season}: {len(frame)} games, {len(decisions)} daily cutoffs',flush=True)
    result=pd.DataFrame(rows)
    ef=elo_features(games,stage1_config())
    result=result.merge(ef[['game_id','elo_diff','elo_probability']],on='game_id',validate='one_to_one')
    known=result.latest_result_used.notna()
    assert (result.loc[known,'latest_result_used']<=result.loc[known,'rating_cutoff']).all()
    assert (result.rating_cutoff<=result.decision_time).all()
    if save_diagnostics:
        write_json(OUT/'convergence.json',convergence)
    return result


def logistic(train,test,columns):
    model=make_pipeline(StandardScaler(),LogisticRegression(C=CFG['logistic_C'],max_iter=1000))
    model.fit(train[columns],train.won)
    return model.predict_proba(test[columns])[:,1]


def loss(y,p):
    p=np.clip(p,1e-6,1-1e-6)
    return -(y*np.log(p)+(1-y)*np.log1p(-p))


def evaluate(games,features):
    df=games.merge(features.drop(columns=['season','decision_time','venue_effect']),on='game_id',validate='one_to_one')
    allpred=[]; metrics=[]; regression=[]; interval_history=[]; folds=[]
    model_features={'logistic_elo':['venue_effect','elo_diff'],
                    'efficiency_logistic':['venue_effect','eff_margin'],
                    'efficiency_context':['venue_effect','eff_margin','venue_edge','rest_diff','rest_missing']}
    for season in range(2017,2026):
        test=df[df.season==season].copy()
        train=df[(df.season<season)&(df.result_available_assumed<test.decision_time.min())]
        assert train.tipoff.max()<test.decision_time.min()
        assert set(train.game_id).isdisjoint(set(test.game_id))
        folds.append({'season':season,'train_n':len(train),'test_n':len(test),'train_last':str(train.result_available_assumed.max()),'test_first_decision':str(test.decision_time.min()),'score':season>=2018})
        y=test.won.to_numpy()
        probs={'constant':np.full(len(test),(train.won.sum()+1)/(len(train)+2)),
               'venue':np.array([(train.loc[train.venue_effect==v,'won'].sum()+1)/(int((train.venue_effect==v).sum())+2) for v in test.venue_effect]),
               'elo':test.elo_probability.to_numpy()}
        for model,col in [('margin_ratings','strength_margin'),('efficiency_gaussian','eff_margin')]:
            sigma=max(float((train.margin-train[col]).std()),1.)
            probs[model]=ndtr(test[col].to_numpy()/sigma)
        for model,columns in model_features.items(): probs[model]=logistic(train,test,columns)
        point={}
        for target,columns in [('margin',['eff_margin','venue_effect']),('total',['eff_total','expected_pace','venue_effect'])]:
            fitted=make_pipeline(StandardScaler(),Ridge(alpha=CFG['regression_alpha']))
            fitted.fit(train[columns],train[target])
            point[target]=fitted.predict(test[columns])
        intervals={}
        for target in ['margin','total']:
            earlier=[h[target] for h in interval_history]
            width=float(np.quantile(np.abs(np.concatenate(earlier)),CFG['interval_coverage'],method='higher')) if earlier else None
            intervals[target]=width
            if season>=2018:
                error=point[target]-test[target].to_numpy()
                regression.append({'season':season,'target':target,'n':len(test),'mae':float(np.abs(error).mean()),
                                   'rmse':float(np.sqrt(np.mean(error**2))),'interval_nominal':.8,
                                   'interval_coverage':float(np.mean(np.abs(error)<=width)) if width is not None else None,
                                   'interval_width':2*width if width is not None else None})
        interval_history.append({target:point[target]-test[target].to_numpy() for target in ['margin','total']})
        if season>=2018:
            for model,p in probs.items():
                p=np.clip(p,1e-6,1-1e-6)
                metrics.append({'season':season,'model':model,'n':len(test),'log_loss':float(loss(y,p).mean()),
                                'brier':float(np.mean((p-y)**2)),'accuracy':float(np.mean((p>=.5)==y))})
                part=test[['game_id','season','tipoff','decision_time','home_team','away_team','home_name','away_name','neutral','venue_effect','venue_id','phase','early_season','margin','total','won','home_prior_games','away_prior_games','home_prior_boxes','away_prior_boxes','home_conference','away_conference']].copy()
                part['model']=model; part['win_probability']=p; part['log_loss']=loss(y,p)
                part['expected_margin']=point['margin']; part['expected_total']=point['total']
                part['margin_low']=point['margin']-intervals['margin']; part['margin_high']=point['margin']+intervals['margin']
                part['total_low']=point['total']-intervals['total']; part['total_high']=point['total']+intervals['total']
                part['model_version']='research-v2'; part['actual_issue_time']=None
                part['availability_warning']='Availability not verified for historical forecast'
                part['historical_timing_verified']=False
                allpred.append(part)
        print(f'evaluation {season}: {len(test)} games, train {len(train)}',flush=True)
    pred=pd.concat(allpred,ignore_index=True)
    pd.DataFrame(metrics).to_csv(OUT/'results_by_season.csv',index=False)
    pd.DataFrame(regression).to_csv(OUT/'margin_total_results.csv',index=False)
    pred.to_parquet(OUT/'predictions.parquet',index=False)
    write_json(OUT/'folds.json',folds)
    write_json(OUT/'model_features.json',model_features)
    return pred


def diagnostics(pred):
    bins=[]; summaries=[]; slices=[]
    for model,p in pred.groupby('model'):
        y=p.won.to_numpy(); prob=p.win_probability.to_numpy()
        # Held-out labels used only for calibration diagnostics, never adjusted forecasts.
        cal=LogisticRegression(C=1e6,max_iter=1000).fit(logit(prob).reshape(-1,1),y)
        summaries.append({'model':model,'n':len(p),'log_loss':float(p.log_loss.mean()),
                          'brier':float(np.mean((prob-y)**2)),'accuracy':float(np.mean((prob>=.5)==y)),
                          'calibration_intercept':float(cal.intercept_[0]),'calibration_slope':float(cal.coef_[0,0])})
        for season,g in p.groupby('season'):
            indices=np.minimum((g.win_probability.to_numpy()*10).astype(int),9)
            for b in range(10):
                part=g.iloc[np.flatnonzero(indices==b)]
                bins.append({'model':model,'season':int(season),'bin':b,'n':len(part),
                             'mean_probability':float(part.win_probability.mean()) if len(part) else None,
                             'observed_rate':float(part.won.mean()) if len(part) else None})
        for field in ['neutral','early_season','phase','home_conference']:
            for value,g in p.groupby(field,dropna=False):
                slices.append({'model':model,'slice':field,'value':str(value),'n':len(g),'log_loss':float(g.log_loss.mean())})
        for label,mask in [('underdog',p.win_probability<.5),('favorite',p.win_probability>=.5),('strong_favorite',p.win_probability>=.8),('strong_underdog',p.win_probability<=.2),('cold_start',p[['home_prior_boxes','away_prior_boxes']].min(axis=1)<5)]:
            g=p[mask]
            if len(g): slices.append({'model':model,'slice':'pregame_group','value':label,'n':len(g),'log_loss':float(g.log_loss.mean())})
    pd.DataFrame(summaries).sort_values('log_loss').to_csv(OUT/'results_summary.csv',index=False)
    write_json(OUT/'calibration.json',{'verdict':'manual-review-required','bins':bins,'diagnostic_labels_only':True})
    pd.DataFrame(slices).to_csv(OUT/'error_slices.csv',index=False)
    uncertainty=[]
    rng=np.random.default_rng(CFG['seed'])
    comparisons=[(m,'margin_ratings') for m in ['logistic_elo','efficiency_gaussian','efficiency_logistic','efficiency_context']]
    comparisons.append(('efficiency_context','efficiency_logistic'))
    for model,reference_model in comparisons:
        reference=pred[pred.model==reference_model][['game_id','log_loss']].rename(columns={'log_loss':'reference_loss'})
        d=pred[pred.model==model].merge(reference,on='game_id',validate='one_to_one')
        d['loss_difference']=d.log_loss-d.reference_loss
        daily=d.assign(date=d.decision_time.dt.strftime('%Y-%m-%d')).groupby(['season','date']).agg(s=('loss_difference','sum'),n=('game_id','size'))
        season_arrays=[g[['s','n']].to_numpy() for _,g in daily.groupby(level=0)]
        samples=[]
        for _ in range(1000):
            total=count=0.
            for arr in season_arrays:
                starts=rng.integers(0,len(arr),size=math.ceil(len(arr)/7))
                indices=np.concatenate([(start+np.arange(7))%len(arr) for start in starts])[:len(arr)]
                total+=arr[indices,0].sum(); count+=arr[indices,1].sum()
            samples.append(total/count)
        # Dyadic team multiplier sensitivity: shared-team games receive coupled weights.
        teams=sorted(set(d.home_team)|set(d.away_team)); index={t:i for i,t in enumerate(teams)}
        h=d.home_team.map(index).to_numpy(); a=d.away_team.map(index).to_numpy()
        diff=d.loss_difference.to_numpy(); team_samples=[]
        for _ in range(1000):
            w=rng.exponential(1,size=len(teams)); game_w=w[h]*w[a]
            team_samples.append(float(np.sum(game_w*diff)/game_w.sum()))
        uncertainty.append({'model':model,'reference':reference_model,'n':len(d),
                            'mean_log_loss_difference':float(diff.mean()),
                            'date_block_95_low':float(np.quantile(samples,.025)),'date_block_95_high':float(np.quantile(samples,.975)),
                            'team_multiplier_95_low':float(np.quantile(team_samples,.025)),'team_multiplier_95_high':float(np.quantile(team_samples,.975)),
                            'limitation':'exploratory; 7 active dates per block; team multipliers are sensitivity, not exact confidence guarantees; no multiple-testing correction'})
    pd.DataFrame(uncertainty).to_csv(OUT/'paired_uncertainty.csv',index=False)


def main():
    games=pd.read_parquet(OUT/'games.parquet')
    experiment={'id':globals().get('RUN_ID','20261013-efficiency-context-v2'),'created_at':datetime.now(timezone.utc).isoformat(),
                'hypothesis':'daily adjusted efficiency improves matched development log loss over margin and Elo baselines',
                'config':CFG,'charter':'STAGE2_CHARTER.md','data_sha256':hashlib.sha256((OUT/'games.parquet').read_bytes()).hexdigest(),
                'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'primary_metric':'log_loss','success':'mean improvement and majority of folds; audit CLEAN needed for promotion',
                'status':'planned','seed':CFG['seed'],'command':'python stage2_models.py'}
    path=OUT/'experiment_pre_run.json'
    if path.exists(): raise ValueError('Experiment already exists; assign a new version before another fit')
    write_json(path,experiment)
    try:
        f=build_features(games, save_diagnostics=True)
        f.to_parquet(OUT/'features.parquet',index=False)
        p=evaluate(games,f)
        diagnostics(p)
        write_json(OUT/'experiment_outcome.json',{'status':'completed','decision':'follow-up',
                   'reason':'historical source timing remains REVIEW REQUIRED; no production promotion',
                   'holdout_scored':False,'models':sorted(p.model.unique()),'test_games':p.game_id.nunique()})
    except Exception as e:
        write_json(OUT/'experiment_outcome.json',{'status':'failed','error':repr(e)})
        raise


if __name__=='__main__':
    main()
