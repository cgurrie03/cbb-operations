"""Contemporaneous roster audit and frozen 2027 paper-model preparation."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,hashlib,json,urllib.request
import joblib,numpy as np,pandas as pd
from spread_v3 import ROOT,OUT as V3,sha,dump
from spread_v4_features import OUT as V4,load_games,load_context
from spread_v4 import fit,inputs,FEATURES
from stage2_models import fit_daily,CFG
from preseason_features import OnlineFeatures

OUT=ROOT/'preseason-2027-20261018'
BASE='https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/'
MEMBERSHIP=ROOT.parents[1]/'work/live-membership'

def now():return datetime.now(timezone.utc)

def fetch(url,kind):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'BasketballResearch/1.1'}),timeout=35) as r:blob=r.read()
    observed=now().isoformat();digest=hashlib.sha256(blob).hexdigest()
    directory=OUT/'raw'/kind;directory.mkdir(parents=True,exist_ok=True)
    filename=directory/(now().strftime('%Y%m%dT%H%M%S%fZ')+'-'+digest+'.json')
    with filename.open('xb') as f:f.write(blob)
    return json.loads(blob),dict(url=url,observed_at=observed,path=str(filename),sha256=digest)

def members():
    m=json.loads((MEMBERSHIP/'manifest.json').read_text());x=pd.read_parquet(MEMBERSHIP/m['file'])
    return set('espn:'+str(t) for t in x.loc[x.subdivision_id.eq('mbb:d1')&x.team_id_source.eq('espn'),'team_id'].astype(str))

def roster_snapshot(team,year):
    data,meta=fetch(BASE+f'teams/{team}/roster?season={year}','rosters')
    if data.get('season',{}).get('year')!=year or str(data.get('team',{}).get('id'))!=str(team):
        raise ValueError('Roster season/team mismatch')
    athletes=data.get('athletes',[])
    if not 5<=len(athletes)<=40:raise ValueError('Incomplete roster')
    ids=[str(a['id']) for a in athletes]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate roster athlete')
    return dict(team_id='espn:'+team,season=year,athletes=athletes,coach=data.get('coach',[]),
                name=data['team'].get('displayName',team),source=meta)

def acquire_rosters():
    teams,meta=fetch(BASE+'teams?groups=50&limit=1000','teams')
    teams=[t['team'] for t in teams['sports'][0]['leagues'][0]['teams']]
    ids=members();teams=[t for t in teams if 'espn:'+str(t['id']) in ids]
    results=[];errors=[]
    with ThreadPoolExecutor(max_workers=6) as pool:
        jobs={pool.submit(roster_snapshot,str(t['id']),year):(t['id'],year) for t in teams for year in [2026,2027]}
        for i,f in enumerate(as_completed(jobs),1):
            team,year=jobs[f]
            try:results.append(f.result())
            except Exception as e:errors.append(dict(team_id='espn:'+str(team),season=year,error_type=type(e).__name__))
            if i%100==0:print('Roster sources checked',i,'/',len(jobs),flush=True)
    stamp=now().strftime('%Y%m%dT%H%M%SZ')
    payload=dict(observed_at=now().isoformat(),teams_source=meta,rosters=results,errors=errors)
    dump(OUT/f'roster-snapshot-{stamp}.json',payload);dump(OUT/'rosters-latest.json',payload)
    print('Season-tagged rosters captured:',len(results),'failures:',len(errors),flush=True)

def audit_rosters():
    data=json.loads((OUT/'rosters-latest.json').read_text());by={(r['team_id'],r['season']):r for r in data['rosters']}
    p=pd.read_parquet(V4/'raw/player_box_2026.parquet')
    games=pd.read_parquet(V3/'games-2026.parquet')
    p['game_id']='espn:'+p.game_id.astype('int64').astype(str);p=p[p.game_id.isin(games.game_id)].dropna(subset=['athlete_id','team_id','minutes'])
    p=p[p.minutes.gt(0)&p.minutes.le(65)].copy();p['team_id']='espn:'+p.team_id.astype('int64').astype(str);p['athlete_id']=p.athlete_id.astype('int64').astype(str)
    mins=p.groupby(['team_id','athlete_id']).minutes.sum();team_minutes=p.groupby('team_id').minutes.sum()
    origins=p.groupby(['athlete_id','team_id']).minutes.sum().reset_index().sort_values(['minutes','team_id'],ascending=[False,True]).drop_duplicates('athlete_id').set_index('athlete_id')
    rows=[];players=[]
    for team in sorted(members()):
        current=by.get((team,2027));old=by.get((team,2026));ids={str(a['id']) for a in current['athletes']} if current else set()
        retained=sum(float(mins.get((team,a),0)) for a in ids);denom=float(team_minutes.get(team,0))
        incoming=[]
        for athlete in current['athletes'] if current else []:
            aid=str(athlete['id']);origin=origins.loc[aid,'team_id'] if aid in origins.index else None
            transfer=origin is not None and origin!=team
            if transfer:incoming.append(aid)
            players.append(dict(team_id=team,athlete_id=aid,name=athlete.get('displayName'),prior_team_id=origin,
                observed_prior_d1_minutes=float(origins.loc[aid,'minutes']) if origin else None,incoming_transfer=transfer,
                source_url=current['source']['url'],observed_at=current['source']['observed_at']))
        oldcoach={str(c.get('id')) for c in old['coach']} if old else set();newcoach={str(c.get('id')) for c in current['coach']} if current else set()
        changed=oldcoach!=newcoach if oldcoach and newcoach else None
        share=retained/denom if current and denom else None
        rows.append(dict(team_id=team,name=current['name'] if current else team,roster_season=2027,
            roster_observed=bool(current),roster_observed_at=current['source']['observed_at'] if current else None,
            roster_source_url=current['source']['url'] if current else None,roster_sha256=current['source']['sha256'] if current else None,
            listed_players=len(ids),retained_2026_d1_minutes_share=share,incoming_transfers_with_d1_history=len(incoming),
            coach_changed=changed,coach_ids=sorted(newcoach),
            uncertainty='high' if share is None or share<.4 or changed else 'normal',
            availability_verified=False,availability_status='unknown; roster presence does not prove availability'))
    dump(OUT/'roster-audit.json',dict(observed_at=data['observed_at'],teams=rows,players=players,errors=data['errors']))
    pd.DataFrame(rows).to_csv(OUT/'roster-audit.csv',index=False)
    print('Roster audit:',len(rows),'teams,',sum(r['roster_observed'] for r in rows),'observed,',sum(bool(r['coach_changed']) for r in rows),'coach changes',flush=True)

def refresh_rosters(team_ids):
    """Refresh next-slate rosters at most daily; preserve old observations on errors."""
    from datetime import timedelta
    path=OUT/'rosters-latest.json';data=json.loads(path.read_text())
    old={(r['team_id'],r['season']):r for r in data['rosters']};jobs=[]
    for team in sorted(set(team_ids)):
        row=old.get((team,2027))
        if not row or now()-datetime.fromisoformat(row['source']['observed_at'])>timedelta(hours=24):jobs.append(team)
    if not jobs:return
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures={pool.submit(roster_snapshot,t.split(':')[-1],2027):t for t in jobs}
        for f in as_completed(futures):
            try:r=f.result();old[(r['team_id'],2027)]=r
            except Exception as e:data['errors'].append(dict(team_id=futures[f],season=2027,error_type=type(e).__name__,observed_at=now().isoformat()))
    data['rosters']=list(old.values());data['observed_at']=now().isoformat();dump(path,data);audit_rosters()

def freeze():
    if (OUT/'frozen-models.joblib').exists():raise RuntimeError('Frozen preseason model already exists')
    old=inputs();closing=inputs(True)
    x=pd.concat([old,closing],ignore_index=True)
    games=load_games();y=games[['game_id','margin']]
    train=x.merge(y,on='game_id',validate='one_to_one');train['delta']=train.margin+train.line
    train['push']=np.isclose(train.delta,0,atol=1e-10,rtol=0);train['y']=train.delta.gt(0).astype(int)
    models=fit(train[train.season.le(2025)],train[train.season.eq(2026)])
    joblib.dump(models,OUT/'frozen-models.joblib')
    # Settled 2026 priors for both existing efficiency and new online features.
    efficiency={}
    for year,g in games.groupby('season',sort=True):
        prior={t:[v*CFG['carryover'] for v in a] for t,a in efficiency.items()}
        teams=sorted(set(g.home_team)|set(g.away_team)|set(prior))
        ids,o,d,t,m,*_=fit_daily(g,teams,prior)
        efficiency={team:[float(o[i]),float(d[i]),float(t[i]),float(m[i])] for team,i in ids.items()}
    # Store pre-2027 raw sources so daily feature reconstruction has an exact history.
    _,_,source_manifest=load_context()
    games.to_parquet(OUT/'settled-history.parquet',index=False)
    dump(OUT/'efficiency-priors.json',efficiency)
    dump(OUT/'model-manifest.json',dict(model_version='spread-paper-2027-v1',frozen_at=now().isoformat(),
        candidate='enhanced_raw',controls=['enhanced_calibrated','market_no_vig'],promotion=False,status='paper',
        minimum_ev=.02,minimum_history=8,primary_features=FEATURES,fit_seasons=sorted(map(int,train[train.season.le(2025)].season.unique())),
        calibration_season=2026,prospective_season=2027,cutoff_minutes=60,result_release_hours=24,
        model_sha256=sha(OUT/'frozen-models.joblib'),charter_sha256=sha(OUT/'CHARTER.md'),
        efficiency_priors_sha256=sha(OUT/'efficiency-priors.json'),history_sha256=sha(OUT/'settled-history.parquet'),
        feature_source_manifest=source_manifest,source_sha256=sha(__file__)))
    print('Prospective model frozen; no 2027 outcomes used.',flush=True)

def seed_online():
    if (OUT/'online-priors.json').exists():raise RuntimeError('Online seed already frozen')
    games=pd.read_parquet(OUT/'settled-history.parquet');rotations,locations,_=load_context();seed={}
    for year,g in games.groupby('season',sort=True):
        state=OnlineFeatures(**seed)
        for row in g.sort_values(['tipoff','game_id']).to_dict('records'):state.update(row,rotations,locations)
        seed=state.seed()
    dump(OUT/'online-priors.json',seed)
    print('Frozen online priors from settled 2026 history.',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['rosters','audit','freeze','seed']);a=p.parse_args()
    {'rosters':acquire_rosters,'audit':audit_rosters,'freeze':freeze,'seed':seed_online}[a.stage]()
