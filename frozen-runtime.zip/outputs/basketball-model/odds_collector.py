"""Five-per-day, quota-aware odds snapshots. Never logs credential-bearing URLs."""
from pathlib import Path
from ctypes import wintypes
import ctypes
from datetime import datetime,timezone
from datetime import timedelta
from zoneinfo import ZoneInfo
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError
import json,hashlib,re,sys
from odds_history import record,history_for
from player_reports import attach_reports

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'work/odds-snapshots'
SITE=ROOT/'outputs/court-signal/dist/data.json'
SECRET=ROOT/'work/odds-private/api-key.dpapi'
OUT.mkdir(parents=True,exist_ok=True)

class Blob(ctypes.Structure):
    _fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]

def load_key():
    raw=SECRET.read_bytes(); buffer=ctypes.create_string_buffer(raw)
    source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));result=Blob()
    crypt=ctypes.WinDLL('crypt32',use_last_error=True)
    crypt.CryptUnprotectData.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,
        ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
    crypt.CryptUnprotectData.restype=wintypes.BOOL
    if not crypt.CryptUnprotectData(ctypes.byref(source),None,None,None,None,1,ctypes.byref(result)):
        raise RuntimeError('The saved key cannot be opened by this Windows account')
    try:return ctypes.string_at(result.data,result.size).decode('utf-8')
    finally:
        kernel=ctypes.WinDLL('kernel32');kernel.LocalFree.argtypes=[ctypes.c_void_p]
        kernel.LocalFree(ctypes.cast(result.data,ctypes.c_void_p))

def safe_name(s):return re.sub(r'[^a-z0-9]','',s.lower())
def write(path,value):
    pending=path.with_suffix(path.suffix+'.pending');pending.write_text(json.dumps(value,separators=(',',':')),encoding='utf-8');pending.replace(path)

def collect():
    ledger_file=OUT/'usage.json';ledger=json.loads(ledger_file.read_text()) if ledger_file.exists() else {'calls':[],'credits_since_setup':0}
    now=datetime.now(timezone.utc);local=now.astimezone(ZoneInfo('America/New_York'));day=local.date().isoformat()
    today=[c for c in ledger['calls'] if c['day']==day]
    if len(today)>=5:return {'status':'daily_limit_reached','day':day,'requests_today':len(today)}
    if ledger['calls'] and (now-datetime.fromisoformat(ledger['calls'][-1]['at'])).total_seconds()<3600:
        return {'status':'recent_snapshot_reused','day':day,'requests_today':len(today)}
    if ledger.get('remaining') is not None and ledger['remaining']<3:
        return {'status':'quota_limit_reached','remaining':ledger['remaining']}
    rolling_credits=sum(c.get('credits',3) for c in ledger['calls'] if datetime.fromisoformat(c['at'])>now-timedelta(days=31))
    if rolling_credits+3>500:return {'status':'local_credit_guard_reached'}
    # Record an attempt before network access. Failures count toward the five/day guard.
    call={'at':now.isoformat(),'day':day,'status':'attempting'};ledger['calls'].append(call);write(ledger_file,ledger)
    key=load_key()
    params={'apiKey':key,'regions':'us','markets':'h2h,spreads,totals','oddsFormat':'american','includeLinks':'true'}
    endpoint='https://api.the-odds-api.com/v4/sports/basketball_ncaab/odds/'
    try:
        with urlopen(Request(endpoint+'?'+urlencode(params),headers={'User-Agent':'BasketballResearch/0.4'}),timeout=30) as response:
            payload=response.read();headers={k:response.headers.get(k) for k in ['x-requests-remaining','x-requests-used','x-requests-last']}
        if key.encode() in payload:raise RuntimeError('Unexpected credential-bearing provider response')
        events=json.loads(payload)
        if not isinstance(events,list):raise RuntimeError('Unexpected provider response')
    except HTTPError as error:
        call['status']='provider_error';call['http_status']=error.code;write(ledger_file,ledger)
        return {'status':'provider_error','http_status':error.code}
    except Exception:
        call['status']='connection_or_response_error';write(ledger_file,ledger)
        return {'status':'connection_or_response_error'}
    finally:key=None
    observed=datetime.now(timezone.utc).isoformat();digest=hashlib.sha256(payload).hexdigest()
    stamp=now.strftime('%Y%m%dT%H%M%SZ');raw_name=stamp+'-'+digest+'.json'
    (OUT/raw_name).write_bytes(payload)
    cost=int(float(headers['x-requests-last'])) if headers['x-requests-last'] is not None else 3
    ledger['credits_since_setup']+=cost
    ledger['remaining']=int(float(headers['x-requests-remaining'])) if headers['x-requests-remaining'] is not None else None
    ledger['provider_used']=int(float(headers['x-requests-used'])) if headers['x-requests-used'] is not None else None
    call.update(status='success',credits=cost,events=len(events));write(ledger_file,ledger)
    info={'collectedAt':observed,'provider':'The Odds API','regions':['us'],'markets':['h2h','spreads','totals'],
          'eventCount':len(events),'remainingCredits':ledger['remaining'],'creditsUsed':ledger['provider_used'],
          'lastRequestCredits':cost,'snapshotFile':raw_name,'sha256':digest,'events':events}
    write(OUT/'latest.json',info)
    write((OUT/raw_name).with_suffix('.metadata.json'),{k:v for k,v in info.items() if k!='events'})
    # Persist exact book/selection/line/price plus observation time for replay.
    # Normalization uses this response only; it never requests additional odds.
    record(info)
    data=json.loads(SITE.read_text());matched=0;unmatched=[]
    for game in data['upcoming']:game.pop('odds',None)
    for event in events:
        matches=[g for g in data['upcoming'] if safe_name(g['home'])==safe_name(event['home_team']) and safe_name(g['away'])==safe_name(event['away_team'])
            and abs((datetime.fromisoformat(g['tipoff'])-datetime.fromisoformat(event['commence_time'].replace('Z','+00:00'))).total_seconds())<=86400]
        if len(matches)==1:
            matches[0]['odds']={'eventId':event['id'],'collectedAt':observed,'bookmakers':event.get('bookmakers',[]),'homeName':event['home_team'],'awayName':event['away_team'],'history':history_for(event['id'])};matched+=1
        else:unmatched.append({'id':event['id'],'home':event['home_team'],'away':event['away_team'],'reason':'no unique exact team-and-date match'})
    data['oddsFeed']={k:v for k,v in info.items() if k!='events'}
    data['oddsFeed'].update(matchedGames=matched,unmatchedGames=len(unmatched),mode='five periodic snapshots/day',updateTimesEastern=['09:00','12:00','15:00','18:00','21:00'])
    reports=[]
    for report_file in (ROOT/'work/player-reports').glob('*.json'):
        reports.extend(json.loads(report_file.read_text(encoding='utf8')))
    attach_reports(data,reports,observed)
    write(SITE,data);write(OUT/'unmatched.json',unmatched)
    return {'status':'success','events':len(events),'matched_games':matched,'remaining_credits':ledger['remaining'],'request_credits':cost,'collected_at':observed}

if __name__=='__main__':
    try:
        import msvcrt
        with (OUT/'collector.lock').open('a+b') as lock:
            lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
            try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
            except OSError:
                print(json.dumps({'status':'collector_already_running'}));sys.exit(0)
            try:print(json.dumps(collect()))
            finally:lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
    except Exception:
        # Secret decryption and HTTP errors must not leak details into tool transcripts.
        print(json.dumps({'status':'setup_or_storage_error'}));sys.exit(1)
