"""Outcome-isolated prediction and separate grading for spread confidence diagnostics."""
from pathlib import Path
import argparse, hashlib, json, sys
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'blind-replay-20261014'
OUT=ROOT/'confidence-check-20261017'
COLS=['eff_margin','venue_effect']
EDGES=np.array([0,.5,.55,.6,.65,.7,.75,.8,.85,.9,.95,1.00000001])
LABELS=['Below 50%','50–55%','55–60%','60–65%','65–70%','70–75%','75–80%','80–85%','85–90%','90–95%','95–100%']
BOOT_WEIGHTS={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2,default=str,allow_nan=False),encoding='utf-8')
def fit_margin(train):return make_pipeline(StandardScaler(),Ridge(alpha=20.)).fit(train[COLS],train.margin)
def probabilities(forecast,handicap,residuals):
    """Home/away probabilities conditional on no push; raw push mass separate."""
    residuals=np.sort(np.asarray(residuals));boundary=-np.asarray(handicap)
    is_integer=np.isclose(boundary,np.round(boundary),rtol=0,atol=1e-10)
    # Rounded predicted margins imply integer final margins. Boundary ties in
    # continuous residual space have probability zero; half-up endpoints fixed.
    upper=np.where(is_integer,boundary+.5,boundary)-forecast
    lower=np.where(is_integer,boundary-.5,boundary)-forecast
    cdf=lambda values:np.searchsorted(residuals,values,side='left')/len(residuals)
    away=cdf(lower);home=1-cdf(upper);push=1-home-away
    return home/np.maximum(home+away,1e-12),away/np.maximum(home+away,1e-12),push
def bands(prob):return pd.cut(prob,EDGES,labels=LABELS,right=False,include_lowest=True)

def predict():
    if (OUT/'predictions.parquet').exists():raise RuntimeError('Refusing to overwrite frozen predictions')
    train=pd.read_parquet(OLD/'train-24.parquet')
    test=pd.read_parquet(OLD/'pregame-24.parquet')
    assert train.season.max()==2022 and test.season.min()==2023
    assert not set(['margin','won','total','home_score','away_score']).intersection(test.columns)
    assert train.release.max()<test.decision_time.min()
    known=test.latest_result_used.notna()
    assert (test.loc[known,'latest_result_used']<=test.loc[known,'rating_cutoff']).all()
    assert (test.rating_cutoff<=test.decision_time).all()
    residuals=[];folds=[]
    for year in range(2018,2023):
        v=train[train.season==year].copy()
        t=train[(train.season<year)&(train.release<v.decision_time.min())]
        assert t.release.max()<v.decision_time.min() and set(t.game_id).isdisjoint(v.game_id)
        prediction=fit_margin(t).predict(v[COLS])
        residuals.append(pd.DataFrame({'game_id':v.game_id,'season':year,'residual':v.margin-prediction}))
        folds.append({'season':year,'training_n':len(t),'residual_n':len(v),'training_last_release':str(t.release.max()),'first_cutoff':str(v.decision_time.min())})
    residuals=pd.concat(residuals,ignore_index=True)
    residuals.to_parquet(OUT/'earlier-heldout-residuals.parquet',index=False)
    point=fit_margin(train).predict(test[COLS])
    classifier=make_pipeline(StandardScaler(),LogisticRegression(C=1.,max_iter=1000)).fit(train[['venue_effect','eff_margin']],train.won)
    original=test[['game_id','season','decision_time']].copy()
    original['predicted_margin']=point
    original['win_probability']=classifier.predict_proba(test[['venue_effect','eff_margin']])[:,1]
    original.to_parquet(OUT/'recomputed-model-predictions.parquet',index=False)
    old=pd.read_parquet(OLD/'predictions-24.parquet').set_index('game_id').loc[original.game_id]
    for col in ['predicted_margin','win_probability']:
        np.testing.assert_allclose(old[col],original[col],atol=1e-12,rtol=0)
    # Only outcome-free quote fields are accepted. Matched source retains one
    # quote per event/book, verified against raw archive in this experiment.
    quotes=pd.read_parquet(OLD/'matched_market_lines.parquet')
    quotes=quotes[(quotes.market=='spreads')&(quotes.bookmaker=='draftkings')].copy()
    assert not quotes.duplicated(['game_id','market','bookmaker']).any()
    assert (quotes.quote_time<=quotes.tipoff).all()
    x=original.merge(quotes.drop(columns=['season','decision_time']),on='game_id',validate='one_to_one')
    home,away,push=probabilities(x.predicted_margin.to_numpy(),x.line.to_numpy(),residuals.residual.to_numpy())
    edge=x.predicted_margin+x.line
    x['spread_side']=np.where(edge>1e-10,'home',np.where(edge < -1e-10,'away','pass'))
    x['cover_probability']=np.where(edge>=0,home,away)
    x['push_probability']=push
    x['winner_confidence']=np.maximum(x.win_probability,1-x.win_probability)
    x['cover_band']=bands(x.cover_probability)
    x['winner_band']=bands(x.winner_confidence)
    x.to_parquet(OUT/'predictions.parquet',index=False)
    dump(OUT/'prediction-manifest.json',{'created_at':datetime.now(timezone.utc).isoformat(),'code_sha256':sha(__file__),'charter_sha256':sha(OUT/'CHARTER.md'),
         'files':{p.name:sha(p) for p in [OUT/'predictions.parquet',OUT/'recomputed-model-predictions.parquet',OUT/'earlier-heldout-residuals.parquet']},
         'source_hashes':{p.name:sha(p) for p in [OLD/'train-24.parquet',OLD/'pregame-24.parquet',OLD/'predictions-24.parquet',OLD/'matched_market_lines.parquet']},
         'folds':folds,'bin_edges':EDGES.tolist(),'about70':[.675,.725],'test_outcomes_read':False,'original_model_reproduced':True,
         'training_last_season':2022,'residual_count':len(residuals),'test_rows':len(test),'matched_spreads':len(x),'strict_cutoff_spreads':int(x.at_forecast_cutoff.sum())})
    print('Predictions frozen and hashed; no test outcomes read.',flush=True)

def grade_rows(pred,outcomes):
    x=pred.merge(outcomes,on='game_id',validate='one_to_one')
    assert len(x)==len(pred)
    delta=x.margin+x.line
    x['grade']=np.where(x.spread_side=='pass','pass',np.where(np.isclose(delta,0,atol=1e-10,rtol=0),'push',np.where((delta>0)==(x.spread_side=='home'),'win','loss')))
    x['winner_correct']=(x.win_probability>=.5)==x.won
    # Alternate wager on the predicted outright winner, explicitly separate.
    x['winner_side_ats']=np.where(np.isclose(delta,0,atol=1e-10,rtol=0),'push',np.where((delta>0)==(x.win_probability>=.5),'win','loss'))
    return x

def summary(g,prob,all_dates):
    valid=g[g.grade.isin(['win','loss'])]
    wins=int((valid.grade=='win').sum());losses=len(valid)-wins
    row={'n':len(g),'wins':wins,'losses':losses,'pushes':int((g.grade=='push').sum()),'passes':int((g.grade=='pass').sum()),
         'mean_probability':float(valid[prob].mean()) if len(valid) else None,'cover_rate':wins/len(valid) if len(valid) else None,
         'winner_accuracy':float(g.winner_correct.mean()) if len(g) else None,'sparse':len(valid)<100,'date_block_low':None,'date_block_high':None}
    if len(valid):
        daily=valid.assign(win=(valid.grade=='win').astype(int)).groupby('date').agg(n=('win','size'),wins=('win','sum')).reindex(all_dates,fill_value=0).to_numpy()
        days=len(all_dates)
        if days not in BOOT_WEIGHTS:
            rng=np.random.default_rng(137)
            starts=rng.integers(0,days,size=(2000,int(np.ceil(days/7))))
            ix=((starts[:,:,None]+np.arange(7))%days).reshape(2000,-1)[:,:days]
            weights=np.zeros((2000,days),dtype=np.int32)
            np.add.at(weights,(np.arange(2000)[:,None],ix),1)
            BOOT_WEIGHTS[days]=weights
        sample=BOOT_WEIGHTS[days]@daily
        valid_boot=sample[:,0]>0
        rates=sample[valid_boot,1]/sample[valid_boot,0]
        row['date_block_low'],row['date_block_high']=map(float,np.quantile(rates,[.025,.975]))
    return row

def score_metrics(g,prob):
    g=g[g.grade.isin(['win','loss'])];n=len(g)
    if not n:return {'n':0}
    p=np.clip(g[prob].to_numpy(),1e-6,1-1e-6);y=(g.grade=='win').to_numpy().astype(int)
    ece=0.
    for band in LABELS:
        m=bands(g[prob])==band
        if m.any():ece+=m.sum()/n*abs(p[m].mean()-y[m].mean())
    return {'n':n,'brier':float(np.mean((p-y)**2)),'log_loss':float(np.mean(-(y*np.log(p)+(1-y)*np.log1p(-p)))),'ece':float(ece),'baseline50_brier':.25,'baseline50_log_loss':float(np.log(2))}

def grade():
    manifest=json.loads((OUT/'prediction-manifest.json').read_text())
    for name,h in manifest['files'].items():assert sha(OUT/name)==h
    # Only the separate grading process opens test-game outcomes.
    outcomes=pd.read_parquet(ROOT/'stage2/games.parquet',columns=['game_id','margin','won','home_name','away_name'])
    pred=pd.read_parquet(OUT/'predictions.parquet')
    x=grade_rows(pred,outcomes)
    x['date']=x.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    all_dates=sorted(x.date.unique())
    records=[];highlights=[];metrics=[]
    for name,frame in [('one_hour_cutoff',x[x.at_forecast_cutoff]),('near_tipoff_benchmark',x)]:
        for season,g in [('all',frame),*list(frame.groupby('season'))]:
            for prob,kind in [('cover_probability','exploratory_cover_probability'),('winner_confidence','original_winner_confidence')]:
                for band in LABELS:
                    part=g[bands(g[prob])==band]
                    records.append({'population':name,'season':season,'probability_kind':kind,'band':band,**summary(part,prob,all_dates)})
                for band,mask in [('about70',(g[prob]>=.675)&(g[prob]<.725)),('70to75',(g[prob]>=.7)&(g[prob]<.75)),('at_least70',g[prob]>=.7),('all',pd.Series(True,index=g.index))]:
                    highlights.append({'population':name,'season':season,'probability_kind':kind,'selection':band,**summary(g[mask],prob,all_dates)})
            metrics.append({'population':name,'season':season,**score_metrics(g,'cover_probability')})
    pd.DataFrame(records).to_csv(OUT/'confidence-buckets.csv',index=False)
    pd.DataFrame(highlights).to_csv(OUT/'70-percent-check.csv',index=False)
    dump(OUT/'probability-metrics.json',metrics)
    x.to_csv(OUT/'game-by-game.csv',index=False)
    # Outcome poisoning changes grades only, never saved predictions or bands.
    poisoned=outcomes.copy();poisoned['margin']=999.;poisoned['won']=False
    changed=grade_rows(pred,poisoned)
    for col in ['spread_side','cover_probability','push_probability','cover_band','winner_band','win_probability']:
        pd.testing.assert_series_equal(x[col],changed[col],check_names=False)
    assert (x.grade!=changed.grade).any()
    for file,h in manifest['files'].items():assert sha(OUT/file)==h
    dump(OUT/'integrity.json',{'prediction_hashes_unchanged':True,'outcome_poison_preserves_probabilities_sides_and_bands':True,
         'test_games':17205,'matched':len(x),'unmatched':17205-len(x),'strict_cutoff':int(x.at_forecast_cutoff.sum()),
         'post_cutoff_quotes':int((~x.at_forecast_cutoff).sum()),'verdict':'REVIEW REQUIRED: original publication times and prior development selection unresolved'})
    print(pd.DataFrame(highlights).query("season=='all' and selection in ['all','about70','70to75']").to_string(index=False),flush=True)

def plot():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    table=pd.read_csv(OUT/'confidence-buckets.csv')
    table=table[(table.population=='near_tipoff_benchmark')&(table.season=='all')&(table.probability_kind=='exploratory_cover_probability')&(table.wins+table.losses>0)]
    from matplotlib.ticker import PercentFormatter
    fig,(ax,count_ax)=plt.subplots(1,2,figsize=(11,6),gridspec_kw={'width_ratios':[4,1.35]},layout='constrained')
    ax.plot([0,1],[0,1],ls='--',color='#777777',label='Perfect calibration')
    ax.axhline(.5,color='#999999',lw=1,label='50% reference')
    for row in table.itertuples():
        ax.errorbar(row.mean_probability,row.cover_rate,yerr=[[row.cover_rate-row.date_block_low],[row.date_block_high-row.cover_rate]],fmt='o',color='#176080',capsize=3)
    ax.set(xlim=(0,1),ylim=(0,1),xlabel='Exploratory predicted cover probability\n(excluding pushes)',ylabel='Observed spread cover rate',title='Historical spread probability check\nSeasons 2022–23 to 2024–25')
    ax.xaxis.set_major_formatter(PercentFormatter(1));ax.yaxis.set_major_formatter(PercentFormatter(1))
    ax.legend(loc='upper left',fontsize=9)
    count_ax.axis('off')
    count_table=count_ax.table(cellText=[[r.band,f'{r.wins+r.losses:,}'] for r in table.itertuples()],colLabels=['Band','Decided n'],loc='center',cellLoc='left',colLoc='left')
    count_table.auto_set_font_size(False);count_table.set_fontsize(9);count_table.scale(1,1.7)
    fig.text(.12,-.035,'DraftKings near-tipoff benchmark; most lines were recorded after the one-hour cutoff.\nEarlier-season residual mapping; not issued forecasts. Bars: 95% date-block bootstrap intervals.',fontsize=9)
    fig.savefig(OUT/'spread-calibration.png',dpi=180,bbox_inches='tight')
    plt.close(fig)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['predict','grade','plot']);args=parser.parse_args()
    {'predict':predict,'grade':grade,'plot':plot}[args.stage]()
