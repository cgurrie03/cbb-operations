"""Recover earlier archived quotes by identity and timestamps, without outcome access."""
from pathlib import Path
import numpy as np
import pandas as pd
from confidence_check import ROOT,OLD,OUT,probabilities,bands,sha,dump

def main():
    if (OUT/'cutoff-predictions.parquet').exists():raise RuntimeError('Refusing to overwrite frozen cutoff predictions')
    raw=ROOT.parents[1]/'work/blind-replay-source-probe/spreads-full.csv'
    q=pd.read_csv(raw);q=q[q.season.between(2023,2025)&q.bookmaker.eq('draftkings')].copy()
    aliases=pd.read_csv(OLD/'market_team_alias_audit.csv')[['season','source_name','espn_id']].drop_duplicates()
    assert not aliases.duplicated(['season','source_name']).any()
    for side in ['home','away']:
        q=q.merge(aliases.rename(columns={'source_name':side+'_team','espn_id':side+'_id'}),on=['season',side+'_team'],how='left',validate='many_to_one')
    q['quote_time']=pd.to_datetime(q.timestamp,utc=True)
    q['source_tipoff']=pd.to_datetime(q.commence_time,utc=True)
    q['date']=q.source_tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    games=pd.read_parquet(ROOT/'stage2/games.parquet',columns=['game_id','season','home_team','away_team','tipoff','decision_time'])
    games=games[games.season.between(2023,2025)]
    games['date']=games.tipoff.dt.tz_convert('America/New_York').dt.strftime('%Y-%m-%d')
    accepted=[]
    for orientation in ['same','reversed']:
        a=q.copy()
        if orientation=='reversed':a['home_id'],a['away_id']=q.away_id,q.home_id
        a=a.merge(games,on=['season','date'],suffixes=('_source','_game'))
        a=a[(a.home_id==a.home_team_game)&(a.away_id==a.away_team_game)].copy()
        a['line']=a.spread*(-1 if orientation=='reversed' else 1)
        valid=(a.quote_time<=a.decision_time)&(a.quote_time>=a.tipoff-pd.Timedelta(hours=24))&((a.source_tipoff-a.tipoff).abs()<=pd.Timedelta(hours=2))&a.line.abs().lt(80)
        a=a[valid].copy();a['orientation']=orientation
        accepted.append(a[['game_id','season','event_id','bookmaker','quote_time','source_tipoff','tipoff','decision_time','line','orientation']])
    q=pd.concat(accepted,ignore_index=True).drop_duplicates()
    conflicts=q.groupby(['game_id','bookmaker','quote_time']).line.transform('nunique')>1
    conflict_n=int(conflicts.sum());q=q[~conflicts].sort_values(['quote_time','event_id']).drop_duplicates(['game_id','bookmaker'],keep='last')
    q['at_forecast_cutoff']=True;q['minutes_before_tip']=(q.tipoff-q.quote_time).dt.total_seconds()/60;q['market']='spreads'
    old=pd.read_parquet(OUT/'predictions.parquet')
    model=pd.read_parquet(OUT/'recomputed-model-predictions.parquet')
    residuals=pd.read_parquet(OUT/'earlier-heldout-residuals.parquet').residual.to_numpy()
    x=model.merge(q.drop(columns=['season','decision_time']),on='game_id',validate='one_to_one')
    home,away,push=probabilities(x.predicted_margin.to_numpy(),x.line.to_numpy(),residuals)
    edge=x.predicted_margin+x.line
    x['spread_side']=np.where(edge>1e-10,'home',np.where(edge < -1e-10,'away','pass'))
    x['cover_probability']=np.where(edge>=0,home,away);x['push_probability']=push
    x['winner_confidence']=np.maximum(x.win_probability,1-x.win_probability)
    x['cover_band']=bands(x.cover_probability);x['winner_band']=bands(x.winner_confidence)
    x.to_parquet(OUT/'cutoff-predictions.parquet',index=False)
    old_ids=set(old[old.at_forecast_cutoff].game_id);new_ids=set(x.game_id)
    dump(OUT/'cutoff-recovery-manifest.json',{'reason':'Raw archive has a few repeated event/book entries; selecting latest near-tipoff first can discard an earlier eligible quote.',
         'test_outcomes_read':False,'source_code_sha256':sha(__file__),'source_archive_sha256':sha(raw),'prediction_sha256':sha(OUT/'cutoff-predictions.parquet'),
         'strict_rows':len(x),'previous_strict_rows':len(old_ids),'additional_games':sorted(new_ids-old_ids),'rejected_conflict_rows':conflict_n,
         'selection_policy':'Latest nonconflicting archived DraftKings quote at/before one-hour decision cutoff, <=24 hours old; exact identity/orientation/date and <=2-hour tipoff tolerance.'})
    print('Cutoff-only predictions frozen:',len(x),'previous retained subset:',len(old_ids),flush=True)

if __name__=='__main__':main()
