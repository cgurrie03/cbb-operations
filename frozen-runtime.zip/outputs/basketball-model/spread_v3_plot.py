"""Standalone reliability figure from already-frozen evaluation results."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from spread_v3 import OUT

def main():
    data=json.loads((OUT/'results.json').read_text())
    fig,ax=plt.subplots(figsize=(9,6),layout='constrained')
    ax.plot([0,1],[0,1],linestyle='--',color='#7b7b7b',label='Perfect calibration')
    ax.axhline(.5,color='#999999',linewidth=1)
    styles=[('original_core','Original core diagnostic','#c35620','o'),('cover_logistic_raw','Direct spread model','#176080','s'),('cover_logistic_calibrated','Calibrated spread model','#21805e','D')]
    for candidate,label,color,marker in styles:
        rows=[r for r in data['confidence_buckets'] if r['cohort']=='provider_labeled_close' and r['season']=='all' and r['candidate']==candidate and r['decided']]
        n=sum(r['decided'] for r in rows)
        for i,r in enumerate(rows):
            x,y=r['mean_probability'],r['observed_cover_rate'];low,high=r['date_block_interval']
            if low is not None:ax.vlines(x,low,high,color=color,linewidth=1.2,alpha=.7)
            ax.scatter(x,y,color=color,marker=marker,s=45,label=f'{label} (n={n:,})' if i==0 else None,zorder=3)
            if r['decided']<100:ax.annotate(f"n={r['decided']}",(x,y),xytext=(5,7),textcoords='offset points',fontsize=8,color=color)
    ax.set(xlim=(0,1),ylim=(0,1),xlabel='Mean predicted spread-cover probability',ylabel='Actual cover rate',title='Spread-cover reliability against historical closing lines\n2024–25 and 2025–26 · 11,505 matched games')
    ax.xaxis.set_major_formatter(PercentFormatter(1));ax.yaxis.set_major_formatter(PercentFormatter(1));ax.legend(loc='upper left',fontsize=9)
    fig.text(.12,-.035,'Points are fixed probability bands; bars are 95% date-block intervals. Empty bands omitted.\nNew spread candidates have no 70% predictions. Provider-labeled closes lack exact capture timestamps.',fontsize=9)
    fig.savefig(OUT/'spread-reliability.png',dpi=180,bbox_inches='tight');fig.savefig(OUT/'spread-reliability.svg',bbox_inches='tight');plt.close(fig)
    print('Standalone reliability figure saved.')

if __name__=='__main__':main()
