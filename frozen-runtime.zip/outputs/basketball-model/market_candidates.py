"""Point-in-time market baselines and residual challengers. No provider requests."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge,LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from odds_history import before_cutoff,stamp

MIN_TRAIN,MIN_TEST,MIN_SEASONS=1000,200,2
def consensus(rows):
    groups={}
    for r in rows:groups.setdefault((r['book'],r['market']),{}).setdefault(r['selection'],[]).append(r)
    values={'margin':[],'total':[],'probability':[]}
    for (book,market),selections in groups.items():
        pair=['over','under'] if market=='totals' else ['home','away']
        if any(len(selections.get(k,[]))!=1 for k in pair):continue
        a,b=[selections[k][0] for k in pair]
        # A complete pair from the same observed book market, not synthetic sides.
        if a['observed_at']!=b['observed_at'] or a['quote_at']!=b['quote_at']:continue
        if market=='spreads' and abs(a['point']+b['point'])<1e-9:values['margin'].append(-a['point'])
        elif market=='totals' and a['point']==b['point']:values['total'].append(a['point'])
        elif market=='h2h':
            pa,pb=1/a['decimal_price'],1/b['decimal_price'];values['probability'].append(pa/(pa+pb))
    return {**{k:float(np.median(v)) if v else None for k,v in values.items()},**{k+'_books':len(v) for k,v in values.items()}}
def build_inputs(slates,quotes):
    rows=[]
    for game in slates.to_dict('records'):
        # event_id must be the exact identity mapped by the protected collector.
        event=[r for r in quotes if r['event_id']==game['event_id']]
        q=before_cutoff(event,game['decision_time'])
        c=consensus(q)
        rows.append({**game,**{'market_'+k:v for k,v in c.items()},'eligible_quote_count':len(q)})
    return pd.DataFrame(rows)
def gate(frame):
    if frame.empty:return {'status':'insufficient_data','eligible_games':0,'reason':'No timestamped prospective quotes yet'}
    train=frame[frame.season<=2022];test=frame[frame.season.between(2023,2025)]
    ok=len(train)>=MIN_TRAIN and len(test)>=MIN_TEST and test.season.nunique()>=MIN_SEASONS
    return dict(status='ready' if ok else 'insufficient_data',training_games=len(train),test_games=len(test),test_seasons=int(test.season.nunique()),
                required_training=MIN_TRAIN,required_test=MIN_TEST,required_test_seasons=MIN_SEASONS)
def candidate_predictions(train,test,target):
    """Training labels allowed only for earlier years. Test targets forbidden."""
    assert train.season.max()<test.season.min()
    assert not set(['won','margin','total']).intersection(test.columns)
    market='market_probability' if target=='won' else 'market_'+target
    core='won_prediction' if target=='won' else target+'_prediction'
    a,b=test[market].to_numpy(),test[core].to_numpy()
    if target=='won':
        logit=lambda x:np.log(np.clip(x,1e-6,1-1e-6)/(1-np.clip(x,1e-6,1-1e-6)))
        x=np.c_[logit(train[market].to_numpy()),logit(train[core].to_numpy())]
        model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=1000)).fit(x,train.won)
        correction=model.predict_proba(np.c_[logit(a),logit(b)])[:,1]
    else:
        x=pd.DataFrame({'market':train[market],'gap':train[core]-train[market]})
        model=make_pipeline(StandardScaler(),Ridge(alpha=20)).fit(x,train[target]-train[market])
        correction=a+model.predict(pd.DataFrame({'market':a,'gap':b-a}))
    return {'consensus':a,'fixed_blend':.5*a+.5*b,'market_correction':correction}
def line_probabilities(forecast,line,residuals,selection):
    """Residuals must come from earlier held-out training predictions only."""
    if len(residuals)<1000:raise ValueError('Insufficient earlier calibration residuals')
    actual=forecast+np.asarray(residuals)
    if selection=='home':delta=actual+line
    elif selection=='away':delta=-actual+line
    elif selection=='over':delta=actual-line
    elif selection=='under':delta=line-actual
    else:raise ValueError('Unknown selection')
    push=np.isclose(delta,0)
    return {'win':float(((delta>0)&~push).mean()),'push':float(push.mean()),'loss':float(((delta<0)&~push).mean())}
def settle(probability,price,result,validated=False,push_probability=0):
    """Candidate policy. Disable issuance until a separate validation gate passes."""
    if not np.isfinite(price) or abs(price)<100:raise ValueError('Invalid American price')
    decimal=1+price/100 if price>0 else 1+100/abs(price)
    if not 0<=probability<=1 or not 0<=push_probability<=1-probability:raise ValueError('Invalid probabilities')
    ev=probability*(decimal-1)-(1-probability-push_probability)
    if not validated or ev<.03:return {'status':'pass','expected_return':ev,'profit':0}
    return {'status':result,'expected_return':ev,'profit':decimal-1 if result=='win' else -1 if result=='loss' else 0}
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--inputs',type=Path);parser.add_argument('--targets',type=Path);args=parser.parse_args()
    if args.inputs:
        if not args.targets:raise ValueError('Separate training/grading target file required')
        frame=pd.read_parquet(args.inputs)
        assert not {'won','margin','total'}.intersection(frame.columns)
        # Inputs must be generated by build_inputs from observed, as-of quotes.
        assert frame.game_id.is_unique and (frame.eligible_quote_count>0).all()
        assert frame.season.max()<=2025,'This charter preserves the 2026 holdout'
        ready=gate(frame)
        if ready['status']!='ready':args.out.write_text(json.dumps(ready,indent=2));return
        directory=args.out.with_suffix('');directory.mkdir(exist_ok=False)
        paths=[]
        for year in [2023,2024,2025]:
            prior=pd.read_parquet(args.targets,filters=[('season','<',year)])
            tr=frame[frame.season<year].merge(prior[['game_id','won','margin','total']],on='game_id',validate='one_to_one')
            test=frame[frame.season==year]
            rows=[]
            for target,market in [('won','market_probability'),('margin','market_margin'),('total','market_total')]:
                t=tr[tr[market].notna()];v=test[test[market].notna()]
                if len(t)<MIN_TRAIN or len(v)<MIN_TEST:continue
                for candidate,prediction in candidate_predictions(t,v,target).items():
                    x=v[['game_id','season','decision_time']].copy();x['target']=target;x['candidate']=candidate;x['prediction']=prediction;rows.append(x)
            if rows:
                path=directory/f'predictions-{year}.parquet';pd.concat(rows).to_parquet(path,index=False);paths.append(path)
        hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
        (directory/'prediction_hashes.json').write_text(json.dumps(hashes,indent=2))
        metrics=[]
        if paths:
            labels=pd.read_parquet(args.targets,filters=[('season','<=',2025)])
            allpred=pd.concat([pd.read_parquet(p) for p in paths]).merge(labels[['game_id','won','margin','total']],on='game_id',validate='many_to_one')
            for (target,candidate,year),x in allpred.groupby(['target','candidate','season']):
                if target=='won':
                    prob=np.clip(x.prediction,1e-6,1-1e-6);score=float(-(x.won*np.log(prob)+(1-x.won)*np.log(1-prob)).mean())
                else:score=float((x.prediction-x[target]).abs().mean())
                metrics.append(dict(target=target,candidate=candidate,season=int(year),n=len(x),metric='log_loss' if target=='won' else 'mae',score=score))
        assert hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
        enough=len({r['season'] for r in metrics})>=MIN_SEASONS
        args.out.write_text(json.dumps({'status':'research_complete' if enough else 'insufficient_data','metrics':metrics if enough else [],'promotion':False,'prediction_hashes':hashes},indent=2));return
    folder=Path(__file__).resolve().parents[2]/'work/odds-snapshots/normalized'
    snapshots=[json.loads(p.read_text()) for p in folder.glob('*.json')]
    result=gate(pd.DataFrame())
    result.update(snapshots=len(snapshots),quote_rows=sum(len(s['rows']) for s in snapshots),
        historical_constraint='Archived near-tipoff lines excluded from -60 minute model inputs; no archived spread/total prices.',
        promotion=False,network_requests=0)
    args.out.write_text(json.dumps(result,indent=2));print(json.dumps(result))
if __name__=='__main__':main()
