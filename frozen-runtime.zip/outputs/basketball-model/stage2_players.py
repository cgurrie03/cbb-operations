"""Audit prior appearances for contributor warnings, without inferring injuries."""
import pandas as pd
from stage2_data import load, OUT, write_json


def main():
    games=pd.read_parquet(OUT/'games.parquet')[['game_id','home_team','away_team','tipoff','result_available_assumed']]
    parts=[]; audit=[]; manifests=[]
    for season in range(2016,2026):
        raw,manifest=load('player_box',season); manifests.append(manifest)
        df=raw.copy(); df.game_id='espn:'+df.game_id.astype(str)
        df=df[df.game_id.isin(games.game_id)].copy()
        valid=df.athlete_id.notna()&df.team_id.notna()&df.minutes.notna()&df.minutes.ge(0)&df.minutes.le(80)
        clean=df.loc[valid,['game_id','season','athlete_id','athlete_display_name','team_id','minutes','did_not_play']].copy()
        clean.athlete_id=clean.athlete_id.astype('int64'); clean.team_id=clean.team_id.astype('int64')
        duplicates=int(clean.duplicated(['game_id','team_id','athlete_id']).sum())
        if duplicates: raise ValueError(f'Duplicate appearance keys: season {season}, {duplicates}')
        clean=clean.merge(games,on='game_id',validate='many_to_one')
        ids='espn:'+clean.team_id.astype(str)
        if not (ids.eq(clean.home_team)|ids.eq(clean.away_team)).all(): raise ValueError('Player team/game identity mismatch')
        audit.append({'season':season,'raw_rows':len(raw),'retained_D1_game_rows':len(df),
                      'valid_appearance_rows':len(clean),'excluded_missing_or_invalid':int((~valid).sum()),
                      'duplicate_keys':duplicates,'note':'Postgame appearances estimate prior contribution only; never pregame injury status.'})
        parts.append(clean.drop(columns=['home_team','away_team']))
        print(f'player audit {season}: {len(clean):,} valid appearances',flush=True)
    pd.concat(parts,ignore_index=True).to_parquet(OUT/'player_appearances.parquet',index=False)
    write_json(OUT/'player_audit.json',{'seasons':audit,'source_manifests':manifests,
                                     'historical_injury_status_inferred':False,'source_publication_times_verified':False})


if __name__=='__main__': main()
