"""Publish readiness documentation and reproducible, credential-free artifacts."""
from pathlib import Path
import json,shutil
from preseason_prepare import OUT,ROOT
from spread_v3 import sha,dump

DELIVER=Path(r'C:\Users\coope\Documents\Codex\2026-10-17\rev\outputs\preseason-opening-day')
SITE=ROOT.parent/'court-signal'

def main():
    d=json.loads((OUT/'readiness-latest.json').read_text())
    text=f'''# Opening-day preparation — November 2, 2026

Preparation completed October 18, 2026. The site is prepared for contemporaneous paper testing; live betting recommendations remain disabled.

## What is ready

- Current-season, source-tagged ESPN rosters captured for {d['rosters_captured']} of {d['roster_teams']} Division I teams, including the three schools absent from the main ESPN team-list response. Prior rosters/coaches were also requested. Missing historical coach/roster records remain unknown.
- Prior-season player IDs matched to 2026 Division I minutes to measure retained minutes, incoming players with Division I history, and observed source-reported coach changes ({d['coach_changes']}). Roster presence is not health clearance. No invented transfer, recruit or coach point coefficient was added.
- Settled 2026 team strengths and efficiency priors prepared. Existing carryover rules and early-history shrinkage are preserved. Descriptive roster warnings remain separate from calibrated spread probabilities.
- A new prospective model is frozen: enhanced spread-v4 algorithm, fit on 2021–2025 and calibrated on 2026, with enhanced calibrated and market-price controls. Those years are now development history. The untouched prospective evaluation starts in season2027. No 2027 outcome was used to fit or calibrate.
- Opening-day schedule captured: {d['schedule_games']} games, {d['eligible_d1_games']} D1-versus-D1 games eligible for this model. D1-versus-non-D1 games stay on the normal Games schedule but do not receive unsupported model predictions.
- Append-only paper forecast storage, real issue-time checks, model/feature/source hashes, cutoff and quote-age guards, immutable previous forecasts, one canonical pre-cutoff record per game/candidate, result collection after a24h release delay, separate grading, coverage/missed-game counts, log loss/Brier and confidence bands are implemented.
- The existing five daily odds updates now also run the prospective pipeline. They keep all three odds markets and existing API/key/quota protections. The paper pipeline reads cached paid odds and free public data; it does not make another paid odds request.
- One additional one-time opening-night check is configured for November1 at22:45 America/New_York. The regular November1 21:00 run reserves its paid slot for that check. The earliest currently confirmed tip is03:00 Eastern November2, with a02:00 cutoff. Unconfirmed placeholder times are displayed as TBD and cannot issue forecasts. The prior-evening check provides a pre-cutoff capture opportunity without increasing the five-request daily ceiling.

## Frozen paper selection rule

Compare the actual available prices and handicaps on both sides, select at most one offer per game, and require at least2% expected profit per unit risked. Both teams must have eight prior current-season D1 games, a fresh actually observed price, and explicit source-backed availability coverage. Missing, late, stale or unverified inputs mean pass. No real wagers are placed. Opening-day and early-season passes are expected.

Forecasts are recorded only within24h of listed tipoff and before tipoff minus60min. Source observation and provider update must precede issue; price age at issue is at most15min. Outside that window the displayed entries are previews, not issued forecasts. At preparation time there are {d['priced_games']} qualifying priced opening games and {d['forecasts_issued_total']} actual paper forecasts issued; missing probabilities are not fabricated.

## Monitoring and limits

Existing cadence:09:00,12:00,15:00,18:00,21:00 Eastern. The November1 22:45 check is a one-time exception replacing that day's21:00 paid call. These are LOCAL Codex automations: this computer and Codex must be awake/available. Configured schedules do not prove a run occurred. Five periodic updates cannot guarantee a fresh quote for every game's cutoff; missing games/quotes remain visible and are never reconstructed after results.

Next-slate rosters refresh at most daily. Current result capture can catch up seven dates per run after downtime; each result retains its actual first observation time and cannot influence earlier forecasts. No postgame DNP is classified as a pregame injury.

The official SEC availability page was reachable on October18, but no verified game-specific report was ingested. A strict source-linked report/coverage importer is ready. Availability remains unknown until adequate timely evidence exists; no report does not mean healthy. Current report capture and publication times are required and stale reports are rejected. There is no league-wide verified injury clearance feed connected.

First-week review (November9 or next available run) checks collection, identities, missing prices, cutoffs and grading. It does not automatically recalibrate. Formal performance review requires at least1,000 canonical priced forecasts,200 paper selections and30 active dates. Those are review thresholds, not proof of profitability or automatic promotion. A revised model must get a new version and its own prospective evaluation.

## Validation and reproducibility

The release manifest seals operational source, models, fixed history and priors. Every future run verifies those hashes before collection. Paper records reject backdating, future features/quotes, stale prices, missing prices, target fields and rewriting issued forecasts. Test fixtures use temporary test-only storage, never production paper history.

Preparation artifacts include the charter, source/roster audit, preseason team priors, fitted model and release manifests. Private protected provider credentials, raw paid odds and private live forecasts are excluded. Implementation snapshots are under implementation/. Operations are documented in PRESEASON_2027_OPERATIONS.md.

Current website: https://cbb.coopergurrie.com/#spreads

Sources: ESPN public team/roster/scoreboard/summary endpoints; hash-preserved SportsDataverse historical boxes and2027 membership; the existing protected The Odds API collector; https://www.secsports.com/mbbreports . Current rosters are captured observations from ESPN, not an assertion of full independent school-by-school verification.
'''
    (OUT/'README.md').write_text(text,encoding='utf-8');DELIVER.mkdir(parents=True,exist_ok=True)
    files=['README.md','CHARTER.md','model-manifest.json','release-manifest.json','roster-audit.csv','roster-audit.json','team-priors.csv',
           'readiness-latest.json','availability-source-status.json','frozen-models.joblib','efficiency-priors.json','online-priors.json']
    for file in files:shutil.copy2(OUT/file,DELIVER/file)
    for directory in [DELIVER/'implementation',SITE/'research/preseason-2027']:
        directory.mkdir(parents=True,exist_ok=True)
        for file in ['preseason_prepare.py','preseason_features.py','prospective_run.py','prospective_registry.py','test_prospective_2027.py','PRESEASON_2027_OPERATIONS.md']:
            shutil.copy2(ROOT/file,directory/file)
        for file in ['CHARTER.md','model-manifest.json','release-manifest.json']:shutil.copy2(OUT/file,directory/file)
    shutil.copy2(OUT/'README.md',SITE/'dist/preseason-method.md')
    dump(DELIVER/'artifact-checksums.json',{p.name:sha(p) for p in DELIVER.iterdir() if p.is_file() and p.name!='artifact-checksums.json'})
    print('Preseason report, audit and implementation snapshot prepared.',flush=True)

if __name__=='__main__':main()
