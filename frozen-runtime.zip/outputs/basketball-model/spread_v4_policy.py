"""Production gate: research results never silently authorize live selections."""
import numpy as np
import pandas as pd
from spread_v4 import decision

def issue(frame,selection,minimum_ev=.02):
    """Known pre-cutoff quotes and reviewed availability required for a promoted model."""
    x=decision(frame,minimum_ev)
    if not selection.get('promotion',False):
        x['selected_side']='pass';x['selected_price']=np.nan
        x['pass_reason']='model has not passed prospective promotion gate'
        return x
    required={'quote_time','decision_time','injury_snapshot_verified','historical_timing_verified'}
    if not required.issubset(x):raise ValueError('Production timing/availability evidence missing')
    quote=pd.to_datetime(x.quote_time,utc=True,errors='coerce')
    cutoff=pd.to_datetime(x.decision_time,utc=True,errors='coerce')
    valid=quote.notna()&cutoff.notna()&quote.le(cutoff)&(cutoff-quote).le(pd.Timedelta(minutes=15))
    valid &= x.injury_snapshot_verified.eq(True)&x.historical_timing_verified.eq(True)
    x.loc[~valid,'selected_side']='pass';x.loc[~valid,'selected_price']=np.nan
    x.loc[~valid,'pass_reason']='unverified or stale pregame information'
    # One opportunity per game; compare expected profit, never the eventual score.
    x=x.sort_values(['expected_profit','quote_time'],ascending=[False,False],na_position='last')
    selected=x[x.selected_side.ne('pass')].drop_duplicates('game_id',keep='first')
    passed=x[~x.game_id.isin(selected.game_id)].drop_duplicates('game_id',keep='first')
    return pd.concat([selected,passed],ignore_index=True)
