"""Append-only, result-free shadow forecast snapshots for future validation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
from odds_history import stamp

ROOT=Path(__file__).resolve().parents[2]/'work/prospective-forecasts'
REQUIRED={'game_id','tipoff','decision_time','issued_at','model_version','features_observed_at','feature_sha256','predicted_margin','predicted_total','home_win_probability','status'}
FORBIDDEN={'home_score','away_score','won','margin','total','result','final_score'}
def save(forecast,directory=ROOT):
    if not REQUIRED<=forecast.keys() or FORBIDDEN.intersection(forecast):raise ValueError('Incomplete or result-bearing forecast')
    issued,cutoff,tip,observed=map(stamp,[forecast['issued_at'],forecast['decision_time'],forecast['tipoff'],forecast['features_observed_at']])
    if None in [issued,cutoff,tip,observed] or not observed<=issued<=cutoff<tip:raise ValueError('Forecast was not recorded before cutoff')
    now=datetime.now(timezone.utc)
    if now>cutoff or not -5<=(now-issued).total_seconds()<=300:raise ValueError('Cannot backdate a forecast')
    if forecast['status']!='shadow':raise ValueError('Live promotion is not authorized by the unresolved audit')
    if not 0<=forecast['home_win_probability']<=1:raise ValueError('Invalid probability')
    import math
    if not all(math.isfinite(forecast[k]) for k in ['predicted_margin','predicted_total','home_win_probability']):raise ValueError('Invalid forecast')
    directory.mkdir(parents=True,exist_ok=True)
    key=hashlib.sha256((forecast['game_id']+'|'+forecast['decision_time']+'|'+forecast['model_version']).encode()).hexdigest()
    path=directory/(key+'.json');payload=json.dumps(forecast,sort_keys=True,allow_nan=False).encode()
    if path.exists():
        if path.read_bytes()!=payload:raise ValueError('Refusing to revise an issued forecast')
    else:
        with path.open('xb') as out:out.write(payload)
    return {'path':str(path),'sha256':hashlib.sha256(payload).hexdigest()}
