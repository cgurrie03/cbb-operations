"""Source-backed availability warnings; never invent injury probabilities."""
from datetime import timedelta
import pandas as pd

UNCERTAIN={'questionable','game time decision','game-time decision','gtd','doubtful'}
ABSENT={'out','suspended'}


def prior_minutes(players, player_id, team_id, cutoff):
    """Only available prior appearances within 90 days; postgame DNP isn't injury."""
    if players is None or players.empty:
        return None
    cutoff=pd.Timestamp(cutoff)
    history=players[(players.athlete_id.astype('Int64').astype(str)==str(player_id)) &
                    (players.team_id.astype('Int64').astype(str)==str(team_id)) &
                    (players.result_available_assumed<=cutoff) &
                    (players.tipoff>=cutoff-pd.Timedelta(days=90)) & players.minutes.gt(0)]
    if history.empty: return None
    return float(history.sort_values('tipoff').tail(5).minutes.mean())


def warnings_for_game(game_id, cutoff, reports, players=None, coverage_verified=False):
    cutoff=pd.Timestamp(cutoff)
    if cutoff.tzinfo is None: raise ValueError('cutoff needs timezone')
    warnings=[]; latest={}; rejected=[]
    for report in reports:
        if report.get('game_id')!=game_id: continue
        try:
            published=pd.Timestamp(report['published_at'])
            observed=pd.Timestamp(report['observed_at'])
            if published.tzinfo is None or observed.tzinfo is None:
                raise ValueError('report timestamp needs timezone')
            if max(published,observed)>cutoff: raise ValueError('report unavailable at cutoff')
            if cutoff-published>pd.Timedelta(hours=48): raise ValueError('report stale')
            if not report.get('source_url'): raise ValueError('source URL missing')
            key=(str(report['team_id']),str(report['player_id']))
            if key not in latest or published>pd.Timestamp(latest[key]['published_at']): latest[key]=report
        except (KeyError,ValueError,TypeError) as e:
            rejected.append({'player_id':report.get('player_id'),'reason':str(e)})
    for report in latest.values():
        status=report.get('status','').strip().lower()
        if status not in UNCERTAIN|ABSENT: continue
        minutes=prior_minutes(players,report['player_id'],report['team_id'],cutoff)
        contributing=minutes is not None and minutes>=20
        if contributing: level='key_player'
        elif minutes is None: level='contribution_unknown'
        else: level='rotation_player'
        message=(f"{'Key player' if contributing else 'Player'} availability {'uncertain' if status in UNCERTAIN else 'affected'}: "
                 f"{report.get('player_name','Reported player')} is {report['status']}. "
                 'Forecast may change when availability is confirmed.')
        warnings.append({'level':level,'message':message,'player_id':str(report['player_id']),
                         'status':status,'prior_average_minutes':minutes,'source_url':report['source_url'],
                         'published_at':report['published_at'],'observed_at':report['observed_at'],
                         'probability_adjustment':None})
    if not coverage_verified:
        warnings.append({'level':'coverage_unknown','message':'Player availability has not been verified for this game.','probability_adjustment':None})
    return {'warnings':warnings,'rejected_reports':rejected,'coverage_verified':coverage_verified,
            'automatic_probability_adjustment':False}
